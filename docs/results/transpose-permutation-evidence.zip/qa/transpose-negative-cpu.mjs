import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {readFile,writeFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import vm from 'node:vm';
import {runtimePlan} from '../../../src/tflite-runtime-policy.js';
import {executeRuntime} from '../../../src/tflite-runtime-execute.js';
import {parseModel} from '../../../src/model-engine.js';
import {Archive} from '../../../vendor/netron/zip.js';
const base=new URL('../../../vendor/litert/2.6.0/',import.meta.url),messages=[],report={status:'running',runtime:'LiteRT.js2.6.0 CPUWASM,numThreads1',cases:[],scope:'Explicit tinyNodeCPUcomparison;no applicationchange,newbrowser,modelupload orfullbrowsermemoryclaim.'};
globalThis.self=globalThis;globalThis.require=createRequire(import.meta.url);globalThis.__dirname=fileURLToPath(base);
globalThis.importScripts=url=>vm.runInThisContext(readFileSync(new URL(url),'utf8'),{filename:fileURLToPath(url)});
globalThis.Module={locateFile:name=>fileURLToPath(new URL(name,base)),printErr:s=>messages.push(String(s))};
const rt=await import('../../../vendor/litert/2.6.0/core.js');await rt.loadLiteRt(new URL('litert_wasm_compat_internal.js',base).href);
const metadata=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',import.meta.url),'utf8'));
try{
 for(const [name,input,expected] of [['minimal-positive',[42],[42]],['minimal-negative',[42],[42]],['positive',[1,2,3,4,5,6],[1,4,2,5,3,6]],['negative',[1,2,3,4,5,6],[1,4,2,5,3,6]],['negative-identity',[1,2,3,4,5,6],[1,2,3,4,5,6]]]){
  const raw=new Uint8Array(await readFile(new URL(`transpose-negative-${name}.tflite`,import.meta.url))),blob=new Blob([raw]),index=await parseModel((o,n)=>raw.subarray(o,o+n),raw.length,metadata),plan=runtimePlan(index.raw,raw.length);assert.ok(plan.eligible);messages.length=0;
  const result=await executeRuntime({blob,plan,rt,specs:[{mode:'bin',file:new File([Float32Array.from(input)],'input.bin')}],diagnostics:()=>messages});
  const row={name,status:result.status,reason:result.reason,stage:result.stage,compiled:result.compiled,invoked:result.invoked,modelSHA256:createHash('sha256').update(raw).digest('hex'),diagnostics:result.diagnostics,input,expected};
  if(result.io?.archive){const data=new Uint8Array(await result.io.archive.arrayBuffer());await writeFile(new URL(`transpose-negative-cpu-${name}.zip`,import.meta.url),data,{flag:'wx'});row.ioSHA256=createHash('sha256').update(data).digest('hex');row.ioBytes=data.length;
   const zip=Archive.open(data,'zip');if(zip.entries.has('outputs-0.bin')){row.actual=[...new Float32Array(zip.entries.get('outputs-0.bin').peek().slice().buffer)];row.exactOutput=row.actual.length===expected.length&&row.actual.every((n,i)=>Object.is(n,expected[i]));}
  }
  report.cases.push(row);
 }
 assert.ok(report.cases.filter(c=>c.name.endsWith('positive')).every(c=>c.status==='passed'&&c.exactOutput));
 report.status=report.cases.every(c=>c.status==='passed'&&c.exactOutput)?'all-valid-positive-and-negative-cpu-passed':'negative-compatibility-difference-retained';
}catch(e){report.status='failed-comparison';report.error=e.stack||String(e);process.exitCode=1;}
finally{rt.unloadLiteRt();report.finishedAt=new Date().toISOString();await writeFile(new URL('transpose-negative-cpu.json',import.meta.url),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));}
