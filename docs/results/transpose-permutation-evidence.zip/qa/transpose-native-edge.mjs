import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {once} from 'node:events';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {chromium,selectors} from 'playwright';
import {createStaticServer} from '../../../scripts/serve.mjs';
import {verifyArtifact,gitSource} from '../../../scripts/lib/release-artifact.mjs';
import {trustedDocument} from '../../../test/browser/trusted-document.mjs';
import {windowsProcessObserver} from '../../../test/browser/windows-process-memory.mjs';
import {registerDOMReader,desktopDOMReader} from '../../../test/browser/desktop-dom-reader.mjs';
import {parseModel} from '../../../src/model-engine.js';
import {tflite as schema} from '../../../vendor/netron/tflite-schema.js';
import {Archive} from '../../../vendor/netron/zip.js';
assert.equal(process.platform,'win32');assert.ok(process.argv.includes('--allow-local-browser'));
const [mode,buildArg,outputArg,commit]=process.argv.slice(2).filter(v=>!v.startsWith('--'));
assert.ok(['red','green'].includes(mode)&&buildArg&&outputArg&&/^[a-f0-9]{40}$/.test(commit));
const q=path.dirname(fileURLToPath(import.meta.url)),build=path.resolve(buildArg),output=path.resolve(outputArg),source=gitSource();assert.equal(source.dirty,false);
const metadata=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',import.meta.url),'utf8')),artifact=await verifyArtifact(build,{expectedCommit:commit,requireClean:true,publicOnly:true});
await mkdir(output);await registerDOMReader(selectors);const server=createStaticServer(build);server.listen(0,'127.0.0.1');await once(server,'listening');const base=`http://127.0.0.1:${server.address().port}/`,pause=ms=>new Promise(r=>setTimeout(r,ms)),report={status:'running',mode,driverSource:source,release:artifact.release,browsers:[],scope:'SyntheticnegativeTranspose→Add;nativechooser/clone/export/reopen/search/manualrawBINCPU at32px1280x640;manifestpinnedHTMLfixture,not HTTPSdocumenttransport orphysicalRSSacceptance.'};
try{
 for(const channel of ['msedge']){
  const row={channel,status:'running',workers:[],errors:[],downloads:0};report.browsers.push(row);let browser,context,page,observer,closing=false;
  try{
   browser=await chromium.launch({channel,headless:true,args:channel==='chrome'?['--disable-updater-scheduler']:[]});row.version=browser.version();const cdp=await browser.newBrowserCDPSession();observer=await windowsProcessObserver({python:process.env.MODEL_LENS_QA_PYTHON,cdp,channel});row.root=observer.root;
   context=await browser.newContext({acceptDownloads:true,viewport:{width:1280,height:640}});const documentFixture=await trustedDocument(build,artifact);row.documentFixture=documentFixture.proof;
   await context.route('**/*',async route=>{if(new URL(route.request().url()).origin!==new URL(base).origin||route.request().method()!=='GET'){row.errors.push('Unexpected appnetwork request');return route.abort();}if(!await documentFixture.handle(route,base))await route.continue();});
   page=await context.newPage();page.setDefaultTimeout(30000);page.on('pageerror',e=>row.errors.push(e.message));page.on('download',()=>row.downloads++);page.on('worker',w=>{const entry={url:w.url(),closed:false};row.workers.push(entry);w.once('close',()=>{entry.closed=true;});});const read=desktopDOMReader(page);
   const until=async fn=>{const end=Date.now()+30000;while(!await read(fn)){assert.ok(Date.now()<end,'UI condition timeout: '+fn);await pause(50);}};
   const ready=()=>until(()=>document.querySelector('#model-tabs').getAttribute('aria-busy')==='false'&&document.querySelector('#loading-card').hidden&&document.querySelector('#target').getAttribute('aria-busy')==='false');
   const choose=async(file,button)=>{const event=page.waitForEvent('filechooser');await page.locator(button).click();await(await event).setFiles(file);};
   const save=async(button,name)=>{const event=page.waitForEvent('download');await page.locator(button).click();const d=await event;assert.equal(await d.failure(),null);const p=path.join(output,channel+'-'+name);await d.saveAs(p);await d.delete();return p;};
   await page.goto(base);await until(()=>document.querySelector('#application-startup').hidden&&!document.querySelector('#open-model').disabled);await choose(path.join(q,'transpose-negative-ui-source.tflite'),'#open-model');await ready();await page.locator('#graph-font-size').selectOption('32');await ready();await page.locator('#edit-mode').click();await until(()=>document.querySelector('#edit-workspace').getAttribute('aria-busy')==='false'&&document.querySelectorAll('[data-edit-node]').length===2);await page.locator('#edit-font').selectOption('32');await page.locator('[data-edit-node="op:0:1"] .edit-node-title').click();await page.locator('#edit-add-after').click();await until(()=>document.querySelectorAll('.edit-node.added').length===1);await page.locator('#edit-expose').check();
   assert.ok(!await page.locator('#edit-export').isDisabled());const beforeRuntime=row.workers.filter(w=>/tflite-runtime-worker/.test(w.url)).length;
   if(mode==='red'){
    await page.locator('#edit-export').click();await until(()=>document.querySelector('#edit-workspace').getAttribute('aria-busy')==='false'&&document.querySelector('#edit-message').textContent.includes('permutation'));
    row.rejection=await page.locator('#edit-message').textContent();assert.match(row.rejection,/Subgraph #0.*OP #0.*permutation/);assert.equal(row.downloads,0);row.status='reproduced-negative-export-rejection';
   }else{
    const file=await save('#edit-export','negative-edited.tflite');await until(()=>!document.querySelector('#edit-open-result').disabled);assert.equal(row.workers.filter(w=>/tflite-runtime-worker/.test(w.url)).length,beforeRuntime,'Exportmustnotstartinterpreter');
    const raw=new Uint8Array(await readFile(file)),index=await parseModel((o,n)=>raw.subarray(o,o+n),raw.length,metadata),g=index.raw.subgraphs[0];assert.equal(g.operators.length,3);assert.equal(g.operators.filter(op=>index.raw.operator_codes[op.opcode_index].builtin_code===schema.BuiltinOperator.TRANSPOSE).length,1);
    const perm=g.tensors[g.operators[0].inputs[1]],buffer=index.raw.buffers[perm.buffer],view=new DataView(raw.buffer,raw.byteOffset+Number(buffer.offset),Number(buffer.size));assert.equal(perm.type,2);assert.deepEqual([view.getInt32(0,true),view.getInt32(4,true)],[-1,0]);row.export={bytes:raw.length,sha256:createHash('sha256').update(raw).digest('hex'),permutation:[-1,0],operators:3};
    await page.locator('#edit-open-result').click();await ready();await page.locator('#query').fill('Transpose');await until(()=>document.querySelector('#result-count').textContent==='1 筆結果');await page.locator('.result-item').first().click();await ready();row.searchMatches=1;
    await page.locator('#run-mode').click();await page.locator('#edit-runtime-check').click();await until(()=>document.querySelector('#edit-runtime-dialog').open);await page.locator('#runtime-input-mode-0').selectOption('bin');await choose(path.join(q,'transpose-negative-ui-input.bin'),'#runtime-input-file-0');await page.locator('#edit-runtime-run').click();await until(()=>document.querySelector('#run-workspace').getAttribute('aria-busy')==='false'&&!!document.querySelector('#edit-runtime-result').dataset.status);assert.equal(await page.locator('#edit-runtime-result').getAttribute('data-status'),'passed');
    const ioFile=await save('#edit-runtime-download','negative-io.zip'),io=new Uint8Array(await readFile(ioFile)),zip=Archive.open(io,'zip'),manifest=JSON.parse(new TextDecoder().decode(zip.entries.get('manifest.json').peek()));assert.equal(manifest.modelSHA256,row.export.sha256);assert.equal(manifest.validation.status,'passed');
    const tensors=new Map([[g.inputs[0],[1,2,3,4,5,6]]]);for(const op of g.operators){const name=schema.BuiltinOperator[index.raw.operator_codes[op.opcode_index].builtin_code];let expected;if(name==='TRANSPOSE')expected=[1,4,2,5,3,6];else{assert.equal(name,'ADD');const a=tensors.get(op.inputs[0]),b=tensors.get(op.inputs[1]);assert.equal(a.length,b.length);expected=a.map((n,i)=>n+b[i]);}assert.equal(op.outputs.length,1);tensors.set(op.outputs[0],expected);}
    row.outputs=[];for(const [i,id]of [...g.outputs].entries()){const actual=[...new Float32Array(zip.entries.get(`outputs-${i}.bin`).peek().slice().buffer)],expected=tensors.get(id);assert.deepEqual(actual,expected);row.outputs.push({tensor:id,actual,expected});}row.io={sha256:createHash('sha256').update(io).digest('hex'),bytes:io.length};row.status='passed-negative-edit-export-reopen-search-cpu';
   }
   row.layout=await read(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,editFont:document.querySelector('#edit-font').value,graphFont:document.querySelector('#graph-font-size').value}));assert.equal(row.layout.width,1280);assert.ok(row.layout.scrollWidth<=1280);assert.equal(row.layout.editFont,'32');assert.equal(row.layout.graphFont,'32');await page.screenshot({path:path.join(output,channel+'-32px.png')});row.beforeClose=await observer.sample();
   await context.close();context=null;closing=true;let timer;try{await Promise.race([browser.close(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('normal browser.close exceeded10s')),10000);})]);}finally{clearTimeout(timer);}row.browserClosed=true;const remaining=await observer.remaining();row.processCleanup={allReaped:remaining.rows.length===0,remaining:remaining.rows,identities:remaining.identities};assert.ok(row.processCleanup.allReaped);assert.ok(row.workers.length&&row.workers.every(w=>w.closed));assert.deepEqual(row.errors,[]);
  }catch(e){row.status='failed-flow';row.error=e.stack||String(e);if(page&&!page.isClosed())await page.screenshot({path:path.join(output,channel+'-failure.png')}).catch(()=>{});throw e;}
  finally{if(!closing&&browser){await context?.close();await browser.close();}if(observer)row.observerClose=await observer.close();}
 }
 assert.deepEqual(gitSource(),source);report.status=mode==='red'?'reproduced-original-export-rejection':'passed-native-negative-export-regression';
}catch(e){report.status='failed-flow';report.error=e.stack||String(e);process.exitCode=1;}
finally{server.closeAllConnections();await new Promise(r=>server.close(r));report.finishedAt=new Date().toISOString();await writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({status:report.status,browsers:report.browsers.map(b=>({channel:b.channel,status:b.status,error:b.error})),error:report.error}));if(mode==='red')process.exitCode=1;}
