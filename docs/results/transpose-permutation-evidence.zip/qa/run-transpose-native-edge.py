import datetime, hashlib, json, os, pathlib, subprocess, sys
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2]
candidate=root.with_name('tflite-explorer-transpose')
output=q/'transpose-native-edge';log=q/'transpose-native-edge.log';status=q/'transpose-native-edge-status.json'
driver=q/'transpose-native-edge.mjs';commit='4b0822e0df200bfb969a8fa7ea7ab9d387d98484'
assert all(not p.exists() for p in [output,log,status,driver])
state={'status':'create-intent','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'output':str(output),'log':str(log),'driver':str(driver),'source':commit,'purpose':'Complete only the previously unexecuted Edge case; Chrome close failure remains failed','cleanup':'Retain all failure and success evidence; no cleanup authorised','autoRetries':False}
def persist():
    with status.open('w',encoding='utf-8') as f:
        json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
persist()
native=root/'test/browser/windows-process-memory.py';raw=native.read_bytes();scope={'__name__':'postexit_census'}
exec(compile(raw.decode('utf-8').split('observer=Observer()')[0],str(native),'exec'),scope)
old=json.loads((q/'transpose-native-green/report.json').read_bytes());b=old['browsers'][0]
assert old['status']=='failed-flow' and 'exceeded10s' in b['error']
table=scope['snapshot']();live=[]
for identity in b['beforeClose']['identities']:
    row=table.get(identity['pid'])
    if row:
        found=scope['inspect']({**row,'startTicks':identity['startTicks']})
        if found:live.append(found)
state['previousChromeLateCensus']={'observed':len(b['beforeClose']['identities']),'remaining':live,'scope':'Only prevents concurrent owned browsers. SDK force cleanup is logged; this does not prove normal close.'};persist()
assert not live, 'Previous owned browser still live; do not start another'
original=(q/'transpose-native-ui.mjs').read_bytes();text=original.decode('utf-8')
assert text.count("for(const channel of ['chrome','msedge'])")==1
changed=text.replace("for(const channel of ['chrome','msedge'])","for(const channel of ['msedge'])")
driver.write_text(changed,encoding='utf-8',newline='\n')
state['driverChange']={'originalSHA256':hashlib.sha256(original).hexdigest(),'edgeSHA256':hashlib.sha256(driver.read_bytes()).hexdigest(),'onlyChange':"Browser list ['chrome','msedge'] -> ['msedge']; no timer/application/assertion changes"};persist()
env={**os.environ,'DEBUG':'pw:browser','MODEL_LENS_QA_PYTHON':sys.executable}
node=r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
with log.open('xb') as f:
    p=subprocess.Popen([node,str(driver),'green',str(candidate/'build/qa/transpose-candidate-1'),str(output),commit,'--allow-local-browser'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
    state.update(status='running',pid=p.pid);persist();result=p.wait()
state.update(status='producer-exited',exitCode=result,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());persist()
print(json.dumps(state));sys.exit(result)
