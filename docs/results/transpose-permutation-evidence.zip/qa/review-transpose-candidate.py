import hashlib, json, os, pathlib, subprocess, zipfile
from datetime import datetime, timezone

q = pathlib.Path(__file__).resolve().parent
root = q.parents[2]
candidate = root.with_name('tflite-explorer-transpose')
sha = lambda data: hashlib.sha256(data).hexdigest()
pkg = json.loads((candidate/'package.json').read_text('utf-8'))
lock = json.loads((candidate/'package-lock.json').read_text('utf-8'))
oldlock = json.loads((root/'package-lock.json').read_text('utf-8'))
assert pkg['version'] == lock['version'] == lock['packages']['']['version'] == '1.2.1'
for data in (lock, oldlock):
    data.pop('version'); data['packages'][''].pop('version')
assert lock == oldlock, 'dependency versions must remain unchanged'
receipt = json.loads((candidate/'docs/results/windows-v1.2-native.json').read_text('utf-8'))
archive = candidate/'docs/results/windows-v1.2-native-evidence.zip'
assert sha(archive.read_bytes()) == '751174f0c19a878b608613529b8ffb39c6d16f9cc217227d16c90531a5bcff43'
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == 25
    members = next(v for v in receipt.values() if isinstance(v, dict) and 'members' in v)['members']
    assert sorted(z.namelist()) == sorted(m['path'] for m in members)
    for m in members:
        data = z.read(m['path']); assert len(data) == m['bytes'] and sha(data) == m['sha256']
assert receipt['status'] == 'passed-finite-original-policy'
assert receipt['source']['commit'] == 'f592e3d9df7ed48fae2ca19e353c7215638959a3'
assert len(receipt['cases']) == 2 and all(c['status'] == 'passed' for c in receipt['cases'])
tap = (q/'transpose-all-targeted-green.tap').read_text('utf-8')
assert '# tests 56' in tap and '# pass 56' in tap and '# fail 0' in tap and '# skipped 0' in tap
red = json.loads((q/'transpose-native-red/report.json').read_text('utf-8'))
assert red['status'] == 'reproduced-original-export-rejection'
assert len(red['browsers']) == 2 and all(b['status'] == 'reproduced-negative-export-rejection' and b['browserClosed'] and b['processCleanup']['allReaped'] for b in red['browsers'])
files = ['package.json', 'package-lock.json', 'src/tflite-constant-checks.js', 'src/tflite-semantic-checks.js', 'test/tflite-constant-checks.test.mjs', 'test/tflite-semantic-checks.test.mjs', 'test/tflite-transpose-runtime.test.mjs']
snapshot = {p: sha((candidate/p).read_bytes()) for p in files}
subprocess.run(['git','diff','--check'], cwd=candidate, check=True)
out = {'status':'passed-candidate-source-and-preserved-evidence', 'at':datetime.now(timezone.utc).isoformat(), 'candidate':str(candidate), 'baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=candidate,text=True).strip(), 'versions':'1.2.1', 'dependencyLockUnchangedExceptRootVersions':True, 'windowsArchiveMembers':25, 'relatedTests':56, 'nativeRedBrowsers':2, 'sourceSHA256':snapshot, 'nativeGreen':'pending-clean-candidate-build', 'scope':'Source/evidence review only; no claim of deployed fix or future full-model memory acceptance.'}
with (q/'transpose-candidate-source-review.json').open('x',encoding='utf-8') as f:
    json.dump(out,f,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
print(json.dumps(out))
