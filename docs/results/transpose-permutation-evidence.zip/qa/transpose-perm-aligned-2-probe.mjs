import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {readFile,writeFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
import {runtimeFixture} from '../../../test/runtime-fixture.mjs';
import {tflite as schema} from '../../../vendor/netron/tflite-schema.js';
import {FlatbufferWriter} from '../../../src/flatbuffer-writer.js';
import {parseModel} from '../../../src/model-engine.js';
import {checkOperatorMetadata} from '../../../src/tflite-semantic-checks.js';
import {validateTfliteConstants} from '../../../src/tflite-constant-checks.js';
import {runtimePlan} from '../../../src/tflite-runtime-policy.js';
import {executeRuntime} from '../../../src/tflite-runtime-execute.js';
import {Archive} from '../../../vendor/netron/zip.js';
class AlignedWriter extends FlatbufferWriter {
 vector(values,type){if(type==='Uint8Array'&&values.length===16){const p=this.reserve(4+values.length,8,4);this.write(p,values.length);values.forEach((v,i)=>this.write(p+4+i,v,'setUint8'));return p;}return super.vector(values,type);}
}
const base=new URL('../../../vendor/litert/2.6.0/',import.meta.url),messages=[],cases=[];
globalThis.self=globalThis;globalThis.require=createRequire(import.meta.url);globalThis.__dirname=fileURLToPath(base);globalThis.importScripts=url=>vm.runInThisContext(readFileSync(new URL(url),'utf8'),{filename:fileURLToPath(url)});globalThis.Module={locateFile:name=>fileURLToPath(new URL(name,base)),printErr:s=>messages.push(String(s))};
const rt=await import('../../../vendor/litert/2.6.0/core.js');await rt.loadLiteRt(new URL('litert_wasm_compat_internal.js',base).href);const metadata=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',import.meta.url),'utf8'));
try{
 for(const type of [2,4]){
  const {model}=await runtimeFixture({inputShapes:[[1,2],[2]],outputShape:[1,2]}),g=model.subgraphs[0];model.operator_codes[0].builtin_code=schema.BuiltinOperator.TRANSPOSE;model.operator_codes[0].deprecated_builtin_code=schema.BuiltinOperator.TRANSPOSE;
  const bytes=new Uint8Array(type===2?8:16),view=new DataView(bytes.buffer);if(type===2){view.setInt32(0,0,true);view.setInt32(4,1,true);}else{view.setBigInt64(0,0n,true);view.setBigInt64(8,1n,true);}model.buffers.push({data:bytes,offset:0n,size:0n});Object.assign(g.tensors[1],{buffer:1,type});g.inputs=Int32Array.of(0);g.operators[0].builtin_options=null;
  const blob=new AlignedWriter().finish(model,new Blob()),raw=new Uint8Array(await blob.arrayBuffer()),index=await parseModel((o,n)=>raw.subarray(o,o+n),raw.length,metadata);const buffer=index.raw.buffers[1],body=new DataView(raw.buffer,raw.byteOffset+Number(buffer.offset),Number(buffer.size));if(type===4){assert.equal(Number(buffer.offset)%8,0);assert.equal(body.getBigInt64(0,true),0n);assert.equal(body.getBigInt64(8,true),1n);}assert.equal(index.raw.subgraphs[0].tensors[1].type,type);let metadataError,constantError,proof;
  try{checkOperatorMetadata('TRANSPOSE',[g.tensors[0],g.tensors[1]],[g.tensors[2]],{});}catch(e){metadataError=e.message;}
  try{proof=validateTfliteConstants(index.raw,0,(o,n)=>raw.subarray(o,o+n));}catch(e){constantError=e.message;}
  messages.length=0;const result=await executeRuntime({blob,plan:runtimePlan(index.raw,raw.length),rt,specs:[{mode:'bin',file:new File([Float32Array.of(1,2)],'input.bin')}],diagnostics:()=>messages});let actual;
  if(result.io?.archive){const zip=Archive.open(new Uint8Array(await result.io.archive.arrayBuffer()),'zip');if(zip.entries.has('outputs-0.bin'))actual=[...new Float32Array(zip.entries.get('outputs-0.bin').peek().slice().buffer)];}
  cases.push({type,bufferOffset:Number(buffer.offset),aligned8:Number(buffer.offset)%8===0,metadataAccepted:!metadataError,metadataError,constantAccepted:!constantError,constantError,proof,cpu:result.status,stage:result.stage,reason:result.reason,actual,expected:[1,2],diagnostics:result.diagnostics});
 }
}finally{rt.unloadLiteRt();await writeFile(new URL('transpose-perm-aligned-2-probe.json',import.meta.url),JSON.stringify({cases,scope:'Onlyint32vsint64permutationcontrol;actualCPU,notanappfix'},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({cases}));}
