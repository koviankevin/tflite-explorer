import datetime, json, os, pathlib, subprocess, sys
q = pathlib.Path(__file__).resolve().parent
root = q.parents[2]
candidate = root.with_name('tflite-explorer-transpose')
node = pathlib.Path(r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe')
output = q/'transpose-native-green'
status = q/'transpose-native-green-status.json'
log = q/'transpose-native-green.log'
commit = '4b0822e0df200bfb969a8fa7ea7ab9d387d98484'
def save(data):
    with status.open('w', encoding='utf-8') as f:
        json.dump(data,f,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
assert not output.exists() and not log.exists() and not status.exists(), 'Preserve prior attempts; do not overwrite evidence'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=candidate,text=True).strip() == commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=candidate,text=True).strip()
state={'status':'create-intent','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':commit,'output':str(output),'log':str(log),'producer':'transpose-native-ui.mjs green','purpose':'Native Chrome/Edge affected export/reopen/search/manual CPU at1280x640/32px','cleanup':'Retain original and corrected evidence; no cleanup authorised','noRetry':True}
save(state)
env=os.environ.copy();env['DEBUG']='pw:browser';env['MODEL_LENS_QA_PYTHON']=sys.executable
cmd=[str(node),str(q/'transpose-native-ui.mjs'),'green',str(candidate/'build/qa/transpose-candidate-1'),str(output),commit,'--allow-local-browser']
with log.open('xb') as f:
    child=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
    state.update(status='running',pid=child.pid);save(state)
    result=child.wait()
state.update(status='producer-exited',exitCode=result,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save(state)
print(json.dumps(state));sys.exit(result)
