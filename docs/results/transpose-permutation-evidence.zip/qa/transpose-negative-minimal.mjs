import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {runtimeFixture} from '../../../test/runtime-fixture.mjs';
import {tflite as s} from '../../../vendor/netron/tflite-schema.js';
import {FlatbufferWriter} from '../../../src/flatbuffer-writer.js';
import {parseModel} from '../../../src/model-engine.js';
import {validateTfliteConstants} from '../../../src/tflite-constant-checks.js';
const metadata=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',import.meta.url),'utf8'));
const cases=[];
for(const [name,values,output,legal] of [['positive',[0],[1],true],['negative',[-1],[1],true],['out-of-range',[-2],[1],false]]){
 const {model}=await runtimeFixture({inputShapes:[[1],[values.length]],outputShape:output}),g=model.subgraphs[0];
 model.operator_codes[0].builtin_code=s.BuiltinOperator.TRANSPOSE;model.operator_codes[0].deprecated_builtin_code=s.BuiltinOperator.TRANSPOSE;
 const bytes=new Uint8Array(values.length*4),dv=new DataView(bytes.buffer);values.forEach((v,i)=>dv.setInt32(i*4,v,true));model.buffers.push({data:bytes,offset:0n,size:0n});Object.assign(g.tensors[1],{buffer:1,type:2});g.inputs=Int32Array.of(0);g.operators[0].builtin_options=null;
 const blob=new FlatbufferWriter().finish(model,new Blob()),raw=new Uint8Array(await blob.arrayBuffer()),index=await parseModel((o,n)=>raw.subarray(o,o+n),raw.length,metadata);
 await writeFile(new URL(`transpose-negative-minimal-${name}.tflite`,import.meta.url),raw,{flag:'wx'});
 const rt=index.raw.subgraphs[0].tensors[1],rb=index.raw.buffers[rt.buffer],actual=new DataView(raw.buffer,raw.byteOffset+Number(rb.offset),Number(rb.size));assert.equal(actual.getInt32(0,true),values[0]);
 let proof,error;try{proof=validateTfliteConstants(index.raw,0,(o,n)=>raw.subarray(o,o+n));}catch(e){error=e.message;assert.match(error,/Subgraph #0.*OP #0.*tensor #1/);}
 cases.push({name,values,output,legalForPinnedKernel:legal,accepted:!error,proof,error,fileBytes:raw.length});
}
assert.ok(cases.find(c=>c.name==='positive').accepted);
assert.ok(cases.filter(c=>!c.legalForPinnedKernel).every(c=>!c.accepted));
const rejectedLegal=cases.filter(c=>c.legalForPinnedKernel&&!c.accepted);
const report={status:rejectedLegal.length?'red-valid-negative-permutation-rejected':'passed-static-controls',at:new Date().toISOString(),cases,primaryReference:'tensorflow/tensorflow@7bc5d217d3bd79426527d0055fd3b54812f52e93:transpose.cc',runtimeCPU:'not-yet-evaluated;do-not-claimcurrentLiteRTacceptance',scope:'Actual FlatBuffer writer/parser andactualboundedconstantvalidation;no appmodification,no browser andno inference.'};
await writeFile(new URL('transpose-negative-minimal.json',import.meta.url),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));process.exitCode=rejectedLegal.length?1:0;
