import datetime, hashlib, json, os, pathlib, struct, zipfile
q=pathlib.Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()

class Flatbuffer:
    """Independent bounded reader for the actual tiny synthetic download only."""
    def __init__(self,data):
        assert 8<len(data)<65536 and data[4:8]==b'TFL3';self.data=data;self.root=self.num(0,'I')
    def num(self,pos,fmt):return struct.unpack_from('<'+fmt,self.data,pos)[0]
    def field(self,table,slot):
        vt=table-self.num(table,'i');entry=4+2*slot
        if entry>=self.num(vt,'H'):return None
        off=self.num(vt+entry,'H');return table+off if off else None
    def scalar(self,table,slot,fmt='I',default=0):
        pos=self.field(table,slot);return self.num(pos,fmt) if pos else default
    def vector(self,table,slot,tables=False,fmt='i'):
        pos=self.field(table,slot)
        if not pos:return []
        pos+=self.num(pos,'I');count=self.num(pos,'I');assert count<1024
        if tables:return [p+self.num(p,'I') for p in range(pos+4,pos+4+4*count,4)]
        size=struct.calcsize(fmt);return [self.num(pos+4+i*size,fmt) for i in range(count)]
    def check(self):
        codes=self.vector(self.root,1,True);graphs=self.vector(self.root,2,True);buffers=self.vector(self.root,4,True)
        assert len(graphs)==1;g=graphs[0];ts=self.vector(g,0,True);ops=self.vector(g,3,True)
        assert len(ops)==3 and self.vector(g,1)==[0] and self.vector(g,2)==[3,4]
        signatures=[]
        for op in ops:
            code=codes[self.scalar(op,0)];builtin=max(self.scalar(code,3,'i'),self.scalar(code,0,'b'))
            signatures.append((builtin,self.vector(op,1),self.vector(op,2)))
        assert signatures==[(39,[0,1],[2]),(0,[2,2],[3]),(0,[2,2],[4])],signatures
        perm=ts[1];assert self.scalar(perm,1,'b')==2 and self.vector(perm,0)==[2]
        buf=buffers[self.scalar(perm,2)];offset=self.scalar(buf,1,'Q');size=self.scalar(buf,2,'Q')
        payload=self.data[offset:offset+size] if size else bytes(self.vector(buf,0,fmt='B'))
        assert payload==struct.pack('<ii',-1,0)
        assert self.vector(ts[0],0)==[2,3] and all(self.vector(ts[i],0)==[3,2] for i in [2,3,4])
        return {'ports':signatures,'permutation':[-1,0],'inputShape':[2,3],'outputShape':[3,2]}

expected_commit='4b0822e0df200bfb969a8fa7ea7ab9d387d98484';expected_build='32a2194e23e040a1'
red=json.loads((q/'transpose-native-red/report.json').read_bytes())
assert red['status']=='reproduced-original-export-rejection' and len(red['browsers'])==2
assert all(b['status']=='reproduced-negative-export-rejection' and b['downloads']==0 and b['browserClosed'] and b['processCleanup']['allReaped'] for b in red['browsers'])
cases=[]
for folder,channel,normal in [('transpose-native-green','chrome',False),('transpose-native-edge','msedge',True)]:
    directory=q/folder;raw=(directory/'report.json').read_bytes();r=json.loads(raw);assert r['release']['source']['commit']==expected_commit and not r['release']['source']['dirty'] and r['release']['buildId']==expected_build
    assert len(r['browsers'])==1;b=r['browsers'][0];assert b['channel']==channel and b['errors']==[] and b['downloads']==2 and b['searchMatches']==1
    assert b['layout']=={'width':1280,'scrollWidth':1280,'editFont':'32','graphFont':'32'}
    assert len(b['workers'])==5 and all(w['closed'] for w in b['workers'])
    assert sum('/tflite-runtime-worker.js' in w['url'] for w in b['workers'])==1
    model=(directory/(channel+'-negative-edited.tflite')).read_bytes();assert len(model)==b['export']['bytes']==1976 and sha(model)==b['export']['sha256']
    decoded=Flatbuffer(model).check()
    io=(directory/(channel+'-negative-io.zip')).read_bytes();assert len(io)==b['io']['bytes'] and sha(io)==b['io']['sha256']
    with zipfile.ZipFile(directory/(channel+'-negative-io.zip')) as z:
        assert z.testzip() is None and sorted(z.namelist())==['inputs-0.bin','manifest.json','outputs-0.bin','outputs-1.bin']
        manifest=json.loads(z.read('manifest.json'));assert manifest['modelSHA256']==sha(model) and manifest['validation']['status']=='passed' and manifest['validation']['compiled'] and manifest['validation']['invoked']
        assert struct.unpack('<6f',z.read('inputs-0.bin'))==(1.,2.,3.,4.,5.,6.)
        for name in ['outputs-0.bin','outputs-1.bin']:
            assert struct.unpack('<6f',z.read(name))==(2.,8.,4.,10.,6.,12.)
    log=(q/(folder+'.log')).read_text('utf-8')
    if normal:
        assert r['status']=='passed-native-negative-export-regression' and b['status']=='passed-negative-edit-export-reopen-search-cpu'
        assert b['browserClosed'] and b['processCleanup']['allReaped'] and not b['processCleanup']['remaining']
        assert '<process did exit: exitCode=0, signal=null>' in log and '<will force kill>' not in log and '<kill>' not in log
    else:
        assert r['status']==b['status']=='failed-flow' and 'exceeded10s' in b['error'] and not b.get('browserClosed')
        assert '<will force kill>' in log and '<process did exit: exitCode=1, signal=null>' in log
    cases.append({'channel':channel,'functionalChecks':'passed','normalClose':'passed' if normal else 'failed-original-10s-limit','wholeAttempt':'passed' if normal else 'failed','reportSHA256':sha(raw),'modelSHA256':sha(model),'ioSHA256':sha(io),'decoded':decoded,'nativeWorkerCloses':len(b['workers'])})
assert cases[0]['modelSHA256']==cases[1]['modelSHA256']
result={'format':'model-lens-transpose-native-review','version':1,'status':'functional-correction-proved-chrome-normal-close-remains-failed','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidateCommit':expected_commit,'candidateBuild':expected_build,'originalNativeRedBrowsers':2,'cases':cases,'scope':'Both actual edited model downloads independently decoded; all IO ZIP CRC/bytes/numbers verified. Chrome whole attempt remains failed; SDK force cleanup is not normal close. No private-model root cause or future memory guarantee.'}
with (q/'transpose-native-review.json').open('x',encoding='utf-8') as f:
    json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(result))
