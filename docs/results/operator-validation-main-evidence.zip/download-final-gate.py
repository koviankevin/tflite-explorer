import base64,datetime,hashlib,io,json,os,pathlib,sys,urllib.request,zipfile
q=pathlib.Path(__file__).resolve().parent;kind=sys.argv[1];assert kind in ['browser','contract','site']
meta=json.loads((q/f'op-final-{kind}-artifacts.json').read_bytes());assert meta['total_count']==len(meta['artifacts']) and len(meta['artifacts'])<=4
run=json.loads((q/f'op-final-{kind}-run.json').read_bytes());assert run['status']=='completed' and run['conclusion']=='success' and run['head_sha']=='c6c36d45f81fd339c8bda97deb9b218da7faef4b'
prefix={'browser':'browser-lifecycle','contract':'release-contract','site':'versioned-site-browser'}[kind]
items=[a for a in meta['artifacts'] if a['name']==f'{prefix}-{run["head_sha"]}-{run["run_attempt"]}'];assert len(items)==1
a=items[0];assert not a['expired'] and 0<a['size_in_bytes']<4*1024**2
dest=q/f'op-final-{kind}-artifact.zip';report=q/f'op-final-{kind}-report.json'
assert not dest.exists() and not report.exists()
intent={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'operation':'download-provider-artifact-for-local-verification','artifact':a['id'],'kind':kind,'outputs':[str(dest),str(report)],'expectedDigest':a['digest'],'credentialHandling':'Connector download reference is transient,never printed or saved','cleanup':'Retain bounded original ZIP and raw JSON; no cleanup authorised'}
with (q/f'op-final-{kind}-download-intent.json').open('x',encoding='utf-8') as f:json.dump(intent,f,indent=2);f.flush();os.fsync(f.fileno())
url=base64.b64decode(sys.argv[2]).decode('utf-8');assert url.startswith('https://')
with urllib.request.urlopen(url,timeout=30) as r:raw=r.read(4*1024**2+1)
del url
assert len(raw)==a['size_in_bytes'] and 'sha256:'+hashlib.sha256(raw).hexdigest()==a['digest']
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert len(z.namelist())==1 and z.testzip() is None
    name=z.namelist()[0];assert '/' not in name and '\\' not in name and name.endswith('.json')
    data=z.read(name);assert len(data)<4*1024**2;parsed=json.loads(data)
for p,b in [(dest,raw),(report,data)]:
    with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
print(json.dumps({'kind':kind,'artifact':a['id'],'bytes':len(raw),'digest':a['digest'],'status':parsed.get('status'),'source':{k:parsed.get('source',{}).get(k) for k in ['commit','tree','dirty']},'counts':parsed.get('counts')}))
