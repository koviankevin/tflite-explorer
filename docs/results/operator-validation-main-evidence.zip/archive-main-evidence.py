from pathlib import Path
import json,zipfile,hashlib,datetime
q=Path(__file__).resolve().parent;repo=q.parents[3]/'tflite-explorer-transpose'
load=lambda n:json.loads((q/n).read_text(encoding='utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
source='c6c36d45f81fd339c8bda97deb9b218da7faef4b';tree='1db3085be359df76c7d129cfd03938caca895340'
reviews={k:load(f'op-final-{k}-review.json') for k in ['browser','contract','site']}
for kind,r in reviews.items():assert r['status']=='passed-original-gate-review' and r['source']==source and r['tree']==tree
core=load('op-core-review.json');assert core['status']=='core-evidence-reused-after-original-policy-review' and core['candidate']==source and core['files']==88
smoke=load('op-final-delivery-smoke-review.json');assert smoke['status']=='passed-reviewed' and smoke['source']==source and smoke['checks']==35
raw_smoke=load('op-final-delivery-smoke.json');assert raw_smoke['operatorValidation']['cases'][-1]['operators']==21006 and raw_smoke['operatorValidation']['automaticRuntimeWorkers']==0
browser=load('op-final-browser-report.json');assert browser['status']=='passed' and len(browser['cycles'])==8 and browser['fixture']['bytes']==1349965216 and browser['fixture']['operators']==21005 and browser['browserClosed'] and browser['processCleanup']['allReaped']
assert all(w['closed'] for w in browser['workerClosures']) and all(w['closed'] for w in raw_smoke['workers'])
assert browser['evaluation']['status']=='passed' and not browser['evaluation']['issues']
out=repo/'docs/results/operator-validation-main-evidence.zip';receipt=repo/'docs/results/operator-validation-main.json';assert not out.exists() and not receipt.exists()
patterns=['op-core-*','op-final-*','op-main-*','pr190-*','pr191-*','pr192-*']
names=set()
for pattern in patterns:
 for p in q.glob(pattern):
  if p.is_file() and p.suffix in ['.json','.zip','.png']:names.add(p.name)
for n in ['main-gate-dispatch.json','main-prefix-gate-dispatch.json','main-final-gate-dispatch.json','main-browser-failed.zip','main-browser-failed-report.json','main-browser-failed-job.json','main-prefix-browser-job-log.json','core-scope-review.json','core-prefix-scope-review.json','review-main-gate.mjs','review-final-gate.mjs','review-core-reuse.mjs','review-final-delivery-smoke.mjs','download-final-gate.py','download-final-smoke.py','archive-main-evidence.py']:
 assert (q/n).is_file();names.add(n)
members=[]
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name in sorted(names):
  data=(q/name).read_bytes();z.writestr(name,data);members.append(dict(path=name,bytes=len(data),sha256=sha(data)))
 for name,p in [('licenses/LICENSE-ModelLens.txt',repo/'LICENSE'),('licenses/LICENSE-Netron.txt',repo/'vendor/netron/LICENSE'),('licenses/LICENSE-Apache-2.0.txt',repo/'vendor/litert/2.6.0/LICENSE')]:
  data=p.read_bytes();z.writestr(name,data);members.append(dict(path=name,bytes=len(data),sha256=sha(data)))
 note=b'Readers are retained for audit. Run them from the matching repository checkout; do not execute untrusted provider artifacts. Source archives and small synthetic Windows models remain in the two linked candidate evidence ZIPs. This archive contains metadata-only physical reports, not 1.25GiB model files. Apache-2.0 license also covers TensorFlow kernel references in operator-validation-candidate-evidence.zip.\n'
 z.writestr('REPLAY.txt',note);members.append(dict(path='REPLAY.txt',bytes=len(note),sha256=sha(note)))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None and len(z.namelist())==len(members)
 for m in members:assert sha(z.read(m['path']))==m['sha256']
r=dict(format='model-lens-operator-validation-main',status='all-four-gates-reviewed-not-published',source=source,tree=tree,version='1.3.0',core=core,gates=reviews,site=smoke,physical=dict(bytes=browser['fixture']['bytes'],operators=21005,cycles=8,evaluation=browser['evaluation'],workerClosures=len(browser['workerClosures']),allWorkersClosed=True,processCleanup=browser['processCleanup']),nodePR=dict(pr=192,tests=877,passCount=842,fail=0,skipped=35,checkout='5b0974d22b8d2cee50c569e0b7966871b1b55fd2',tree=tree),archive=dict(file=out.name,bytes=out.stat().st_size,sha256=sha(out.read_bytes()),members=members),limits=['No public Pages/Release promotion yet.','Windows native functional reports retain their own earlier source; Chrome normal-close10s failure remains unresolved.','Finite public fixtures do not verify arbitrary kernels, company dialects/runtime, OS power failure or full accessibility.'])
receipt.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=r['status'],members=len(members),archiveBytes=out.stat().st_size,sha256=r['archive']['sha256'],physicalEvaluation=r['physical']['evaluation'])))
