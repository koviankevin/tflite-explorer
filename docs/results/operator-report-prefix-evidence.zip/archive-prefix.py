from pathlib import Path
import json,hashlib,zipfile,datetime
q=Path(__file__).resolve().parent
repo=q.parents[3]/'tflite-explorer-transpose'
out=repo/'docs/results/operator-report-prefix-evidence.zip'
receipt=repo/'docs/results/operator-report-prefix.json'
assert not out.exists() and not receipt.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
chrome=json.loads((q/'chrome-3/report.json').read_text(encoding='utf-8'))
edge=json.loads((q/'msedge-3/report.json').read_text(encoding='utf-8'))
expected='e18e27ee3eece79a20151ca326b5a9d2b9099f2c'
assert chrome['source']==edge['source'] and edge['source']['commit']==expected and not edge['source']['dirty']
assert chrome['status']=='failed' and chrome['functionalStatus']=='passed' and 'normal browser.close exceeded10s' in chrome['error']
assert edge['status']=='passed' and edge['browserClosed'] and edge['processCleanup']['allReaped'] and not edge['processCleanup']['remaining']
for folder,r in [('chrome-3',chrome),('msedge-3',edge)]:
    assert r['flow']['modelWorkers']==5 and r['flow']['automaticRuntimeWorkers']==0 and not r['errors'] and all(w['closed'] for w in r['workers'])
    assert [(c['name'],c['status']) for c in r['flow']['cases']]==[('SPLIT','passed'),('PAD','not-run'),('SLICE','rejected'),('Large','mixed')]
    large=r['flow']['cases'][-1];assert large['operators']==21006 and large['visibleReportRows']==200
    for name in ['SPLIT','PAD','Large']:
        record=json.loads((q/folder/f'operand-{name}.report.json').read_text(encoding='utf-8'))
        a=(q/folder/f'operand-{name}-source.tflite').read_bytes();b=(q/folder/f'operand-{name}-edited.tflite').read_bytes()
        c=next(c for c in r['flow']['cases'] if c['name']==name);assert sha(b)==c['outputSHA256']
        assert len(record['operatorValidation'])==(21006 if name=='Large' else 2)
        if name=='Large':assert len(a)<16*1024**2 and record['operatorSummary']['checked']==21000 and record['operatorSummary']['unchecked']==6
        for p in record['provenance']['ranges']:
            x,y,n=p['sourceOffset'],p['outputOffset'],p['bytes'];assert len(b[y:y+n])==n and a[x:x+n]==b[y:y+n]
failed=(q/'main-browser-failed.zip').read_bytes();assert len(failed)==3587 and sha(failed)=='241474e34a5c0bec58f7c2a8ae17c89af94e114ece328e838d3e7b047bb08b7c'
r=json.loads((q/'main-browser-failed-report.json').read_text(encoding='utf-8'));assert r['status']=='failed' and r['environment']['sourceCommit']=='adf7ef74ab2bc987d61686489720aa897f217f5a'
assert 'Blob.text' in r['audit']['audit']['violations'] and r['audit']['audit']['maxRead']==6688889
assert 'main thread must not re-read the report Blob' in (q/'report-read-red.log').read_text(encoding='utf-8')
assert 'pass 21' in (q/'report-prefix-fixed.log').read_text(encoding='utf-8')
members=[]
for name in ['report-prefix-plan.json','main-browser-failed.zip','main-browser-failed-report.json','main-browser-failed-job.json','report-read-red.log','report-read-fixed.log','report-prefix-fixed.log','chrome-3.log','msedge-3.log','archive-prefix.py']:
    p=q/name;assert p.is_file();members.append((name,p))
for folder in ['chrome-3','msedge-3']:
    for p in sorted((q/folder).iterdir()):assert p.is_file() and not p.is_symlink();members.append((folder+'/'+p.name,p))
rows=[]
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in members:
        b=p.read_bytes();z.writestr(name,b);rows.append({'path':name,'bytes':len(b),'sha256':sha(b)})
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for r in rows:assert sha(z.read(r['path']))==r['sha256']
record={'format':'model-lens-operator-report-prefix','status':'reviewed-candidate-not-published','source':edge['source'],'release':edge['release'],'targetedTests':{'pass':21,'fail':0,'largeReportOperators':21005,'runtimeStatusAttachments':3,'reportBodyReads':0},'failure':{'run':41210387448,'artifact':13046296557,'source':'adf7ef74ab2bc987d61686489720aa897f217f5a','rootCause':'main realm attachRuntimeReport rereads 6688889-byte generated report with Blob.text; original physical audit rejects it before download'},'native':{'chrome':{'functional':'passed','normalClose':'failed-10s','wholeAttempt':'failed'},'msedge':{'functional':'passed','normalClose':'passed','wholeAttempt':'passed'},'perBrowser':{'modelWorkers':5,'automaticRuntimeWorkers':0,'largeReportOperators':21006,'visibleRowsAfterNext':200,'fixtureScope':'same full structure with 64-byte payload; not physical >1GiB'}},'archive':{'file':out.name,'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'members':rows},'remaining':['Protected PR and all affected main gates.','Real >1GiB eight cycles on corrected source.','Prepared/published site and immutable Release verification.','Historical Windows Chrome native-close root cause.']}
receipt.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':record['status'],'members':len(rows),'bytes':out.stat().st_size,'sha256':record['archive']['sha256']}))
