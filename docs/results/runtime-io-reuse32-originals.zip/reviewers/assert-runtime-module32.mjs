import assert from 'node:assert/strict';
import path from 'node:path';
import {sha256} from '../../scripts/lib/release-artifact.mjs';
import {runtimeLoopFixture} from '../../test/runtime-loop-fixture.mjs';

// Read-only independent assertions against provider originals. No report
// rewriting, synthetic native close, adjusted baseline or waived RSS failure.
export async function assertRuntimeModuleWarm32(r){
    const fixture=await runtimeLoopFixture(true),digest=sha256(fixture.bytes),workerURL=name=>new URL(r.coreBasePath+`src/${name}.js?v=${r.expectedBuild}`,r.base).href;
    function temp(record,name,task){
        assert.equal(record.status,'removed');assert.equal(record.directoryRemoved,true);assert.equal(record.bytes,fixture.bytes.length);assert.equal(record.sha256,digest);assert.equal(record.identity.size,fixture.bytes.length);
        assert.match(record.directory,/^\/tmp\/model-lens-network-file-[a-zA-Z0-9]+$/);assert.equal(record.path,path.posix.join(record.directory,name));assert.equal(record.events.length,8);assert.equal(new Set(record.events.map(e=>e.operation_id)).size,8);
        for(const target of ['file','directory'])assert.deepEqual(record.events.filter(e=>e.artifact_id===record.id+'-'+target).map(e=>e.event),['create_intent','created','delete_intent','removed']);
        for(const event of record.events){assert.equal(event.task_id,task);assert.equal(event.producer,'test/browser/public-control-file.mjs');assert.deepEqual(event.inputs,{bytes:fixture.bytes.length,sha256:digest});assert.ok(Number.isFinite(Date.parse(event.timestamp)));}
    }
    const t=r.tfliteRuntime,w=t.warmCancellation;assert.equal(t.sharedRuntimeModuleRequired,true);assert.equal(w.networkHeld,false);assert.equal(w.fakeTimers,false);assert.equal(w.additionalModelWorkers,2);temp(w.fixture,'warm-cancel.tflite','runtime-warm-cancel');assert.deepEqual(w.invocations.map(x=>x.kind),['manual-cancel','model-tab-switch']);
    for(const [i,clicked] of [w.cancelClickedAt,w.tabCloseClickedAt].entries()){
        const invocation=w.invocations[i],worker=t.workers[invocation.workerIndex];assert.equal(worker.url,workerURL('tflite-runtime-worker'));assert.equal(worker.closed,true);assert.ok(invocation.invokeObservedAt>=worker.createdObservedAt&&invocation.invokeObservedAt<=clicked&&clicked<=worker.closeObservedAt);assert.ok(worker.closeObservedAt-clicked<5000);
    }
    assert.equal(w.modelWorker.closed,true);assert.ok(w.modelWorker.createdObservedAt<=w.invocations[0].invokeObservedAt&&w.modelWorker.closeObservedAt>=w.tabCloseClickedAt);
    const g=r.usageGuide,b=g.busyExecution,c=g.busyCompletion;assert.equal(g.sharedRuntimeModuleRequired,true);assert.equal(b.networkHeld,false);assert.equal(b.fakeTimers,false);assert.equal(b.deadlineMs,30000);temp(b.fixture,'guide-busy.tflite','usage-guide-busy');assert.deepEqual(Object.fromEntries(Object.entries(c).filter(([k])=>k!=='completedObservedAt')),{wasDisabled:true,status:'not-verified',reason:'actual30s-timeout',guideOpen:true,reEnabled:true});
    assert.equal(g.runtimeWorkers.length,2);const busy=g.runtimeWorkers[1];assert.equal(busy.url,workerURL('tflite-runtime-worker'));assert.equal(busy.closed,true);assert.ok(busy.createdObservedAt<=b.invokeObservedAt&&b.invokeObservedAt<=b.disabledObservedAt&&b.disabledObservedAt<busy.closeObservedAt&&busy.closeObservedAt<=c.completedObservedAt);assert.ok(busy.closeObservedAt-busy.createdObservedAt>=25000&&busy.closeObservedAt-busy.createdObservedAt<=40000);assert.ok(b.modelClosedObservedAt>=busy.closeObservedAt);assert.equal(g.modelWorkers.length,5);assert.equal(g.modelWorkers[1].closeObservedAt,b.modelClosedObservedAt);
    return {warmRealInvokes:2,warmGuideDeadline:true,publicFixturesRemoved:2};
}
export async function assertRuntimeModule32(r){
    const warm=await assertRuntimeModuleWarm32(r),workerURL=name=>new URL(r.coreBasePath+`src/${name}.js?v=${r.expectedBuild}`,r.base).href;
    assert.equal(r.runtimeModuleColdRequired,true);const cold=r.runtimeModuleCold;assert.equal(cold.format,'model-lens-runtime-module-cold');assert.equal(cold.version,1);assert.equal(cold.status,'passed',cold.error);assert.equal(cold.modelSHA256,r.staticVerification.checks.find(x=>x.path==='demo.tflite').sha256);assert.equal(cold.beforeOpenAssetGETs,0);assert.equal(cold.beforeRunAssetGETs,0);assert.equal(cold.workerContextProbe,1);assert.equal(cold.cancelled,true);assert.equal(cold.cancelledDownloadDisabled,true);assert.equal(cold.contextClosed,true);assert.equal(cold.downloads,0);assert.deepEqual(cold.errors,[]);
    const asset=new URL(r.coreBasePath+'vendor/litert/2.6.0/litert_wasm_compat_internal.wasm',r.base).href;assert.equal(cold.assetGETs,1);assert.equal(cold.requests.filter(x=>x.url===asset).length,1);assert.ok(cold.requests.every(x=>x.allowed&&x.method==='GET'&&x.url.startsWith(r.base)));
    assert.deepEqual(cold.workers.map(x=>x.kind).sort(),['model','runtime','runtime','runtime']);for(const worker of cold.workers){assert.equal(worker.url,workerURL(worker.kind==='model'?'model-worker':'tflite-runtime-worker'));assert.equal(worker.closed,true);assert.ok(worker.closeObservedAt>=worker.createdObservedAt);}
    const clock=cold.timing,ordered=['assetHeldAt','workerProbeAt','cancelClickedAt','cancelledAt','assetReleasedAt','responseFinishedAt','contextClosedAt'];for(const [i,name]of ordered.entries()){assert.ok(Number.isFinite(clock[name]));if(i)assert.ok(clock[name]>=clock[ordered[i-1]]);}
    const runtime=cold.workers.filter(x=>x.kind==='runtime');assert.ok(runtime[0].createdObservedAt<=clock.workerProbeAt&&runtime[0].closeObservedAt>=clock.cancelClickedAt&&runtime[0].closeObservedAt<=clock.cancelledAt&&runtime[0].closeObservedAt-clock.cancelClickedAt<5000);assert.equal(cold.runs.length,2);for(const [i,run]of cold.runs.entries()){assert.equal(run.status,'passed');assert.ok(runtime[i+1].createdObservedAt>=clock.responseFinishedAt&&run.finishedObservedAt>=runtime[i+1].closeObservedAt);}
    assert.equal(cold.inputCleanup.length,3);assert.deepEqual(cold.inputCleanup.map(x=>x.kind),['not-verified','passed','passed']);for(const {kind,...state}of cold.inputCleanup)assert.deepEqual(state,{open:false,controls:0,fileInputs:0,callbackCleared:true,error:''});
    return {...warm,coldAssetGETs:1,coldRuntimeCloses:3,coldModelCloses:1,coldInputCleanups:3};
}
