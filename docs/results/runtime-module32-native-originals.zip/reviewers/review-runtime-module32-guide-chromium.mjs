import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {gitSource,sha256,verifyArtifact} from '../../scripts/lib/release-artifact.mjs';
import {assertReport} from '../../scripts/lib/release-gates.mjs';
const [id,head,build,label='final']=process.argv.slice(2),source=gitSource();assert.match(id,/^\d+$/);assert.match(head,/^[a-f0-9]{40}$/);assert.match(label,/^[a-z0-9-]+$/);assert.equal(source.commit,head);assert.equal(source.dirty,false);
const built=await verifyArtifact(build,{publicOnly:true,expectedCommit:head,requireClean:true});assert.deepEqual(built.release.source,source);assert.equal(built.release.version,'0.2.0-preview.32');
const call=(route,binary=false)=>execFileSync(process.env.GH_BIN,['api','repos/koviankevin/tflite-explorer/'+route],{encoding:binary?undefined:'utf8',maxBuffer:8*1024**2,windowsHide:true,timeout:60000}),json=route=>JSON.parse(call(route));
const run=json(`actions/runs/${id}`),jobs=json(`actions/runs/${id}/attempts/1/jobs?per_page=100`),listing=json(`actions/runs/${id}/artifacts?per_page=100`);
assert.equal(run.status,'completed');assert.ok(['success','failure'].includes(run.conclusion));assert.equal(run.run_attempt,1);assert.equal(run.path,'.github/workflows/production-smoke.yml');assert.equal(run.head_branch,'main');assert.equal(run.head_sha,head);assert.equal(run.event,'workflow_dispatch');assert.equal(run.head_repository.full_name,'koviankevin/tflite-explorer');assert.equal(jobs.total_count,jobs.jobs.length);assert.equal(listing.total_count,listing.artifacts.length);
const job=jobs.jobs.find(j=>j.name==='site-upgrade');assert.equal(job.status,'completed');assert.equal(job.run_attempt,1);assert.equal(job.head_sha,head);
const directory=`build/qa/runtime-module32-guide-chromium-${id}-${label}`;await mkdir(directory);for(const [name,value]of Object.entries({run,jobs,listing}))await writeFile(`${directory}/${name}.json`,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
async function archive(name,stem,jsonName){
 const matches=listing.artifacts.filter(a=>a.name===name);assert.equal(matches.length,1);const artifact=matches[0];assert.equal(artifact.expired,false);assert.equal(artifact.workflow_run.id,Number(id));assert.equal(artifact.workflow_run.head_sha,head);assert.ok(artifact.size_in_bytes>0&&artifact.size_in_bytes<=4*1024**2);assert.ok(Date.parse(artifact.created_at)>=Date.parse(job.started_at)&&Date.parse(artifact.created_at)<=Date.parse(job.completed_at)+1000);
 const bytes=call(`actions/artifacts/${artifact.id}/zip`,true);assert.equal(bytes.length,artifact.size_in_bytes);assert.equal('sha256:'+sha256(bytes),artifact.digest);await writeFile(`${directory}/${stem}.zip`,bytes,{flag:'wx'});await writeFile(`${directory}/${stem}-artifact.json`,JSON.stringify(artifact,null,2)+'\n',{flag:'wx'});
 const allowed=[jsonName,jsonName.replace(/\.json$/,'.png')],py=`import io,sys,json,zipfile,hashlib,pathlib
z=zipfile.ZipFile(io.BytesIO(sys.stdin.buffer.read()));items=z.infolist();allowed=${JSON.stringify(allowed)}
assert 1<=len(items)<=2 and len(set(z.namelist()))==len(items) and ${JSON.stringify(jsonName)} in z.namelist()
assert set(z.namelist())<=set(allowed)
assert all(0<i.file_size<=4*1024**2 and not i.is_dir() for i in items)
assert z.testzip() is None
rows=[]
for i in items:
 b=z.read(i)
 with open(pathlib.Path(sys.argv[1])/i.filename,'xb') as f:f.write(b)
 rows.append({'name':i.filename,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
print(json.dumps(rows))`;
 const members=JSON.parse(execFileSync(process.env.PYTHON_BIN,['-I','-c',py,directory],{input:bytes,encoding:'utf8',maxBuffer:4*1024**2,windowsHide:true}));return {artifact,members,report:JSON.parse(await readFile(`${directory}/${jsonName}`,'utf8'))};
}
const site=await archive(`versioned-site-browser-${head}-1`,'site','versioned-site-browser.json');assertReport(site.report,'site',run,source.tree);assert.equal(site.report.sourceUnchanged,true);
const native=await archive(`versioned-delivery-smoke-${head}-1`,'native','production-smoke.json'),r=native.report;
assert.equal(r.driverSourceCommit,head);assert.deepEqual(r.siteRelease,built.release);assert.equal(r.expectedBuild,built.release.buildId);assert.equal(r.target,'isolated-versioned-snapshot');assert.equal(r.status==='passed'?'success':'failure',job.conclusion);assert.deepEqual(r.errors,[]);

assert.equal(r.status,'passed',r.error);assert.equal(run.conclusion,'success');assert.equal(job.conclusion,'success');assert.equal(r.checks.length,33);assert.deepEqual(r.errors,[]);assert.equal(r.tfliteRuntime.cases.length,19);assert.equal(r.usageGuide.cases.length,5);assert.equal(r.runtimeModuleCold.status,'passed');assert.equal(r.runtimeModuleCold.assetGETs,1);assert.equal(r.runtimeModuleCold.contextClosed,true);assert.equal(r.runtimeModuleCold.workers.filter(w=>w.kind==='runtime').length,3);assert.ok(r.runtimeModuleCold.workers.every(w=>w.closed));
const models=r.workers.filter(w=>/\/model-worker\.js(?:\?|$)/.test(w.url)),runtimes=r.workers.filter(w=>/\/tflite-runtime-worker\.js(?:\?|$)/.test(w.url));assert.equal(models.length,86);assert.equal(runtimes.length,44);assert.ok(r.workers.every(w=>w.closed));
const {evaluateRuntimeLifecycle}=await import('../../test/browser/runtime-lifecycle-policy.mjs'),{assertInputCleanup31}=await import('./assert-input-cleanup31.mjs'),{assertActiveCompute31}=await import('./assert-active-compute31.mjs');const inputCleanup=assertInputCleanup31(r,true),evaluation=evaluateRuntimeLifecycle(r.runtimeLifecycle);assert.equal(evaluation.status,'passed');assert.deepEqual(r.runtimeLifecycle.evaluation,evaluation);
const model=await import('../../test/runtime-memory-fixture.mjs'),fixture=await model.runtimeMemoryFixture();assert.equal(r.runtimeLifecycle.fixture.modelSHA256,sha256(fixture.bytes));for(const c of r.runtimeLifecycle.cycles){assert.equal(c.io.inputSHA256,sha256(new Uint8Array(new Float32Array(model.RUNTIME_MEMORY_ELEMENTS).fill(c.io.input).buffer)));assert.equal(c.io.outputSHA256,sha256(new Uint8Array(model.runtimeMemoryValues(c.io.input).buffer)));assert.equal(c.io.crcVerified,true);}
for(const e of built.files){const observed=r.staticVerification.checks.find(c=>c.path===r.coreBasePath+e.path);assert.ok(observed,e.path);assert.equal(observed.bytes,e.bytes);assert.equal(observed.sha256,e.sha256);}
const first=models[0].url,suffix=r.coreBasePath+'src/model-worker.js?v='+r.expectedBuild;assert.ok(first.endsWith(suffix));const base=first.slice(0,-suffix.length);assert.match(base,/^http:\/\/127\.0\.0\.1:\d+\/tflite-explorer\/$/);const active=await assertActiveCompute31(r,{workerBase:base+r.coreBasePath+'src/'});
const {assertRuntimeModule32}=await import('./assert-runtime-module32.mjs');const moduleProof=await assertRuntimeModule32({...r,base,staticVerification:{...r.staticVerification,checks:built.files}});
assert.deepEqual(gitSource(),source);const receipt={authentication:'passed',acceptance:'passed-native-and-original-chromium-lifecycle',source,run:Number(id),buildId:built.release.buildId,siteArtifact:site.artifact.id,nativeArtifact:native.artifact.id,nativeSHA256:sha256(await readFile(directory+'/production-smoke.json')),checks:r.checks.length,runtimeCases:19,guideCases:5,modelsClosed:86,runtimesClosed:44,active,inputCleanup,moduleProof,lifecycle:evaluation,adapter:'Helper base and relative demo path are derived from authenticated workerURL/core snapshot. No observed status/counts/timing/RSS changed.'};await writeFile(directory+'/review.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));
