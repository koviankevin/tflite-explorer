import datetime,hashlib,json,os,pathlib,urllib.parse,urllib.request
q=pathlib.Path(__file__).resolve().parent
release=json.loads((q/'v1.3.1-release.json').read_bytes());prepared=json.loads((q/'v1.3.1-prepared-review.json').read_bytes())
assert release['tag_name']=='v1.3.1' and release['target_commitish']==prepared['source'] and not release['draft'] and not release['prerelease'] and len(release['assets'])==4
assert release['author']['login']=='github-actions[bot]'
dest=q/'v1.3.1-release-downloads';assert not dest.exists();dest.mkdir()
expected={a['name']:a for a in prepared['assets']};checks=[]
for a in release['assets']:
    e=expected[a['name']];assert a['size']==e['bytes'] and a['digest']=='sha256:'+e['sha256'] and a['state']=='uploaded'
    url=a['browser_download_url'];assert url.startswith('https://github.com/koviankevin/tflite-explorer/releases/download/v1.3.1/')
    part=dest/(a['name']+'.part');final=dest/a['name'];digest=hashlib.sha256();size=0
    with urllib.request.urlopen(url,timeout=30) as r,part.open('xb') as f:
        endpoint=urllib.parse.urlparse(r.geturl());assert endpoint.scheme=='https' and endpoint.hostname in ['github.com','release-assets.githubusercontent.com','objects.githubusercontent.com']
        while True:
            b=r.read(1024**2)
            if not b:break
            size+=len(b);assert size<=e['bytes'];digest.update(b);f.write(b)
        f.flush();os.fsync(f.fileno())
    assert size==e['bytes'] and digest.hexdigest()==e['sha256']
    assert part.resolve().parent==dest.resolve() and final.resolve().parent==dest.resolve() and not final.exists()
    os.replace(part,final);checks.append({'name':a['name'],'bytes':size,'sha256':digest.hexdigest()})
receipt={'status':'actual-four-public-release-downloads-match-prepared','releaseId':release['id'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks}
(q/'v1.3.1-release-download-review.json').open('x',encoding='utf-8').write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))

