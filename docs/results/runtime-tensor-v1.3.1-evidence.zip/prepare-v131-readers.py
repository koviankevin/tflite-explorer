import pathlib
q=pathlib.Path(__file__).resolve().parent;old=q.parents[3]/'tflite-explorer'/'build/qa/op-validation'
for base,new in [('download-v1.3.0-prepared-authorized.py','download-v131-prepared.py'),('extract-v1.3.0-prepared-corrected.py','extract-v131-prepared.py')]:
    text=(old/base).read_text(encoding='utf-8').replace('v1.3.0','v1.3.1').replace('1.3.0-','1.3.1-').replace('41215690135','41242199699').replace('7debc69df1a1c91e8ed3928a8a4932a493324180','8946d3473ae6952f12fd54d124f2d5f645b6c4a2')
    (q/new).open('x',encoding='utf-8').write(text)
text=(old/'review-v1.3.0-prepared-corrected.mjs').read_text(encoding='utf-8').replace('v1.3.0','v1.3.1').replace("version,'1.3.0'","version,'1.3.1'").replace('7debc69df1a1c91e8ed3928a8a4932a493324180','8946d3473ae6952f12fd54d124f2d5f645b6c4a2').replace('68f73b805636224b2023871f0edcab17c68dbf17','86227033a2e8fbe0b8d9ffdbe1a29de0e05de185')
text=text.replace("root=path.resolve(q,'../../..')+'-transpose'","root=path.resolve(q,'../../..')")
text=text.replace('v1.3.1-prepare-jobs.json','v1.3.1-prepare-jobs-raw.json')
text=text.replace("assert.equal(run.id,(await load('v1.3.1-prepare-api-dispatch.json')).run)","assert.equal(run.id,41242199699)")
start=text.index("const core=await load('op-core-review.json');")
end=text.index("assert.deepEqual(receipt.gates.map",start)
text=text[:start]+"const expectedGates={};for(const kind of ['core','browser','contract','site'])expectedGates[kind]=await load('main-'+kind+'-review.json');\n"+text[end:]
text=text.replace("path.join(q,'../windows-large/v1.2.1-live-index.json')","path.join(q,'v1.3.0-live-index.json')")
text=text.replace("assert.ok(site.retainedBuildIds.includes('562c77efcc4288a9'))","assert.ok(site.retainedBuildIds.includes('44782d0412ebc0b8'))")
text=text.replace('d69754e5b6791ecd','562c77efcc4288a9')
text=text.replace('5288f32845cddd3553ffee92b45cf8971271346be5fec0e700744443d5c907a0','2a94efad4e9e905a49344335ca17c3efd9ecdcae2bd010a934e43274e77e2242')
(q/'review-v131-prepared.mjs').open('x',encoding='utf-8').write(text)
print('Prepared bounded download/extraction and independent full ZIP/site/gate/history review readers for exact v1.3.1 source.')

