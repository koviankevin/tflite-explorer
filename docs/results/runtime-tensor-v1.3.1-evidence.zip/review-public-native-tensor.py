import hashlib,json,pathlib,urllib.parse
q=pathlib.Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for c,n in [('chrome',8),('msedge',10)]:
    p=q/('windows-public-'+c)/'report.json';raw=p.read_bytes();r=json.loads(raw)
    assert r['status']=='failed' and r['functionalStatus']=='passed' and r['errors']==['Unexpected application network request']*2
    assert r['browserClosed'] and r['processCleanup']['allReaped'] and not r['processCleanup']['remaining'] and len(r['processCleanup']['identities'])==n
    assert r['release']['version']=='1.3.1' and r['release']['buildId']=='960b708cb9389164' and r['release']['source']['commit']=='8946d3473ae6952f12fd54d124f2d5f645b6c4a2'
    f=r['flow'];assert f['status']=='passed' and len(f['cases'])==3 and f['downloads']==0 and len(f['runtimeWorkers'])==1 and all(w['closed'] for w in r['workers'])
    assert f['located']['font']=='32' and f['located']['focus']=='0' and f['located']['query']=='#7' and '7' in f['located']['nodes']
    rows.append({'channel':c,'browserVersion':r['browserVersion'],'status':r['status'],'functionalStatus':r['functionalStatus'],'nativeIdentities':n,'browserClosed':True,'workers':len(r['workers']),'workersClosed':True,'rawReportSHA256':sha(raw),'cases':f['cases'],'located':f['located'],'guardDenials':2})
p=q/'windows-public-chrome-network-diagnostic'/'report.json';raw=p.read_bytes();r=json.loads(raw);denied=[]
assert r['status']=='failed' and r['functionalStatus']=='passed' and r['browserClosed'] and r['processCleanup']['allReaped'] and len(r['deniedRequests'])==2
for e in r['deniedRequests']:
    u=urllib.parse.urlparse(e['url']);assert u.scheme=='https' and u.hostname=='gc.kis.v2.scr.kaspersky-labs.com' and e['method']=='GET'
    denied.append({'origin':u.scheme+'://'+u.hostname,'resourceType':e['resourceType'],'method':e['method'],'pathClass':'main.js' if u.path.endswith('/main.js') else 'main.css','queryOmitted':True})
assert {e['resourceType'] for e in denied}=={'script','stylesheet'}
artifact=q/'v1.3.1-prepared-artifacts/snapshot/index.html';assert b'kaspersky' not in artifact.read_bytes().lower()
receipt={'format':'model-lens-public-native-tensor-review','status':'functional-and-native-close-passed-network-guard-failed','source':'8946d3473ae6952f12fd54d124f2d5f645b6c4a2','build':'960b708cb9389164','actualPublicHTTPS':True,'channels':rows,'followup':{'scope':'One predeclared Chrome diagnostic retaining the same abort predicate; not a repeated green acceptance attempt','status':'failed','functionalStatus':'passed','deniedRequests':denied,'rawReportSHA256':sha(raw),'rawReportLocalOnly':True,'artifactHTMLContainsKaspersky':False,'officialReference':'https://support.kaspersky.com/help/Kaspersky/Win21.7/en-US/201001.htm','inference':'Observed two Kaspersky script/style requests are consistent with browser-side security software injection and are absent from prepared HTML. This does not prove unrecorded first-attempt Edge requests identical.'},'securityPolicyChanged':False,'antivirusSettingsChanged':False,'modelsOrInputsUploaded':False,'overallWindowsAcceptancePassed':False,'historicalChromeLongLoadIssueFixed':False,'privacy':'Full original request URLs/query strings remain local; only origin/resource type and hashes are published.'}
(q/'public-native-tensor-review.json').open('x',encoding='utf-8').write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'channels':[{'channel':x['channel'],'functional':x['functionalStatus'],'overall':x['status'],'nativeIdentities':x['nativeIdentities']} for x in rows],'diagnosticOrigins':[e['origin'] for e in denied],'allRawProcessesGone':True}))

