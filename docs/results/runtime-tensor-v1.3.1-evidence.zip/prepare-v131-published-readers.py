import pathlib
q=pathlib.Path(__file__).resolve().parent;old=q.parents[3]/'tflite-explorer'/'build/qa/op-validation'
for original,target in [('download-v1.3.0-published.py','download-v131-published.py'),('check-v1.3.0-current-http.py','check-v131-current-http.py'),('review-v1.3.0-published.mjs','review-v131-published.mjs')]:
    text=(old/original).read_text(encoding='utf-8').replace('v1.3.0','v1.3.1').replace('41216245433','41242450193').replace('7debc69df1a1c91e8ed3928a8a4932a493324180','8946d3473ae6952f12fd54d124f2d5f645b6c4a2')
    text=text.replace('v1.3.1-publish-jobs.json','v1.3.1-publish-jobs-raw.json')
    text=text.replace('Exact published v1.2.0 native full8cycles passed;later candidate andemptyChromeclose failures remain unresolved. Linux/focused results do not repair that native failure.','Historical Windows Chrome long-load shutdown failure remains recorded; Linux/focused results do not repair the native OneDrive statistics wait.')
    (q/target).open('x',encoding='utf-8').write(text)
print('Prepared original-policy public HTTP/download/report/deployment review readers.')

