import hashlib,json,pathlib
q=pathlib.Path(__file__).resolve().parent;p=q/'windows-public-tensor-diagnostics.mjs';s=p.read_text(encoding='utf-8')
old="report.errors.push('Unexpected application network request');"
assert s.count(old)==1
s=s.replace(old,"(report.deniedRequests??=[]).push({url:r.url(),method:r.method(),resourceType:r.resourceType()});"+old)
s=s.replace('model-lens-windows-public-runtime-tensor-diagnostics','model-lens-windows-public-runtime-tensor-network-diagnostic')
out=q/'windows-public-tensor-network-diagnostic.mjs';out.open('x',encoding='utf-8').write(s)
receipt={'status':'one-bounded-diagnostic-predeclared','purpose':'Record denied request URL/method/resource only. Original two acceptance failures remain failed; predicate and aborts unchanged. OneChrome diagnostic, no Edge repetition or app modification.','baseSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'diagnosticSHA256':hashlib.sha256(s.encode()).hexdigest(),'model':'Same local official public fixture; no private data or request bodies.'}
(q/'public-network-diagnostic-plan.json').open('x',encoding='utf-8').write(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))

