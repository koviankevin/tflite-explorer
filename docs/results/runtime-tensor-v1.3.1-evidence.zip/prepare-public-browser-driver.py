import hashlib,json,pathlib
q=pathlib.Path(__file__).resolve().parent
original=(q/'windows-tensor-diagnostics-v3.mjs').read_text(encoding='utf-8')
text=original
old=next(line for line in text.splitlines() if line.startswith('const server=createStaticServer('))
new="const base='https://koviankevin.github.io/tflite-explorer/';"
assert old in text;text=text.replace(old,new)
old="const doc=await trustedDocument(build,manifest);report.documentFixture=doc.proof;"
assert old in text;text=text.replace(old,"report.documentTransport='actual public HTTPS; no document fulfillment or local application substitution';")
old="if(!await doc.handle(route,base))return route.continue();"
assert old in text;text=text.replace(old,"return route.continue();")
old="server.closeAllConnections();await new Promise(r=>server.close(r));"
assert old in text;text=text.replace(old,"")
text=text.replace('model-lens-windows-runtime-tensor-diagnostics','model-lens-windows-public-runtime-tensor-diagnostics')
start="Official licensed public-model diagnostic UI on authenticated original HTML fixture;"
assert start in text;text=text.replace(start,"Actual public HTTPS diagnostic UI with local official licensed model;")
text=text.replace('not unobserved short-lived processes, HTTP document transport, physical RSS','not unobserved short-lived processes or physical RSS')
out=q/'windows-public-tensor-diagnostics.mjs';assert not out.exists();out.write_text(text,encoding='utf-8')
receipt={'status':'prepared-not-executed','baseSHA256':hashlib.sha256(original.encode()).hexdigest(),'driverSHA256':hashlib.sha256(text.encode()).hexdigest(),'changes':['Use actual public HTTPS origin, no local server or HTML fixture','Retain canonical native flags, 10s close and35s UI policy','Keep all model/BIN data local, allow only GET at formal application origin'],'purpose':'Run once after v1.3.1 publication verified. No use of pre-publish public v1.3.0 as candidate success.'}
(q/'public-browser-driver-plan.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))

