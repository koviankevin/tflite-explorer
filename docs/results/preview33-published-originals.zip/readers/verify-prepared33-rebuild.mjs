import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {gitSource,verifyArtifact,sha256} from '../../scripts/lib/release-artifact.mjs';
const [run,frozen,buildDirectory]=process.argv.slice(2);assert.match(run,/^\d+$/);assert.match(frozen,/^[a-f0-9]{40}$/);const source=gitSource();assert.equal(source.commit,frozen);assert.equal(source.dirty,false);
const directory=`build/qa/prepared-${run}-runtime33`,prepared=JSON.parse(await readFile(directory+'/report.json','utf8'));assert.equal(prepared.status,'passed');assert.equal(prepared.sourceUnchanged,true);assert.deepEqual(prepared.source,source);
const fresh=await verifyArtifact(buildDirectory,{publicOnly:true,expectedCommit:frozen,requireClean:true});assert.deepEqual(fresh.release,prepared.release);assert.equal(fresh.release.version,'0.2.0-preview.33');
const bytes=await readFile(buildDirectory+'/release-manifest.json'),asset=prepared.assets.find(a=>a.name==='release-manifest.json');assert.ok(asset);assert.equal(bytes.length,asset.bytes);assert.equal(sha256(bytes),asset.sha256);assert.deepEqual(gitSource(),source);
const review={authentication:'passed',source,sourceUnchanged:true,build:fresh.release.buildId,coreManifestSHA256:asset.sha256,coreFiles:fresh.files.length,site:prepared.site,preparation:Number(run),scope:'Independent clean rebuild matches provider-prepared preview.33 manifest; original ZIP/tar and complete site reviewed separately'};await writeFile(directory+'/rebuild-review.json',JSON.stringify(review,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(review));
