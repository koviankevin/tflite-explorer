import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {tflite as s} from '../vendor/netron/tflite-schema.js';
import {FlatbufferWriter} from '../src/flatbuffer-writer.js';
import {parseModel} from '../src/model-engine.js';
import {prepareTfliteModelEdit} from '../src/tflite-model-edit.js';
import {exportTflite} from '../src/tflite-export.js';
import {createExportReport} from '../src/export-report.js';
import {runtimeFixture} from './runtime-fixture.mjs';

const metadata=JSON.parse(await readFile(new URL('../vendor/netron/tflite-metadata.json',import.meta.url),'utf8'));
const parse=bytes=>parseModel((o,n)=>bytes.subarray(o,o+n),bytes.length,metadata);
async function fixture(name,shapes,{rank=false,output=shapes[0],values}={}){
    const {model}=await runtimeFixture({inputShapes:shapes,outputShape:output});
    Object.assign(model.operator_codes[0],{builtin_code:s.BuiltinOperator[name],deprecated_builtin_code:s.BuiltinOperator[name]});
    const g=model.subgraphs[0];
    for(const t of g.tensors)t.has_rank=rank;
    g.operators[0].builtin_options=name==='FULLY_CONNECTED'?Object.assign(new s.FullyConnectedOptions(),{weights_format:0,keep_num_dims:false,fused_activation_function:0}):new s.TransposeOptions();
    if(values){
        g.tensors[1].type=s.TensorType.INT32;g.tensors[1].buffer=1;
        model.buffers.push({data:new Uint8Array(Int32Array.from(values).buffer),offset:0n,size:0n});g.inputs=Int32Array.of(0);
    }
    const blob=new FlatbufferWriter().finish(model,new Blob()),bytes=new Uint8Array(await blob.arrayBuffer()),index=await parse(bytes),file=new File([blob],'legacy-shape.tflite');
    file.arrayBuffer=()=>assert.fail('never read the entire original File');
    return {index,file,bytes};
}

test('actual legacy FC rewire rejects a known incompatible input even when has_rank defaults false',async()=>{
    for(const rank of [true,false]){
        const c=await fixture('FULLY_CONNECTED',[[2,3],[5,4]],{rank,output:[2,5]});
        assert.equal(c.index.raw.subgraphs[0].tensors[0].has_rank,rank);
        assert.throws(()=>prepareTfliteModelEdit(c.index,c.file,[{graph:0,operators:[{template:0,inputs:[0,1]}]}]),error=>/Subgraph #0.*OP #0.*FULLY_CONNECTED/.test(error.message)&&/input_size/.test(error.message));
    }
});

test('actual legacy TRANSPOSE cut checks readable permutation and reports output tensor IDs without changing flags',async()=>{
    const c=await fixture('TRANSPOSE',[[2,3],[2]],{output:[3,2],values:[1,0]}),result=exportTflite(c.index,0,[0],c.file);
    const candidate=await parse(new Uint8Array(await result.blob.arrayBuffer()));
    assert.ok(candidate.raw.subgraphs[0].tensors.every(t=>t.has_rank===false));
    const built=createExportReport(c.index,c.file,result,{graph:0,nodes:[0],outputName:'legacy-cut.tflite'}),r=JSON.parse(await built.blob.text());
    assert.equal(r.operatorValidation[0].status,'passed');
    assert.ok(!('runtimeValidation' in r));
    const bad=await fixture('TRANSPOSE',[[2,3],[2]],{output:[3,2],values:[0,0]});
    assert.throws(()=>exportTflite(bad.index,0,[0],bad.file),/OP #0 TRANSPOSE.*permutation/);
});
