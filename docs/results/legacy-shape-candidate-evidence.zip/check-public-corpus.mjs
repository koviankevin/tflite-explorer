import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {parseModel} from '../../../src/model-engine.js';
import {tflite as schema} from '../../../vendor/netron/tflite-schema.js';
import {checkOperatorMetadata as afterMetadata} from '../../../src/tflite-semantic-checks.js';
import {validateTfliteConstants as afterConstants} from '../../../src/tflite-constant-checks.js';
import {checkOperatorMetadata as beforeMetadata} from './baseline/tflite-semantic-checks.mjs';
import {validateTfliteConstants as beforeConstants} from './baseline/tflite-constant-checks.mjs';
import {editTfliteModel} from '../../../src/tflite-model-edit.js';
import {exportTflite} from '../../../src/tflite-export.js';
const q=new URL('./',import.meta.url),corpus=new URL('../../../../tflite-explorer/build/qa/product-next/public-corpus/',q),metadata=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',q),'utf8'));
const manifest=JSON.parse(await readFile(new URL('manifest.json',corpus),'utf8')),files=[...manifest.files.map(f=>({...f,url:new URL(f.file,corpus)})),{file:'person_detect.tflite',url:new URL('../public-quantized-compatibility/person_detect.tflite',q),bytes:300568,sha256:'808cfdfc0cf3a6fa6f6fa26bfa379ea97c16d5db7334637766e39c3408502e9d'}],cases=[];
const sha=b=>createHash('sha256').update(b).digest('hex'),parse=b=>parseModel((o,n)=>b.subarray(o,o+n),b.length,metadata);
const errorOf=f=>{try{return {status:'passed',result:f()};}catch(e){return {status:'failed',reason:e.message};}};
const shapeFields=m=>m.subgraphs.map(g=>g.tensors.map(t=>({shape:[...t.shape],signature:[...t.shape_signature],has_rank:t.has_rank,quantization:t.quantization})));
const payload=(model,bytes,id)=>{const b=model.buffers[id];return b.size?bytes.subarray(Number(b.offset),Number(b.offset+b.size)):b.data||new Uint8Array();};
for(const f of files){
 const b=new Uint8Array(await readFile(f.url));assert.equal(b.length,f.bytes);assert.equal(sha(b),f.sha256);const index=await parse(b),file=new File([b],f.file),graphs=[];file.arrayBuffer=()=>assert.fail('no entire source File read');
 for(const [graph,g]of index.raw.subgraphs.entries()){
  const operators=g.operators.map((op,node)=>{const code=index.raw.operator_codes[op.opcode_index],name=code.custom_code||schema.BuiltinOperator[Math.max(code.builtin_code,code.deprecated_builtin_code||0)],args=[name,[...op.inputs].map(n=>g.tensors[n]),[...op.outputs].map(n=>g.tensors[n]),op.builtin_options||{}];return {node,type:name,before:errorOf(()=>beforeMetadata(...args)),after:errorOf(()=>afterMetadata(...args))};});
  const read=(o,n)=>b.subarray(o,o+n),before=errorOf(()=>beforeConstants(index.raw,graph,read)),after=errorOf(()=>afterConstants(index.raw,graph,read));graphs.push({graph,operators,beforeConstants:before,afterConstants:after});
 }
 const result=editTfliteModel(index,file,index.raw.subgraphs.map((_,graph)=>({graph}))),identity=new Uint8Array(await result.blob.arrayBuffer()),reopened=await parse(identity);assert.deepEqual(shapeFields(reopened.raw),shapeFields(index.raw));
 assert.equal(reopened.raw.buffers.length,index.raw.buffers.length);let payloads=0;
 for(const [id]of index.raw.buffers.entries()){assert.deepEqual(payload(reopened.raw,identity,id),payload(index.raw,b,id));if(payload(index.raw,b,id).length)payloads++;}
 const cut=exportTflite(index,0,index.raw.subgraphs[0].operators.map((_,i)=>i),file),cutBytes=new Uint8Array(await cut.blob.arrayBuffer()),cutIndex=await parse(cutBytes);
 for(const m of cut.provenance.tensorMap){const src=index.raw.subgraphs[0].tensors[m.sourceId],out=cutIndex.raw.subgraphs[0].tensors[m.outputId];assert.deepEqual(Array.from(out.shape),Array.from(src.shape));assert.equal(out.has_rank,src.has_rank);assert.deepEqual(out.quantization,src.quantization);assert.deepEqual(payload(cutIndex.raw,cutBytes,out.buffer),payload(index.raw,b,src.buffer));}
 cases.push({file:f.file,sourceBytes:b.length,sourceSHA256:f.sha256,graphs,identity:{bytes:identity.length,sha256:sha(identity),payloads,shapeFlagsQuantizationPreserved:true},cut:{bytes:cutBytes.length,sha256:sha(cutBytes),operators:cutIndex.raw.subgraphs[0].operators.length,shapeFlagsQuantizationPayloadsPreserved:true},sourceUnchanged:sha(b)===f.sha256});
}
const regressions=cases.flatMap(c=>c.graphs.flatMap(g=>[...g.operators.filter(o=>o.before.status==='passed'&&o.after.status==='failed').map(o=>({file:c.file,graph:g.graph,node:o.node,kind:'metadata',reason:o.after.reason})),...(g.beforeConstants.status==='passed'&&g.afterConstants.status==='failed'?[{file:c.file,graph:g.graph,kind:'constants',reason:g.afterConstants.reason}]:[])]));
const result={status:regressions.length?'new-rejections-require-review':'passed-public-corpus-shape-compatibility',baseline:'44f0868beb1fa5c8d583260800c3455dcf0e4d29',cases,regressions,scope:'Five hash-pinned public originals;actual metadata/constant differential,identity/full-cut serialization and payload/shape/rank/quantization preservation. No interpreter invoked;prior CPU evidence retains its original scope.'};
await writeFile(new URL('public-corpus.json',q),JSON.stringify(result,(_,v)=>typeof v==='bigint'?String(v):v,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:result.status,regressions,cases:cases.map(c=>({file:c.file,graphs:c.graphs.map(g=>({graph:g.graph,before:g.beforeConstants.status==='passed'?g.beforeConstants.result.checked:g.beforeConstants.reason,after:g.afterConstants.status==='passed'?g.afterConstants.result.checked:g.afterConstants.reason})),payloads:c.identity.payloads,preserved:c.identity.shapeFlagsQuantizationPreserved&&c.cut.shapeFlagsQuantizationPayloadsPreserved}))}));assert.equal(regressions.length,0);
