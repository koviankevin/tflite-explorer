import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {buildSite} from '../../../scripts/build.mjs';
import {gitSource,verifyArtifact} from '../../../scripts/lib/release-artifact.mjs';
const q=new URL('./',import.meta.url),source=gitSource();assert.equal(source.dirty,false);
await writeFile(new URL('candidate-build-intent.json',q),JSON.stringify({source,producer:'build-candidate.mjs',output:'build/qa/legacy-shape-preflight/candidate-site',purpose:'Isolated Windows Chrome/Edge candidate QA;not public deployment',retention:'Preserve all originals/failures;no cleanup'},null,2)+'\n',{flag:'wx'});
const result=await buildSite({output:'build/qa/legacy-shape-preflight/candidate-site'}),manifest=await verifyArtifact(result.directory,{publicOnly:true,requireClean:true,expectedCommit:source.commit});assert.equal(manifest.release.version,'1.4.1');assert.equal(manifest.files.length,325);
const receipt={status:'built-and-verified',source,directory:result.directory,release:manifest.release,files:manifest.files.length};await writeFile(new URL('candidate-build.json',q),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));
