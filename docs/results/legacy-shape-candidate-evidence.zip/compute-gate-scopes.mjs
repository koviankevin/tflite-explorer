import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {sourceScope,gitReader} from '../../../scripts/lib/release-gates.mjs';
const reader=gitReader(),source=reader.git(['rev-parse','HEAD']),records=[];
for(const kind of ['core','browser','contract','site']){
 const previous=JSON.parse(await readFile(new URL('../quantization-preflight/main-'+kind+'-review.json',import.meta.url),'utf8')),before=sourceScope(kind,previous.source,reader),current=sourceScope(kind,source,reader);assert.equal(before.fingerprint,previous.scopeFingerprint);
 const old=new Map(before.files.map(f=>[f.path,JSON.stringify(f)])),changed=current.files.filter(f=>old.get(f.path)!==JSON.stringify(f)).map(f=>f.path);records.push({kind,source,fingerprint:current.fingerprint,files:current.files.length,previousRun:previous.run,previousSource:previous.source,previousFingerprint:before.fingerprint,unchanged:before.fingerprint===current.fingerprint,changed});
}
assert.equal(records[0].unchanged,true);await writeFile(new URL('gate-scope-plan.json',import.meta.url),JSON.stringify({source,records},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(records.map(r=>({kind:r.kind,unchanged:r.unchanged,files:r.files,changed:r.changed}))));
