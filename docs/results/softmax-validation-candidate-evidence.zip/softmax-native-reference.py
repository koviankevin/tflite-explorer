import pathlib,json,hashlib,traceback,datetime
import numpy as np
from ai_edge_litert.interpreter import Interpreter,OpResolverType
root=pathlib.Path('build/qa/softmax-reference');manifest=json.loads((root/'fixture-manifest.json').read_text(encoding='utf-8'));results=[]
for resolver in ['without-delegates','default']:
 for c in manifest['cases']:
  data=(root/'fixtures'/(c['name']+'.tflite')).read_bytes();assert hashlib.sha256(data).hexdigest()==c['modelSHA256']
  row=dict(name=c['name'],resolver=resolver,modelSHA256=c['modelSHA256'],valid=c['valid'])
  try:
   options=dict(model_content=data,num_threads=1)
   if resolver=='without-delegates':options['experimental_op_resolver_type']=OpResolverType.BUILTIN_WITHOUT_DEFAULT_DELEGATES
   runtime=Interpreter(**options);runtime.allocate_tensors();info=runtime.get_input_details()[0]
   raw=(root/'fixtures'/(c['name']+'.bin')).read_bytes();assert hashlib.sha256(raw).hexdigest()==c['inputSHA256']
   values=np.frombuffer(raw,dtype=info['dtype']).reshape(info['shape']);runtime.set_tensor(info['index'],values);runtime.invoke();out=runtime.get_output_details()[0];actual=runtime.get_tensor(out['index']);q=out['quantization_parameters']
   decoded=actual.astype(np.float64).reshape(-1)
   if len(q['scales']):decoded=(decoded-float(q['zero_points'][0]))*float(q['scales'][0])
   row.update(status='invoked',dtype=np.dtype(out['dtype']).name,shape=out['shape'].tolist(),output=actual.reshape(-1).tolist(),decoded=decoded.tolist())
   row['maxError']=float(np.max(np.abs(decoded-np.array(c['expected']))))
   row['matches']=row['maxError']<=(0.07 if c['name'].startswith('LOG_SOFTMAX-') and len(q['scales']) else 0.008 if len(q['scales']) else 1e-6)
   del runtime
  except Exception:row.update(status='failed',error=traceback.format_exc(),matches=False)
  results.append(row);print(json.dumps(row))
report=dict(format='model-lens-native-softmax-reference',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),engine='ai-edge-litert 2.3.0 Interpreter',status='passed' if all(r['matches'] for r in results if r['valid']) else 'failed',results=results)
(root/'native-reference.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
assert report['status']=='passed','Valid fixture failed native reference.'
