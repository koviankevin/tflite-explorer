import {mkdir,writeFile,appendFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {softmaxFixture} from '../../test/softmax-fixture.mjs';
const directory='build/qa/softmax-reference/fixtures';await mkdir(directory,{recursive:true});
await appendFile('build/events.jsonl',JSON.stringify({event:'create_intent',at:new Date().toISOString(),path:directory,purpose:'Exact synthetic Softmax schema/runtime boundary comparison',producer:'softmax-native-fixtures.mjs',cleanup_condition:'Preserve fixture hashes, native outputs and red tests through validation delivery'})+'\n');
const cases=[];
const add=async(name,options,values,valid=true)=>{
    const f=await softmaxFixture(options);await writeFile(directory+'/'+name+'.tflite',f.bytes);await writeFile(directory+'/'+name+'.bin',Buffer.from(values.buffer,values.byteOffset,values.byteLength));
    const logits=Array.from(values,v=>(v-(options.inputQuantization?.zero_point?.[0]??0))*(options.inputQuantization?.scale?.[0]??1)),expected=[];
    for(let i=0;i<logits.length;i+=3){const row=logits.slice(i,i+3).map(v=>v*(options.beta??1)),m=Math.max(...row),sum=row.reduce((a,x)=>a+Math.exp(x-m),0);expected.push(...row.map(x=>options.name==='LOG_SOFTMAX'?x-m-Math.log(sum):Math.exp(x-m)/sum));}
    cases.push({name,options,valid,expected,modelSHA256:createHash('sha256').update(f.bytes).digest('hex'),inputSHA256:createHash('sha256').update(Buffer.from(values.buffer,values.byteOffset,values.byteLength)).digest('hex')});
};
for(const name of ['SOFTMAX','LOG_SOFTMAX']){
    await add(name+'-float',{name},Float32Array.of(1,2,3,-2,-1,0));
    await add(name+'-stale-shape',{name,output:[6]},Float32Array.of(1,2,3,-2,-1,0),false);
    await add(name+'-int32-output',{name,outputType:2},Float32Array.of(1,2,3,-2,-1,0),false);
}
for(const beta of [0,-1])await add('SOFTMAX-beta-'+beta,{name:'SOFTMAX',beta},Float32Array.of(1,2,3,-2,-1,0));
for(const type of [3,9]){
    const inputQuantization={scale:[0.125],zero_point:[type===3?128:0]},values=type===3?Uint8Array.of(128,136,144,112,120,128):Int8Array.of(0,8,16,-16,-8,0);
    for(const outputType of [type,7])await add('SOFTMAX-'+type+'-to-'+outputType,{name:'SOFTMAX',inputType:type,outputType,inputQuantization,outputQuantization:{scale:[outputType===7?1/65536:1/256],zero_point:[outputType===7?-32768:type===3?0:-128]}},values);
    await add('LOG_SOFTMAX-'+type,{name:'LOG_SOFTMAX',inputType:type,inputQuantization,outputQuantization:{scale:[16/256],zero_point:[type===3?255:127]}},values);
}
await add('SOFTMAX-int16',{name:'SOFTMAX',inputType:7,inputQuantization:{scale:[1/256],zero_point:[0]},outputQuantization:{scale:[1/32768],zero_point:[0]}},Int16Array.of(0,256,512,-512,-256,0));
await writeFile('build/qa/softmax-reference/fixture-manifest.json',JSON.stringify({syntheticModelsOnly:true,cases},null,2)+'\n');console.log(JSON.stringify({fixtures:cases.length,valid:cases.filter(c=>c.valid).length}));
