import json,pathlib,sys,statistics,hashlib,math
root=pathlib.Path(__file__).resolve().parent
name=sys.argv[1];assert name in ['chrome-v1.2-1','edge-v1.2-1']
p=root/(name+'.json');raw=p.read_bytes();r=json.loads(raw);channel='chrome' if name.startswith('chrome') else 'msedge'
assert r['status']=='passed' and (root/(name+'.log')).read_text(encoding='utf8').rstrip().endswith('PRODUCER_EXIT=0')
expected=json.loads((root/'v1.2-windows-source.json').read_bytes());assert r['environment']['sourceCommit']==expected['commit'] and r['environment']['sourceTree']==expected['tree']
assert r['environment']['platform']=='win32' and r['environment']['channel']==channel and not r['environment']['sourceDirty'] and r['sourceUnchanged']
MiB=1024**2
policy={'version':3,'cycles':8,'warmupCycles':2,'sampleIntervalMs':500,'urlReleaseTimeoutMs':80000,'settleSamples':5,'maxReadBytes':MiB,'realmReadBytes':16*MiB,'browserPeakGrowthBytes':768*MiB,'closedRssDriftBytes':128*MiB,'closedRssSlopeBytesPerCycle':16*MiB,'closedMainHeapDriftBytes':32*MiB,'modelWorkerUsedBytes':512*MiB,'modelWorkerBackingBytes':512*MiB}
assert r['policy']==policy and r['watchdogMinutes']==30 and r['buildReused'] is True 
assert r['build']==json.loads((root/'v1.2-prepared-artifacts/core/release.json').read_text(encoding='utf8'))
f=r['fixture'];assert f['bytes']==1349965216 and f['operators']==21005 and f['weightBytes']==1342177280 and f['allocatedBytes']>=f['bytes']*.99
assert f['sha256']==f['readbackSHA256']=='7ea3c8b317c42a3464b74ef8d9a80b27b42f912c1592b5c60daab670ffc66586'
assert f['weightSHA256']=='a16ef6b52ac75f75437a7ac7031e68aafe3c4d7475426c7714d5cc77e433a525'
assert r['documentFixture']['mode']=='manifest-pinned-document-fixture' and r['documentFixture']['deliveries']==1 and r['documentFixture']['httpDocumentTransportVerified'] is False
assert not r.get('cleanupObservationAfterDriverError')
assert r['browserClosed'] and r['processCleanup']['allReaped'] and r['processCleanup']['remaining']==[] and not r.get('forcedCleanup')
assert r['windowsObserverClose']=={'exitCode':0,'stderr':''} and r['errors']==[] and r['workerClosures'] and all(w['closed'] for w in r['workerClosures'])
identities=lambda rows:{(v['pid'],v['startTicks']) for v in rows}
assert identities(r['processCleanup']['identities'])<=identities(r['windowsObservedIdentities'])
assert len(identities(r['windowsObservedIdentities']))==len(r['windowsObservedIdentities'])
audit=r['audit'];assert audit['urls'] and all(x['revoked'] for x in audit['urls'])
model=[w for w in audit['workers'] if '/model-worker.js' in w['url']];recovery=[w for w in audit['workers'] if 'recoveryAudit' in w]
assert len(model)==40 and len(recovery)==16
for w in model:
 assert w['terminated'] and not w.get('error') and w['audit']['bytes']==w['stats']['bytesRead']+w.get('verificationReadBytes',0)
for a in [audit['audit']]+[w['audit'] for w in audit['workers'] if 'audit' in w]:assert a['violations']==[] and a['maxRead']<=MiB and a['bytes']<=16*MiB
for w in recovery:
 a=w['recoveryAudit'];assert w['terminated'] and a['complete'] and a['bytes']==f['bytes'] and a['maxRead']<=MiB and a['violations']==[] and a['fingerprint']==f['editFingerprint']
cycles=r['cycles'];assert len(cycles)==8
for i,c in enumerate(cycles):
 assert c['cycle']==i+1 and c['kind']==('prefix' if i%2==0 else 'branch') and c['font']==32 and c['fileInputEmpty'] and c['liveModelWorkers']==c['activeBlobUrls']==0
 assert c['weightVerified'] and c['optionsVerified'] and c['weightSHA256']==f['weightSHA256'] and c['patternSourceMatches']==c['patternReopenMatches']==1 and c['negativePatternMatches']==0
 assert len(c['workerHeaps'])==5
 for h in c['workerHeaps']:assert 0<h['usedSize']<=512*MiB and 0<=h['backingStorageSize']<=512*MiB
 m=c['modelEdit'];assert m['sourceOperators']==21005 and m['outputOperators']==m['readbackOperators']==21006 and m['weightVerified'] and m['optionsVerified'] and m['roundTrip'] and m['byteComparison']=='passed' and m['comparedBytes']>=1342177280
 assert m['weightSHA256']==f['weightSHA256'] and m['sha256']==cycles[0]['modelEdit']['sha256'] and m['prefixMatches']==m['branchMatches']==1
 m=c['composition'];assert m['workspaceNative'] and m['imports']==[4,4] and m['sourceNodes']==8 and m['cloneNodes']==1 and m['undoRedo'] and m['outputOperators']==m['readbackOperators']==9 and m['weightVerified'] and m['optionsVerified'] and m['roundTrip'] and m['byteComparison']=='passed' and m['comparedBytes']>=1342177280
 assert m['sha256']==cycles[0]['composition']['sha256'] and m['weightSHA256']==f['weightSHA256'] and m['prefixMatches']==m['branchMatches']==m['reshapeMatches']==1 and m['negativePatternMatches']==0
 assert m['layout']['font']==32 and m['layout']['width']==1280 and m['layout']['scrollWidth']<=1280 and m['layout']['graphHeight']>=200
 assert m['recovery']['complete'] and m['recovery']['fingerprint']==f['editFingerprint'] and m['recovery']['bytes']==f['bytes']
 assert c['sha256']==cycles[i%2]['sha256']
samples=r['samples'];assert len(samples)>=100 and all(s['rssBytes']>0 and s['privateCommitBytes']>=0 for s in samples)
gaps=[b['elapsedMs']-a['elapsedMs'] for a,b in zip(samples,samples[1:])];assert all(x>=0 for x in gaps)
rss=[c['closedRssBytes'] for c in cycles[2:]];mean=statistics.mean(rss);center=(len(rss)-1)/2
summary={'measuredCycles':6,'rssSlopeBytesPerCycle':sum((i-center)*(v-mean) for i,v in enumerate(rss))/sum((i-center)**2 for i in range(len(rss))),'rssDriftBytes':statistics.median(rss[-3:])-cycles[1]['closedRssBytes'],'mainHeapDriftBytes':statistics.median([c['closedMainHeapBytes'] for c in cycles[-3:]])-cycles[1]['closedMainHeapBytes'],'sampledPeakRssBytes':max(s['rssBytes'] for s in samples)}
summary['sampledPeakGrowthBytes']=summary['sampledPeakRssBytes']-samples[0]['rssBytes']
assert r['evaluation']['status']=='passed' and r['evaluation']['issues']==[]
for key,val in summary.items():assert math.isclose(val,r['evaluation']['summary'][key],rel_tol=1e-12,abs_tol=1e-6),(key,val,r['evaluation']['summary'][key])
for key,limit in [('rssSlopeBytesPerCycle',16*MiB),('rssDriftBytes',128*MiB),('mainHeapDriftBytes',32*MiB),('sampledPeakGrowthBytes',768*MiB)]:assert summary[key]<=limit
assert r['environment']['testArguments']==(['--disable-updater-scheduler'] if channel=='chrome' else [])
assert r['nativeProcessBreakdown'] and all(e['rows'] and e['mainHeap']['usedSize']>0 and e['dom']['nodes']>0 for e in r['nativeProcessBreakdown'])
log=(root/(name+'.log')).read_text(encoding='utf8');assert '<will force kill>' not in log and '<kill>' not in log
assert '<gracefully close end>' in log and '<process did exit: exitCode=0, signal=null>' in log
review={'status':'passed','source':r['environment']['sourceCommit'],'build':r['build']['buildId'],'channel':channel,'reportSHA256':hashlib.sha256(raw).hexdigest(),'summary':summary,'sampling':{'count':len(samples),'maximumGapMs':max(gaps),'p95GapMs':sorted(gaps)[int(len(gaps)*.95)]},'nativeIdentities':r['windowsObservedIdentities'],'nativeWorkersClosed':len(r['workerClosures']),'modelWorkers':40,'recoveryWorkers':16,'workerUsedPeakBytes':max(h['usedSize'] for c in cycles for h in c['workerHeaps']),'workerBackingPeakBytes':max(h['backingStorageSize'] for c in cycles for h in c['workerHeaps']),'fullModelSHA256':cycles[0]['modelEdit']['sha256'],'compositionSHA256':cycles[0]['composition']['sha256'],'cutSHA256':[cycles[0]['sha256'],cycles[1]['sha256']],'limitations':r['limitations']}
(root/(name+'-review.json')).write_text(json.dumps(review,indent=2)+'\n',encoding='utf8');print(json.dumps(review))
