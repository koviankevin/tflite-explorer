from pathlib import Path
import datetime,hashlib,json,zipfile
q=Path(__file__).resolve().parent;repo=q.parents[2];target=repo.parent/'tflite-explorer-transpose/docs/results'
state=json.loads((q/'windows-v1.2-full-status.json').read_bytes())
assert state['status']=='completed-both-reviewed' and len(state['cases'])==2
assert all(r['producerExit']==r['reviewerExit']==0 and r['status']=='passed-reviewed' for r in state['cases'])
sources=[]
for name in ['chrome-v1.2-1','edge-v1.2-1']:
    for suffix in ['.json','.log','-review.json','-review.log']:sources.append((f'native/{name}{suffix}',q/(name+suffix)))
for name in ['windows-v1.2-full-status.json','v1.2-windows-source.json','v1.2-core-reverification.json','windows-v1.2-full-plan.json','close-io-controls-review.json','run-windows-v1.2-full.py','review-windows-v1.2-full.py','archive-windows-v1.2.py']:
    sources.append(('audit/'+name,q/name))
for name in ['test/browser/model-lifecycle.mjs','test/browser/windows-process-memory.mjs','test/browser/windows-process-memory.py','test/browser/owned-processes.mjs','test/browser/lifecycle-policy.mjs','test/browser/trusted-document.mjs','test/physical-tflite-fixture.mjs','LICENSE','vendor/netron/LICENSE']:
    sources.append(('published-source/'+name,repo/name))
rows=[]
for name in ['chrome-v1.2-1','edge-v1.2-1']:
    review=json.loads((q/(name+'-review.json')).read_bytes());raw=json.loads((q/(name+'.json')).read_bytes());log=(q/(name+'.log')).read_text(encoding='utf8')
    assert review['status']=='passed' and review['source']==state['source']['commit'] and review['build']==state['source']['buildId']
    assert '<will force kill>' not in log and '<kill>' not in log and '<process did exit: exitCode=0, signal=null>' in log
    assert hashlib.sha256((q/(name+'.json')).read_bytes()).hexdigest()==review['reportSHA256']
    rows.append({**review,'version':raw['environment']['chromium'],'platform':raw['environment']['release'],'fixture':raw['fixture'],'cases':8,'warmupCases':2,'normalClose':True,'scope':'Actualunmodifiedoriginalproducer/policy;Workerheapcheckpoints,nativeownedprocesses,manifestpinnedHTMLfixture;notfullHTTPtransportorcontinuouspeaks.'})
archive=target/'windows-v1.2-native-evidence.zip';members=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sources:
        data=p.read_bytes();z.writestr(name,data);members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(members)
    for m in members:
        b=z.read(m['path']);assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
data=archive.read_bytes()
receipt={'format':'model-lens-published-v1.2-native-physical-acceptance','version':1,'status':'passed-finite-original-policy','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':state['source'],'cases':rows,'archive':{'path':archive.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'members':members},'limits':{'rssSlopeBytesPerCycle':16*1024**2,'rssDriftBytes':128*1024**2,'sampledPeakGrowthBytes':768*1024**2},'materialLimits':['EdgeRSSslope16492368.46bytes/cycle isclose tooriginal16777216byte limit;notwideheadroom orproofagainstfuturegrowth.','Bothcurrentf592/d697nativecasespassed;historicalChrome4RSS/Chrome5closeandIO-onlyintermittentclosefailuresremainretained. No historicalrootcausefixclaimed.','PhysicalpublicsyntheticFile>1GiB/21005OP;no privatecompanymodel orcustomkernelinference. NativeWorkerV8checkpointsarenotper-workerOSRSSorcontinuouspeaks.','ThisdoesnotverifyOSpowerloss,arbitrarykernels/dialects/migrations,new2hload orfuturepatchedsource. NoGC/RSSsubtraction/trimming/timer/securitychanges.'],'goalComplete':False}
with (target/'windows-v1.2-native.json').open('x',encoding='utf8') as f:json.dump(receipt,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':receipt['status'],'browsers':[{'channel':r['channel'],'slopeBytesPerCycle':r['summary']['rssSlopeBytesPerCycle'],'driftBytes':r['summary']['rssDriftBytes'],'normalClose':r['normalClose']} for r in rows],'archiveBytes':len(data),'members':len(members),'sha256':receipt['archive']['sha256'],'source':state['source']['commit']}),flush=True)
