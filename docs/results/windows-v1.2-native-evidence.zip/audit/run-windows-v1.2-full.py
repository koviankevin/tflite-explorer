from pathlib import Path
import datetime,json,os,subprocess,sys
q=Path(__file__).resolve().parent;repo=q.parents[2]
node=r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
expected=json.loads((q/'v1.2-windows-source.json').read_bytes())
state_path=q/'windows-v1.2-full-status.json'
assert not state_path.exists(), 'Reconcile existing execution instead of repeating.'
state={'status':'starting','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':expected,'autoRetries':False,'predeterminedCases':2,'cases':[]}
def persist():
    temporary=state_path.with_suffix('.tmp')
    with temporary.open('w',encoding='utf8') as f:
        json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(temporary,state_path)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,encoding='utf8').strip()
persist()
try:
    assert git('rev-parse','HEAD')==expected['commit'] and git('rev-parse','HEAD^{tree}')==expected['tree'] and not git('status','--porcelain')
    proof=json.loads((q/'v1.2-core-reverification.json').read_bytes())
    assert proof['status']=='verified-original-public-core' and proof['files']==322
    assert proof['release']['source']['commit']==expected['commit'] and proof['release']['buildId']==expected['buildId']
    assert json.loads((q/'close-io-minimal-large-2/report.json').read_bytes())['processCleanup']['allReaped']
    for channel,name in [('chrome','chrome-v1.2-1'),('msedge','edge-v1.2-1')]:
        assert not (q/(name+'.json')).exists() and not (q/(name+'.log')).exists()
        assert git('rev-parse','HEAD')==expected['commit'] and not git('status','--porcelain')
        row={'name':name,'channel':channel,'status':'starting','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['cases'].append(row);state['status']='running';persist()
        env={**os.environ,'MODEL_LENS_QA_PYTHON':sys.executable,'MODEL_LENS_BROWSER_CHANNEL':channel,'LIFECYCLE_MODE':'gate','LIFECYCLE_REPORT':str(q/(name+'.json')),'LIFECYCLE_BUILD':str(q/expected['build']),'MODEL_LENS_TRUSTED_BOOTSTRAP':'1','DEBUG':'pw:browser'}
        with (q/(name+'.log')).open('xb') as log:
            child=subprocess.Popen([node,'test/browser/model-lifecycle.mjs','--allow-local-browser'],cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            row.update(status='running',producerPid=child.pid);persist();print('START '+name+' PID='+str(child.pid),flush=True)
            for line in child.stdout:
                log.write(line);log.flush()
                if line.startswith((b'PASS ',b'{',b'Report ')):print(line.decode('utf8',errors='replace'),end='',flush=True)
            code=child.wait();log.write(('\nPRODUCER_EXIT='+str(code)+'\n').encode());log.flush();os.fsync(log.fileno())
        row.update(status='passed-pending-independent-review' if code==0 else 'failed-as-measured',producerExit=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());persist()
        if code==0:
            result=subprocess.run([sys.executable,str(q/'review-windows-v1.2-full.py'),name],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            with (q/(name+'-review.log')).open('xb') as f:f.write(result.stdout);f.flush();os.fsync(f.fileno())
            print(result.stdout.decode('utf8',errors='replace'),flush=True)
            row.update(status='passed-reviewed' if result.returncode==0 else 'independent-review-failed',reviewerExit=result.returncode);persist()
        if row['status']!='passed-reviewed':
            state['status']='stopped-after-failed-case';persist();break
    else:
        state['status']='completed-both-reviewed'
except BaseException as e:
    state.update(status='stopped-error',error=type(e).__name__+': '+str(e));print(state['error'],flush=True)
finally:
    state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();persist()
sys.exit(0 if state['status']=='completed-both-reviewed' else 1)
