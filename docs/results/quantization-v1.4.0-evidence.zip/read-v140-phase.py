import pathlib,json,subprocess,sys,re,datetime
q=pathlib.Path(__file__).resolve().parent;phase=sys.argv[1];assert phase in ['prepare','publish'];plan=json.loads((q/'v1.4.0-release-plan.json').read_bytes());source=plan['source'];gh=r'H:\mc2llvm\.work\gh\bin\gh.exe';base='repos/koviankevin/tflite-explorer/'
def api(route):return json.loads(subprocess.check_output([gh,'api',base+route],timeout=45).decode('utf-8-sig'))
intent=json.loads((q/('v1.4.0-'+phase+'-dispatch.json')).read_bytes());runs=api('actions/workflows/verified-pages.yml/runs?head_sha='+source+'&event=workflow_dispatch&per_page=100');new=[r for r in runs['workflow_runs'] if r['id'] not in intent['knownBeforeIds']];assert len(new)==1;run=new[0];assert run['head_sha']==source and run['event']=='workflow_dispatch' and run['run_attempt']==1 and run['head_branch']=='main';assert datetime.datetime.fromisoformat(run['created_at'].replace('Z','+00:00'))>=datetime.datetime.fromisoformat(intent['createdAt']).replace(microsecond=0)
run=api('actions/runs/'+str(run['id']));jobs=api('actions/runs/'+str(run['id'])+'/jobs?per_page=100')
if run['status']!='completed':
 print(json.dumps({'phase':phase,'id':run['id'],'status':run['status'],'jobs':[{k:j[k] for k in ['id','name','status','conclusion']} for j in jobs['jobs']]}));sys.exit(0)
assert run['conclusion']=='success'
for suffix,obj in [('run',run),('jobs-raw',jobs),('artifacts',api('actions/runs/'+str(run['id'])+'/artifacts'))]:
 (q/('v1.4.0-'+phase+'-'+suffix+'.json')).open('x',encoding='utf-8').write(json.dumps(obj,indent=2)+'\n')
if phase=='prepare':
 job=[j for j in jobs['jobs'] if j['name']=='prepare'];assert len(job)==1 and job[0]['conclusion']=='success';raw=subprocess.check_output([gh,'api','--allow-escape-sequences',base+'actions/jobs/'+str(job[0]['id'])+'/logs'],timeout=45);(q/'v1.4.0-prepare-job.log').open('xb').write(raw);matches=[json.loads(line[line.index('{"prepared":true'):]) for line in raw.decode('utf-8-sig').splitlines() if '{"prepared":true' in line];assert len(matches)==1;p=matches[0];assert p['coreSource']==source and p['controllerSource']==source and p['prepared'] and not p['promotion'];(q/'v1.4.0-prepared-output.json').open('x',encoding='utf-8').write(json.dumps(p,indent=2)+'\n')
print(json.dumps({'phase':phase,'id':run['id'],'status':run['status'],'conclusion':run['conclusion'],'artifactsRecorded':True}))
