import pathlib,json
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2]
r=json.loads((q/'v1.4.0-published-review.json').read_bytes())
assert r['status']=='passed' and r['checks']==36 and r['siteFiles']==1468 and r['run']['id']==41250059080
assert (root/'docs/results/quantization-v1.4.0-published.json').exists()
def paragraph(file,prefix,new):
 p=root/file;s=p.read_text(encoding='utf-8');parts=s.split('\n\n');matches=[i for i,x in enumerate(parts) if x.startswith(prefix)];assert len(matches)==1,(file,prefix,matches);parts[matches[0]]=new;p.write_text('\n\n'.join(parts),encoding='utf-8')
paragraph('README.md','目前對外版本為','目前對外版本為 [v1.4.0](https://github.com/koviankevin/tflite-explorer/releases/tag/v1.4.0)，build `d36b95c7320aa6f2`；新增 affine 量化欄位檢查、失敗／未驗證報告與分批清單。324 核心檔、全站 1,468 檔、36 項正式站操作與四份實際固定下載已核對，見[正式交付](docs/quantization-validation.md#v140-正式交付)。模型全程本機，編輯匯出只做靜態與結構檢查，interpreter 保持手動；通過不代表任意 kernel 可執行。Windows 候選兩端的 32px／匯出重開／正常退出已核對；既有正式 HTTPS 額外網路守門及 Chrome 長負載／OneDrive 關閉失敗仍保留。以下舊版紀錄保留原來源與範圍。')
paragraph('docs/product-readiness.md','目前固定版本為','目前固定版本為 [v1.4.0](https://github.com/koviankevin/tflite-explorer/releases/tag/v1.4.0)，build `d36b95c7320aa6f2`。324 核心檔、全站 1,468 檔、36 項正式操作、四份實際固定下載與權威 deployment 均獨立核對，見[量化欄位與報告正式交付](quantization-validation.md#v140-正式交付)。原 RSS、安全與 runtime／URL 計時規則未放寬；Windows 額外網路守門與歷史長負載正常關閉失敗仍保留，完整商品化目標未完成。未知 dtype／codec、未檢查 subgraph 與任意 kernel 語意不列為已驗證；以下舊版驗收保持原來源與範圍。')
paragraph('docs/product-readiness-next.md','使用者於 2026-10-31','使用者於 2026-10-31 將目標接續為「商品等級」。目前正式版為 [v1.4.0](quantization-validation.md#v140-正式交付)／build `d36b95c7320aa6f2`，正式站與固定 Release 已獨立核對；完整商品化目標仍進行中。目標是公開核心可供工程師可靠日常使用，保留全部尚未完成項目；不以單個合成模型或綠燈宣告完成。')
paragraph('docs/product-readiness-next.md','接續 OP 驗證的 [v1.4.0','接續 OP 驗證的 [v1.4.0 量化欄位與報告](quantization-validation.md#v140-正式交付)已正式交付：補上非空 shape／legacy has_rank=false 與單一 scale 的量化軸檢查，未知 QuantizationDetails／尚未實作 dtype 範圍列為未驗證。重接無效欄位阻擋、原樣來源資料保留、100→200 分批、真正 CPU 差異控制，以及 Chrome／Edge 候選 32px／匯出重開均有各自來源證據。四項 main 關卡、正式站 1,468 檔／36 項操作、四份實際 Release 下載與權威 deployment 均已[最終核對](results/quantization-v1.4.0-published.json)。新增流程零自動 runtime，原政策未放寬；這不修復上述原生 Chrome 問題，也不代表所有 OP 或公司模型語意已驗證。')
paragraph('docs/known-issues.md','目前固定版本為','目前固定版本為 [v1.4.0](quantization-validation.md#v140-正式交付)／build `d36b95c7320aa6f2`。本頁保留公開版仍待處理的功能界線與驗收缺口；內網及私有 dialect 依使用者指示自行修改。')
paragraph('docs/known-issues.md','v1.4.0 的[量化欄位','v1.4.0 的[量化欄位檢查與報告](quantization-validation.md#v140-正式交付)已修正 legacy has_rank／單一 scale 的軸檢查，以及其他 QuantizationDetails 被錯用 affine 規則的問題。公開原檔找到 14 個量化軸失敗，原樣與切圖保留資料並明列報告；重接無效欄位則阻擋。未知 codec、INT64／INT4 等尚未實作範圍與超出預算項目明列未驗證。四項 main、正式站 36 項／1,468 檔、實際固定下載與 deployment 已核對；僅涵蓋修改／切出 scopes，不代表其他 subgraphs 或任意 kernel 語意已驗證。')
p=root/'docs/quantization-validation.md';s=p.read_text(encoding='utf-8')
s=s.replace('# Affine 量化欄位檢查與報告（v1.4.0 候選）','# Affine 量化欄位檢查與報告（v1.4.0）')
s=s.replace('目前尚未發布；正式站與固定下載仍為 [v1.3.1](runtime-tensor-diagnostics.md#v131-正式交付)。本候選增加量化欄位的靜態結果，不自動執行 interpreter，也不修改原始權重或量化參數。','已於 [v1.4.0](https://github.com/koviankevin/tflite-explorer/releases/tag/v1.4.0) 正式交付，build `d36b95c7320aa6f2`。新增量化欄位的靜態結果，不自動執行 interpreter，也不修改原始權重或量化參數。下方保留候選與各輪驗收的來源界線，最終結果見[正式交付](#v140-正式交付)。')
s=s.replace('正式 PR／main 發布關卡與交付仍待完成，本頁不宣稱 v1.4.0 已發布。','這是候選階段證據；後續 PR／main 與正式發布結果另列下方。')
s=s.replace('這是發布前結果，尚不代表 v1.4.0 已上線。','這些是發布前關卡，正式來源與 HTTPS／Release 結果另列下方。')
assert '## v1.4.0 正式交付' not in s
s+='''
## v1.4.0 正式交付

證據選用 PR #204 的受測 merge tree 與實際主分支相同。正式來源 `685804b1a2bed1d99926ee3816b38dfa757391b6`／tree `4469b419e7bbe8e5a07e26925c9ee425461e9180`，build `d36b95c7320aa6f2`。先以 [41249891909](https://github.com/koviankevin/tflite-explorer/actions/runs/41249891909) 只準備工件，獨立核對 provider digest、ZIP CRC、324 個核心檔、四項證據來源／scope 與版本歷史後，再由 [41250059080](https://github.com/koviankevin/tflite-explorer/actions/runs/41250059080) 以相同 build／site ID 發布。四個 jobs 皆在第一次 attempt 成功，沒有重跑成功部署。

正式 HTTPS 已逐一核對全站 1,468 檔的 bytes／SHA-256／MIME，36 項瀏覽器操作通過；包括量化失敗／未知／正常三種情境、無效重接阻擋、204 筆報告的 100→200 展開、實際六次下載／202 OP 重開搜尋、四個模型 Worker 關閉，新增流程零自動 runtime。原 15 組 32px 框、19 種手動 runtime、八輪／24 次 CPU／IO 與原 RSS／清理規則也依原政策核對。intentional crash recovery 的強制終止與正常關閉保持不同判定。

實際下載 [v1.4.0 固定 Release](https://github.com/koviankevin/tflite-explorer/releases/tag/v1.4.0) 的 ZIP、checksum、manifest 與 gates 四個 assets，逐一符合準備工件；ZIP 41,290,170 bytes，SHA-256 `911623417c53fb884a9a6e812531fdb9d99b3f58d45f050558876acd61e5b951`。Tag、Latest、不可變來源及權威 Pages deployment 均核對。Site ID 為 `8f6eff2a2ad97de14a78172e085b73084e163a49a6ebdf6dcb28b92acfbdeb6c`，保留 v1.3.1／v1.3.0 及永久 baseline，舊 assets 不變。

[最終收據](results/quantization-v1.4.0-published.json)與[原始發布紀錄及獨立讀取器](results/quantization-v1.4.0-evidence.zip)保留來源、官方 digest 與有限範圍；大型準備工件及四份實際下載留在本機並記錄雜湊，不在 evidence ZIP 重複嵌入。原 Windows Chrome 長負載／OneDrive 關閉問題、正式站額外網路守門失敗，以及任意 kernel／未知量化編碼／公司環境的未驗證範圍仍保留。僅交付 GitHub 正式站與固定 Release，未同步 Sites／GH Studio；完整商品等級目標仍進行中。
'''
p.write_text(s,encoding='utf-8');print('Updated current-version docs and appended source-bound v1.4.0 formal delivery; app unchanged.')
