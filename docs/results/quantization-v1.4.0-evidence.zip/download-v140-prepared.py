import base64,datetime,hashlib,json,os,pathlib,sys,urllib.error,urllib.request,zipfile
q=pathlib.Path(__file__).resolve().parent;name=sys.argv[1];assert name in ['github-pages','release-delivery']
meta=json.loads((q/'v1.4.0-prepare-artifacts.json').read_bytes());items=[a for a in meta['artifacts'] if a['name']==name];assert len(items)==1;a=items[0]
assert not a['expired'] and a['workflow_run']['id']==41249891909 and a['workflow_run']['head_sha']=='685804b1a2bed1d99926ee3816b38dfa757391b6' and 0<a['size_in_bytes']<=528*1024**2
out=q/'v1.4.0-prepared-artifacts';out.mkdir(exist_ok=True);assert out.resolve()==out.absolute() and not out.is_symlink()
dest=out/(name+'.zip');partial=out/(name+'.zip.part');assert not dest.exists() and not partial.exists()
state={'status':'create-intent','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifact':a['id'],'name':name,'destination':str(dest),'partial':str(partial),'expectedBytes':a['size_in_bytes'],'expectedDigest':a['digest'],'credentials':'Transient connector download reference only;never printed or saved','cleanup':'Retain verified ZIP or partial for reconciliation;no deletion authorised'}
def save(suffix):
    with (q/('v1.4.0-'+name+'-download-authorized-'+suffix+'.json')).open('x',encoding='utf-8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save('intent')
try:
    url=base64.b64decode(sys.argv[2]).decode('utf-8');assert url.startswith('https://');digest=hashlib.sha256();size=0
    with urllib.request.urlopen(url,timeout=30) as response,partial.open('xb') as file:
        while True:
            chunk=response.read(1024**2)
            if not chunk:break
            size+=len(chunk);assert size<=a['size_in_bytes'];digest.update(chunk);file.write(chunk)
        file.flush();os.fsync(file.fileno())
    del url
    assert size==a['size_in_bytes'] and 'sha256:'+digest.hexdigest()==a['digest']
    with zipfile.ZipFile(partial) as z:
        assert z.testzip() is None and len(z.namelist())==(1 if name=='github-pages' else 4)
        if name=='github-pages':assert z.namelist()==['artifact.tar']
    assert partial.resolve().parent==out.resolve() and dest.resolve().parent==out.resolve() and not dest.exists()
    os.replace(partial,dest);state.update(status='verified-provider-digest-and-crc',bytes=size,digest=a['digest']);save('result');print(json.dumps({'name':name,'bytes':size,'digest':a['digest'],'status':state['status']}))
except Exception as e:
    state.update(status='failed-preserve-partial-inspect-before-retry',errorType=type(e).__name__)
    if isinstance(e,urllib.error.HTTPError):state['httpStatus']=e.code
    save('result');print(json.dumps({'name':name,'status':state['status'],'errorType':state['errorType']}));sys.exit(1)
