import json,pathlib,re,subprocess
q=pathlib.Path(__file__).resolve().parent;out=q/'v1.4.0-deployment-map.json';assert not out.exists();data={};prefix='repos/koviankevin/tflite-explorer/'
def api(route):
    assert route.startswith(prefix)
    raw=subprocess.check_output([r'H:\mc2llvm\.work\gh\bin\gh.exe','api',route],timeout=45)
    o=json.loads(raw.decode('utf-8-sig'));data[route]=o;return o
deployments=api(prefix+'deployments?environment=github-pages&per_page=1');assert len(deployments)==1;d=deployments[0]
assert d['sha']=='685804b1a2bed1d99926ee3816b38dfa757391b6' and d['environment']=='github-pages'
s=api(prefix+'deployments/'+str(d['id'])+'/statuses?per_page=100')[0];assert s['state']=='success'
m=re.fullmatch(r'https://github.com/koviankevin/tflite-explorer/actions/runs/(\d+)/job/(\d+)',s['log_url']);assert m and int(m[1])==41250059080
job=api(prefix+'actions/jobs/'+m[2]);assert job['conclusion']=='success' and job['head_sha']==d['sha']
run=api(prefix+'actions/runs/'+m[1]+'/attempts/'+str(job['run_attempt']));assert run['status']=='completed' and run['conclusion']=='success'
out.open('x',encoding='utf-8').write(json.dumps(data,indent=2)+'\n')
print(json.dumps({'status':'actual-authoritative-deployment-map-read','deployment':d['id'],'run':run['id'],'job':job['id'],'source':d['sha'],'readonly':True}))

