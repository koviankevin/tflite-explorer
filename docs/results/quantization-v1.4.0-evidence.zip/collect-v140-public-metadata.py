import pathlib,json,subprocess
q=pathlib.Path(__file__).resolve().parent;gh=r'H:\mc2llvm\.work\gh\bin\gh.exe';base='repos/koviankevin/tflite-explorer/';prepared=json.loads((q/'v1.4.0-prepared-review.json').read_bytes());run=json.loads((q/'v1.4.0-publish-run.json').read_bytes());assert run['conclusion']=='success' and run['id']==41250059080 and run['head_sha']==prepared['source']
for suffix,route in [('release','releases/tags/v1.4.0'),('latest-release','releases/latest'),('tag','git/ref/tags/v1.4.0')]:
 raw=subprocess.check_output([gh,'api',base+route],timeout=45);obj=json.loads(raw.decode('utf-8-sig'));(q/('v1.4.0-'+suffix+'.json')).open('xb').write(raw)
 if suffix=='release':assert obj['target_commitish']==prepared['source'] and not obj['draft'] and not obj['prerelease'] and len(obj['assets'])==4
print('Saved actual new v1.4.0 Release, Latest and tag identities.')
