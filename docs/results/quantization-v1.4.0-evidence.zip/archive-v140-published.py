import pathlib,json,hashlib,datetime,zipfile
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];load=lambda n:json.loads((q/n).read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
r=load('v1.4.0-published-review.json');p=load('v1.4.0-prepared-review.json');assert r['status']=='passed' and r['release']['version']=='1.4.0' and r['checks']==36 and r['siteFiles']==1468 and r['quantizationValidation']['status']=='passed' and r['run']['id']==41250059080 and r['goalComplete']==False
names=['v1.4.0-release-plan.json','selection-pr-before-merge.json','selection-checks-review.json','selection-merge-proof.json','selection-contract-artifacts.json','selection-contract-artifact.zip','selection-contract-report.json','v1.3.1-live-index.json']
for k in ['node','contract']:names+=['selection-'+k+'-'+n for n in ['run.json','jobs.json','job.log']]
for phase in ['prepare','publish']:names+=['v1.4.0-'+phase+'-'+n for n in ['dispatch.json','before-runs.json','run.json','jobs-raw.json','artifacts.json']]
names+=['v1.4.0-prepare-job.log','v1.4.0-prepared-output.json','v1.4.0-prepared-extraction.json','v1.4.0-prepared-review.json','v1.4.0-published-review.json','v1.4.0-release.json','v1.4.0-latest-release.json','v1.4.0-tag.json','v1.4.0-deployment-map.json','v1.4.0-current-http-review.json','v1.4.0-live-index.json','v1.4.0-release-download-review.json']
for k in ['github-pages','release-delivery']:names+=['v1.4.0-'+k+'-download-authorized-'+n+'.json' for n in ['intent','result']]
for name in ['live-release-verification.zip','pages-live-report.json','production-smoke.json','production-smoke.png','published-release-verification.zip','pages-release-report.json']:names+=['v1.4.0-published-artifacts/'+name]
for name in ['dispatch-v140.py','read-v140-phase.py','download-v140-prepared.py','extract-v140-prepared.py','review-v140-prepared.mjs','download-v140-published.py','collect-v140-public-metadata.py','check-v140-current-http.py','download-v140-release-assets.py','read-v140-deployment.py','review-v140-published.mjs','archive-v140-published.py','update-v140-docs.py']:names+=[name]
assert len(names)==len(set(names));records=[{'path':n,'bytes':(q/n).stat().st_size,'sha256':sha((q/n).read_bytes())} for n in names]
local=[]
for n in ['v1.4.0-prepared-artifacts/github-pages.zip','v1.4.0-prepared-artifacts/release-delivery.zip']+['v1.4.0-release-downloads/'+a['name'] for a in p['assets']]:
 with (q/n).open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 local.append({'path':n,'bytes':(q/n).stat().st_size,'sha256':digest})
manifest=(json.dumps({'format':'model-lens-quantization-published-originals','source':r['source'],'tree':r['tree'],'records':records,'largeVerifiedArtifactsRetainedLocally':local,'privacy':'Public synthetic QA reports/screenshots, official metadata and reader sources only. No private models, weights, input BIN/BMP or transient download references. Large prepared artifacts and actual release downloads are hash-bound and retained locally without duplicate embedding.'},indent=2)+'\n').encode()
dest=root/'docs/results/quantization-v1.4.0-evidence.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.writestr('manifest.json',manifest)
 for n in names:z.write(q/n,n)
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None and len(z.infolist())==len(records)+1
 for v in records:assert len(z.read(v['path']))==v['bytes'] and sha(z.read(v['path']))==v['sha256']
result={**r,'format':'model-lens-quantization-published-review','preparedReview':p,'sourceSelectionProof':load('selection-merge-proof.json'),'originals':{'path':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'records':len(records),'manifestSHA256':sha(manifest)},'priorEvidence':['quantization-validation-candidate.json','quantization-dtype-followup.json','quantization-main.json'],'goalComplete':False}
(root/'docs/results/quantization-v1.4.0-published.json').open('x',encoding='utf-8').write(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'published-evidence-archived','run':r['run']['id'],'records':len(records),'bytes':dest.stat().st_size,'sha256':result['originals']['sha256']}))
