import datetime,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];phase=sys.argv[1];assert phase in ['prepare','publish']
source='685804b1a2bed1d99926ee3816b38dfa757391b6';tree='4469b419e7bbe8e5a07e26925c9ee425461e9180';repo='koviankevin/tflite-explorer';gh=r'H:\mc2llvm\.work\gh\bin\gh.exe'
p=q/('v1.4.0-'+phase+'-dispatch.json');assert not p.exists(),'Existing intent: reconcile it, never repeat dispatch.'
state={'status':'create-intent','phase':phase,'source':source,'tree':tree,'repository':repo,'workflow':'verified-pages.yml','inputs':{'publish':str(phase=='publish').lower()},'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'automaticRetries':False,'postAttempted':False}
def save():
    with p.open('w',encoding='utf-8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save()
def git(*args):return subprocess.check_output(['git',*args],cwd=root).decode('utf-8-sig').strip()
def api(route):return json.loads(subprocess.check_output([gh,'api','repos/'+repo+'/'+route],cwd=root,timeout=45).decode('utf-8-sig'))
assert git('rev-parse','HEAD')==source and git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain')
assert api('git/ref/heads/main')['object']['sha']==source
before=api('actions/workflows/verified-pages.yml/runs?head_sha='+source+'&event=workflow_dispatch&per_page=100');assert before['total_count']==len(before['workflow_runs'])
(q/('v1.4.0-'+phase+'-before-runs.json')).open('x',encoding='utf-8').write(json.dumps(before,indent=2)+'\n')
state['knownBeforeIds']=[r['id'] for r in before['workflow_runs']]
if phase=='prepare':assert before['total_count']==0
else:
    review=json.loads((q/'v1.4.0-prepared-review.json').read_bytes())
    assert review['status']=='passed-prepared-artifact-review' and review['source']==source and review['tree']==tree and review['readyForExactSourcePublish'] and not review['published']
    assert len(before['workflow_runs'])==1 and before['workflow_runs'][0]['id']==review['run'] and before['workflow_runs'][0]['conclusion']=='success'
    state['inputs'].update(expected_build_id=review['buildId'],expected_site_id=review['siteId'])
state.update(status='dispatch-intent',postAttempted=True);save()
args=[gh,'workflow','run','verified-pages.yml','--repo',repo,'--ref','main']
for k,v in state['inputs'].items():args+=['-f',k+'='+v]
try:
    r=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
    state.update(status='accepted-await-authoritative-run' if r.returncode==0 else 'dispatch-result-needs-reconciliation',exitCode=r.returncode,stdout=r.stdout.decode('utf-8','replace')[:4096],stderr=r.stderr.decode('utf-8','replace')[:4096])
except subprocess.TimeoutExpired:state['status']='unknown-dispatch-result-reconcile'
state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({k:v for k,v in state.items() if k not in ['stdout','stderr','knownBeforeIds']}))
sys.exit(0 if state['status']=='accepted-await-authoritative-run' else 1)

