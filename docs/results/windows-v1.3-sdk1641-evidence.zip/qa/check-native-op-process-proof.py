import datetime,hashlib,json,pathlib,sys
path=pathlib.Path(sys.argv[1]);output=pathlib.Path(sys.argv[2]);assert not output.exists();raw=path.read_bytes();r=json.loads(raw)
result={'format':'model-lens-native-subtree-proof-check','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'failed','reportSHA256':hashlib.sha256(raw).hexdigest(),'originalStatus':r.get('status'),'scope':'Observed owned native subtree admission and exit; never a claim about unobserved short-lived processes or continuous RSS'}
try:
 assert r['format']=='model-lens-windows-operator-validation' and r['status']=='passed' and r['functionalStatus']=='passed' and r['errors']==[]
 root=(r['root']['pid'],r['root']['startTicks']);known={(v['pid'],v['startTicks']) for v in r['processCleanup']['identities']}
 assert root in known and any(pid!=root[0] for pid,ticks in known),'Root-only coverage: no owned descendant was observed'
 snapshots=r.get('nativeProcessSnapshots',[]);assert [s['phase'] for s in snapshots]==['before-flow','before-close'],'Missing before-flow/before-close native subtree admission'
 for s in snapshots:
  rows=s['rows'];assert root in {(v['pid'],v['startTicks']) for v in rows} and any(v['pid']!=root[0] for v in rows),'Subtree sample contains only root'
  assert all((v['pid'],v['startTicks']) in known for v in rows) and all(v['state']=='R' for v in rows)
 assert r['processCleanup']['allReaped'] is True and r['processCleanup']['remaining']==[] and r['browserClosed'] is True and r['observerClose']['exitCode']==0
 assert r['workers'] and all(w['closed'] for w in r['workers']) and r['flow']['automaticRuntimeWorkers']==0
 result.update(status='passed-observed-native-subtree-proof',observedIdentities=len(known),observedWorkers=len(r['workers']),snapshotRows=[len(s['rows']) for s in snapshots],source=r['source'],release=r['release'])
except (AssertionError,KeyError) as error:result['reason']=str(error)
with output.open('x',encoding='utf8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result));sys.exit(0 if result['status']=='passed-observed-native-subtree-proof' else 1)
