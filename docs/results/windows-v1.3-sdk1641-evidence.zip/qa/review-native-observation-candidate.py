import datetime,hashlib,json,pathlib,re,subprocess
q=pathlib.Path(__file__).resolve().parent;repo=q.parents[2].with_name('tflite-explorer-native-validation');load=lambda n:json.loads((q/n).read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,encoding='utf8').strip()=='c36f82d8d8f604fd4d110e24b6fa83fd29e4be7c'
assert subprocess.check_output(['git','status','--porcelain'],cwd=repo,encoding='utf8').strip()==''
subprocess.run(['git','diff','--exit-code','7debc69df1a1c91e8ed3928a8a4932a493324180','HEAD','--','src','vendor','scripts','.github','test/browser/operator-validation-flow.mjs','docs/export-reports.md'],cwd=repo,check=True,capture_output=True)
rows=[]
for channel in ['chrome','msedge']:
 name=channel+'-nativeproof-2';r=load(name+'/report.json');state=load(name+'-status.json');log=(q/(name+'.log')).read_text('utf8',errors='replace')
 assert r['functionalStatus']=='passed' and r['errors']==[] and r['source']['commit']=='c36f82d8d8f604fd4d110e24b6fa83fd29e4be7c' and r['source']['tree']=='7446725c68bf0d7dd31b1d2169ff852b5fba8d07' and r['source']['dirty']==False
 assert r['release']['buildId']=='f6ad04ef17ebbb39' and r['release']['source']==r['source'] and r['documentFixture']['httpDocumentTransportVerified']==False
 assert r['flow']['modelWorkers']==5 and r['flow']['automaticRuntimeWorkers']==0 and r['workers'] and all(w['closed'] for w in r['workers'])
 assert sum('/src/model-worker.js?' in w['url'] for w in r['workers'])==5
 assert [(c['name'],c['status']) for c in r['flow']['cases']]==[('SPLIT','passed'),('PAD','not-run'),('SLICE','rejected'),('Large','mixed')]
 assert r['flow']['cases'][2]['downloads']==0 and r['flow']['cases'][3]['operators']==21006 and r['flow']['cases'][3]['visibleReportRows']==200
 for c in r['flow']['cases']:
  if c['name']=='SLICE':continue
  assert sha(q/name/('operand-'+c['name']+'-edited.tflite'))==c['outputSHA256']
  report=load(name+'/operand-'+c['name']+'.report.json');assert len(report['operatorValidation'])==c['operators']
  layout=c['layout'];assert layout['width']==1280 and layout['height']==640 and layout['documentWidth']<=1281 and layout['scroll']<=layout['client']+1
 snaps=r['nativeProcessSnapshots'];assert [s['phase'] for s in snaps]==['before-flow','before-close'];root=(r['root']['pid'],r['root']['startTicks'])
 final=r['processCleanup'] if channel=='msedge' else r['failureNativeObservation'];known={(x['pid'],x['startTicks']) for x in final['identities']};assert len(known)>1
 for s in snaps:
  ids={(x['pid'],x['startTicks']) for x in s['rows']};assert root in ids and len(ids)>1 and ids<=known and all(x['state']=='R' for x in s['rows'])
 assert int(snaps[0]['observedAtNs'])<int(snaps[1]['observedAtNs']) and r['observerClose']['exitCode']==0
 forced=any(marker in log for marker in ['<will force kill>','<forcefully close>'])
 if channel=='chrome':
  assert r['status']=='failed' and state['exitCode']==1 and 'normal browser.close exceeded10s' in r['error'] and len(final['rows'])==2 and forced
  close='failed-original10s; SDK later forced cleanup is not normal exit'
 else:
  assert r['status']=='passed' and state['exitCode']==0 and r['browserClosed'] and final['allReaped'] and final['remaining']==[] and not forced;close='passed-original10s-and-observed-native-subtree-exit'
 rows.append({'channel':channel,'subtreeObservationCoverage':'passed','functionalStatus':r['functionalStatus'],'originalWholeStatus':r['status'],'producerExitCode':state['exitCode'],'snapshotRows':[len(s['rows']) for s in snaps],'knownNativeIdentities':len(known),'workers':len(r['workers']),'modelWorkers':5,'normalCloseAcceptance':close,'reportSHA256':sha(q/name/'report.json'),'logSHA256':sha(q/(name+'.log'))})
assert load('native-subtree-red.json')['status']=='failed' and load('native-subtree-edge-green.json')['status']=='passed-observed-native-subtree-proof'
result={'status':'native-observation-code-change-validated','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'c36f82d8d8f604fd4d110e24b6fa83fd29e4be7c','tree':'7446725c68bf0d7dd31b1d2169ff852b5fba8d07','candidateBuild':'f6ad04ef17ebbb39','cases':rows,'applicationFilesUnchangedFromPublishedSource':True,'readyForInstrumentationMerge':True,'historicalRootCauseFixed':False,'goalComplete':False,'scope':'Validates observation coverage and preserving the actual known failure. Does not change or replace the Chrome whole-attempt failure or declare Windows acceptance complete.'}
with (q/'native-observation-code-review.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
