import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {chromium} from 'playwright';
import {windowsProcessObserver} from '../../../test/browser/windows-process-memory.mjs';
import {gitSource} from '../../../scripts/lib/release-artifact.mjs';
assert.equal(process.platform,'win32');assert.ok(process.argv.includes('--allow-local-browser'));
const variant=process.argv[2],output=process.env.CLOSE_PROBE_REPORT;assert.ok(['attached','detached'].includes(variant)&&output);
const source=gitSource();assert.equal(source.dirty,false);assert.equal(source.commit,'f592e3d9df7ed48fae2ca19e353c7215638959a3');
const pause=ms=>new Promise(r=>setTimeout(r,ms)),clock=()=>Math.round(performance.now());
const report={format:'model-lens-native-close-diagnostic',status:'failed',diagnosticOnly:true,modelAcceptance:'not evaluated',variant,source,driverSHA256:createHash('sha256').update(await readFile(new URL(import.meta.url))).digest('hex'),startedAt:new Date().toISOString(),events:[],errors:[],nativeSnapshots:[],scope:'Public empty page only,25s to expose asynchronous browser startup;normal browser.close10s unchanged;no models,downloads,application,runtime,GC orsecurity changes;Playwright may forcibly clean its owned root on driver exit after failure;not normal-close evidence.'};
const event=(kind,data={})=>report.events.push({kind,at:new Date().toISOString(),elapsedMs:clock(),...data});
let browser,context,observer,browserCDP,cdp,closing=false;
const watchdog=setTimeout(async()=>{report.errors.push('diagnostic watchdog');await writeFile(output,JSON.stringify(report,null,2)+'\n');process.exit(1);},120000);
try{
 browser=await chromium.launch({channel:'chrome',headless:true,args:['--disable-updater-scheduler']});event('launched');report.browserVersion=browser.version();browser.once('disconnected',()=>event('browser-disconnected'));
 browserCDP=await browser.newBrowserCDPSession();observer=await windowsProcessObserver({python:process.env.MODEL_LENS_QA_PYTHON,cdp:browserCDP,channel:'chrome'});report.root=observer.root;
 context=await browser.newContext();const page=await context.newPage();await context.route('**/*',route=>{report.errors.push('Unexpected network request');return route.abort();});
 await page.setContent('<!doctype html><meta charset="utf-8"><title>Public empty close diagnostic</title><p>Public synthetic empty page</p>');
 cdp=await context.newCDPSession(page);await cdp.send('Performance.enable');
 await cdp.send('Runtime.evaluate',{expression:'document.title',returnByValue:true});await cdp.send('Runtime.getHeapUsage');await cdp.send('Memory.getDOMCounters');
 report.nativeSnapshots.push({phase:'before-idle',...await observer.sample()});event('idle-start');await pause(25000);event('idle-end');
 const beforeClose=await observer.sample();report.nativeSnapshots.push({phase:'before-close',...beforeClose});report.rolesBeforeClose=JSON.parse(execFileSync(process.env.MODEL_LENS_QA_PYTHON,[fileURLToPath(new URL('../windows-large/close-owned-roles.py',import.meta.url))],{input:JSON.stringify({rootPid:observer.root.pid,rows:beforeClose.rows}),encoding:'utf8',windowsHide:true,timeout:20000}));
 if(variant==='detached'){event('observer-detach-start');await cdp.detach();await browserCDP.detach();event('observer-detach-end');}
 event('context-close-start');await context.close();context=null;event('context-close-end');
 closing=true;event('browser-close-start');let timer;
 try{await Promise.race([browser.close(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('normal browser.close exceeded10s')),10000);})]);}finally{clearTimeout(timer);}
 event('browser-close-end');report.browserClosed=true;
 const until=Date.now()+7000;let result;do{result=await observer.remaining();if(result.rows.length)await pause(100);}while(result.rows.length&&Date.now()<until);
 report.processCleanup={allReaped:result.rows.length===0,remaining:result.rows,identities:result.identities};assert.ok(report.processCleanup.allReaped);
 assert.deepEqual(report.errors,[]);assert.deepEqual(gitSource(),source);report.status='completed-diagnostic';
}catch(e){report.error=e.stack||String(e);event('failed',{message:e.message});if(observer)report.failureNativeObservation=await observer.remaining().catch(e=>({error:e.message}));if(report.failureNativeObservation?.rows?.length)try{report.rolesAtFailure=JSON.parse(execFileSync(process.env.MODEL_LENS_QA_PYTHON,[fileURLToPath(new URL('../windows-large/close-owned-roles.py',import.meta.url))],{input:JSON.stringify({rootPid:observer.root.pid,rows:report.failureNativeObservation.rows}),encoding:'utf8',windowsHide:true,timeout:20000}));}catch(e){report.rolesAtFailure={error:e.message};}}
finally{
 if(!closing&&browser){try{await context?.close();let t;try{await Promise.race([browser.close(),new Promise((_,reject)=>{t=setTimeout(()=>reject(Error('setup cleanup close exceeded10s')),10000);})]);}finally{clearTimeout(t);}}catch(e){report.errors.push(e.message);}}
 if(observer)try{report.observerClose=await observer.close();}catch(e){report.status='failed';report.errors.push(e.message);}
 report.finishedAt=new Date().toISOString();clearTimeout(watchdog);await writeFile(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({status:report.status,variant,root:report.root,error:report.error,events:report.events,remaining:report.failureNativeObservation?.rows}));process.exit(report.status==='completed-diagnostic'?0:1);
}
