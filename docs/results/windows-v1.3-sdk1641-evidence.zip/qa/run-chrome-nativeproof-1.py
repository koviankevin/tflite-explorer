import datetime,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path('D:\\Users\\kovia\\OneDrive\\文件\\ChatGPT\\Tflite\\tflite-explorer-native-validation');out=q/'chrome-nativeproof-1';log=q/'chrome-nativeproof-1.log';status=q/'chrome-nativeproof-1-status.json'
assert not out.exists() and not log.exists() and not status.exists()
state={'status':'create-intent','channel':'chrome','source':'c36f82d8d8f604fd4d110e24b6fa83fd29e4be7c','build':'f6ad04ef17ebbb39','output':str(out),'cleanup':'Retain all actual results'}
def save():
 with status.open('w',encoding='utf8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save()
node=r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
bootstrap="const timer=setTimeout(()=>{console.error('Whole process240s failed; not normalexit');process.exit(1)},240000);timer.unref();await import('./test/browser/windows-operator-validation.mjs');"
args=[node,'--input-type=module','-e',bootstrap,'chrome',str(repo/'build/qa/native-observation-candidate-2'),str(out),'--allow-local-browser']
# -e exposes arguments at argv1; preserve the canonical script argv2 contract.
bootstrap="process.argv.splice(1,0,'test/browser/windows-operator-validation.mjs');"+bootstrap;args[4]=bootstrap
with log.open('xb') as f:
 p=subprocess.Popen(args,cwd=repo,env={**os.environ,'MODEL_LENS_QA_PYTHON':sys.executable,'DEBUG':'pw:browser'},stdout=f,stderr=subprocess.STDOUT);state.update(status='running',pid=p.pid);save();code=p.wait()
state.update(status='producer-exited',exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(json.dumps(state));sys.exit(code)
