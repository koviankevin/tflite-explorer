import base64,hashlib,io,json,pathlib,stat,sys,urllib.request,zipfile
q=pathlib.Path(__file__).resolve().parent;kind=sys.argv[1];assert kind in ['core','contract'];prefix='core-performance' if kind=='core' else 'release-contract'
run=json.loads((q/('pr195-v2-'+kind+'-run.json')).read_bytes());jobs=json.loads((q/('pr195-v2-'+kind+'-jobs.json')).read_bytes());meta=json.loads((q/('pr195-v2-'+kind+'-artifacts.json')).read_bytes())
assert run['status']=='completed' and run['conclusion']=='success' and run['event']=='pull_request' and run['head_sha']=='c36f82d8d8f604fd4d110e24b6fa83fd29e4be7c' and run['run_attempt']==1
assert len(jobs['jobs'])==1 and jobs['jobs'][0]['conclusion']=='success' and meta['total_count']==len(meta['artifacts'])==1;a=meta['artifacts'][0]
assert a['name']==prefix+'-08bf7ae614eee67b8069db9244a5eca6ccef2c4e-1' and not a['expired'] and a['workflow_run']['id']==run['id'] and a['workflow_run']['head_sha']==run['head_sha']
archive=q/('pr195-v2-'+kind+'.zip');output=q/('pr195-v2-'+kind+'-report.json');assert not archive.exists() and not output.exists()
url=base64.b64decode(sys.argv[2]).decode('utf8');assert url.startswith('https://')
with urllib.request.urlopen(url,timeout=30) as response:raw=response.read(4*1024**2+1)
del url
assert len(raw)==a['size_in_bytes'] and 'sha256:'+hashlib.sha256(raw).hexdigest()==a['digest']
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 assert z.namelist()==[prefix+'-'+str(run['id'])+'-1.json'] and z.testzip() is None;i=z.infolist()[0];assert i.file_size<=4*1024**2 and not i.is_dir() and stat.S_IFMT(i.external_attr>>16) in [0,stat.S_IFREG];body=z.read(i)
json.loads(body)
with archive.open('xb') as f:f.write(raw)
with output.open('xb') as f:f.write(body)
print(json.dumps({'status':'provider-digest-crc-source-and-paths-verified','kind':kind,'artifact':a['id'],'digest':a['digest'],'reportBytes':len(body),'reportSHA256':hashlib.sha256(body).hexdigest()}))
