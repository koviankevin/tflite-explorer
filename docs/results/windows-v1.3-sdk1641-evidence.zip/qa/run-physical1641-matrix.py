import datetime,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];status=q/'physical1641-matrix-status.json'
assert not status.exists(),'Reconcile actual existing controller/process before another run'
state={'status':'create-intent','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controllerPid':os.getpid(),'cases':[],'automaticRetries':False,'sequential':True,'cleanup':'Retain all physical fixtures, reports and raw failures'}
def save():
 temp=status.with_suffix('.tmp')
 with temp.open('w',encoding='utf8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(temp,status)
save()
native=root/'test/browser/windows-process-memory.py';scope={'__name__':'owned_census'};exec(compile(native.read_text('utf8').split('observer=Observer()')[0],str(native),'exec'),scope)
def assert_exited(report):
 table=scope['snapshot']();live=[]
 for identity in report.get('windowsObservedIdentities',[]):
  row=table.get(identity['pid'])
  if row:
   found=scope['inspect']({**row,'startTicks':identity['startTicks']})
   if found:live.append(found)
 assert not live,'Previous owned browser identities remain live; no second case started'
node=r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
try:
 for channel in ['chrome','msedge']:
  out=q/(channel+'-physical1641-1.json');log=q/(channel+'-physical1641-1.log');assert not out.exists() and not log.exists()
  case={'channel':channel,'report':str(out),'log':str(log),'status':'create-intent'};state['cases'].append(case);save()
  env={**os.environ,'LIFECYCLE_MODE':'gate','MODEL_LENS_BROWSER_CHANNEL':channel,'MODEL_LENS_QA_PYTHON':sys.executable,'MODEL_LENS_TRUSTED_BOOTSTRAP':'1','LIFECYCLE_BUILD':str(root/'build/qa/op-validation/v1.3.0-prepared-artifacts/core'),'LIFECYCLE_REPORT':str(out),'DEBUG':'pw:browser'}
  with log.open('xb') as f:
   process=subprocess.Popen([node,str(q/'model-lifecycle-sdk1641.mjs'),'--allow-local-browser'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
   case.update(status='running',pid=process.pid,startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());state['status']='running';save();print(json.dumps(case),flush=True);code=process.wait()
  case.update(status='producer-exited',exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
  assert out.exists(),'Producer ended without report; preserve and inspect before next case';report=json.loads(out.read_bytes());case['reportedStatus']=report['status'];assert_exited(report);case['nativeIdentitiesReconciledExited']=True;save();print(json.dumps(case),flush=True)
 state['status']='completed-no-retries'
except Exception as error:state.update(status='stopped-needs-reconciliation',errorType=type(error).__name__,reason=str(error));raise
finally:state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(state),flush=True)
sys.exit(0 if state['status']=='completed-no-retries' and all(c['exitCode']==0 for c in state['cases']) else 1)
