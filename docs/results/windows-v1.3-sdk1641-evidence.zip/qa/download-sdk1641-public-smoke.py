import base64,hashlib,io,json,pathlib,stat,sys,urllib.request,zipfile
q=pathlib.Path(__file__).resolve().parent;run=json.loads((q/'sdk1641-public-run.json').read_bytes());jobs=json.loads((q/'sdk1641-public-jobs.json').read_bytes());meta=json.loads((q/'sdk1641-public-artifacts.json').read_bytes())
assert run['id']==41225507999 and run['status']=='completed' and run['head_sha']=='26523731a00e6bf08954d6f7ba94c29178652d58' and run['run_attempt']==1
assert run['path']=='.github/workflows/production-smoke.yml' and run['event']=='workflow_dispatch' and run['head_branch']=='main'
a=[a for a in meta['artifacts'] if a['name']=='production-smoke'];assert len(a)==1;a=a[0];assert not a['expired'] and a['workflow_run']['id']==run['id'] and a['workflow_run']['head_sha']==run['head_sha']
archive=q/'sdk1641-public-original.zip';assert not archive.exists();url=base64.b64decode(sys.argv[1]).decode('utf8');assert url.startswith('https://')
with urllib.request.urlopen(url,timeout=30) as response:raw=response.read(8*1024**2+1)
del url
assert len(raw)==a['size_in_bytes'] and 'sha256:'+hashlib.sha256(raw).hexdigest()==a['digest']
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 names=z.namelist();assert 1<=len(names)<=2 and set(names)<={'production-smoke.json','production-smoke.png'} and len(set(names))==len(names) and z.testzip() is None
 for i in z.infolist():assert not i.is_dir() and stat.S_IFMT(i.external_attr>>16) in [0,stat.S_IFREG] and i.file_size<=4*1024**2
 outputs=[(archive,raw)]+[(q/('sdk1641-public-'+n),z.read(n)) for n in names]
for path,data in outputs:
 with path.open('xb') as f:f.write(data)
print(json.dumps({'status':'actual-public-artifact-digest-crc-reviewed','originalRunConclusion':run['conclusion'],'artifact':a['id'],'bytes':len(raw),'digest':a['digest'],'files':names}))
