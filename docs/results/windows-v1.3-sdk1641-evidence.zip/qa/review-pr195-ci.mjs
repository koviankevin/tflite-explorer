import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {readArtifact} from '../../../scripts/lib/release-gates.mjs';
import {evaluatePerformanceRun} from '../../../scripts/lib/performance-policy.mjs';
const q=path.dirname(fileURLToPath(import.meta.url)),load=async n=>JSON.parse(await readFile(path.join(q,n),'utf8')),sha=b=>createHash('sha256').update(b).digest('hex');
const head='c36f82d8d8f604fd4d110e24b6fa83fd29e4be7c',checkout='08bf7ae614eee67b8069db9244a5eca6ccef2c4e',tree='7446725c68bf0d7dd31b1d2169ff852b5fba8d07';assert.deepEqual(await load('pr195-ci-checkout.json'),{commit:checkout,tree});
const details={};
for(const kind of ['node','contract','core']){
 const run=await load(`pr195-v2-${kind}-run.json`),jobs=(await load(`pr195-v2-${kind}-jobs.json`)).jobs,art=(await load(`pr195-v2-${kind}-artifacts.json`)).artifacts,log=await load(`pr195-v2-${kind}-log.json`);
 assert.equal(run.status,'completed');assert.equal(run.conclusion,'success');assert.equal(run.head_sha,head);assert.equal(run.event,'pull_request');assert.equal(run.run_attempt,1);assert.equal(run.repository.full_name,'koviankevin/tflite-explorer');assert.equal(jobs.length,1);assert.equal(jobs[0].conclusion,'success');assert.ok(log.includes(checkout));
 details[kind]={run:run.id,job:jobs[0].id};
 if(kind==='node'){for(const line of ['# tests 878','# pass 843','# fail 0','# skipped 35','# cancelled 0'])assert.ok(log.includes(line));assert.ok(jobs[0].steps.some(s=>s.name==='Run node scripts/build.mjs'&&s.conclusion==='success'));continue;}
 assert.equal(art.length,1);const a=art[0];assert.equal(a.expired,false);assert.equal(a.workflow_run.id,run.id);assert.equal(a.workflow_run.head_sha,head);const raw=await readFile(path.join(q,`pr195-v2-${kind}.zip`)),decoded=readArtifact(raw,a.digest),r=decoded.report;assert.equal(r.status,'passed');assert.equal(r.source.commit,checkout);assert.equal(r.source.tree,tree);assert.equal(r.source.dirty,false);assert.equal(r.sourceUnchanged,true);
 if(kind==='contract'){assert.deepEqual(r.counts,{tests:78,pass:78,fail:0,skipped:0,cancelled:0});assert.equal(r.plan.required,true);assert.equal(r.node,'v22.23.3');details[kind].counts=r.counts;}
 else{const policy=JSON.parse(await readFile(new URL('../../../test/performance-policy.json',import.meta.url),'utf8'));assert.deepEqual(r.policy,policy);assert.deepEqual(evaluatePerformanceRun(policy,r.samples),r.gate);assert.equal(r.gate.status,'passed');assert.equal(r.samples.length,9);assert.equal(r.referenceEnvironment,true);assert.equal(r.environment.githubRunId,String(run.id));assert.equal(sha(Buffer.from(JSON.stringify(r.source.files))),r.source.fingerprint);details[kind].samples=9;details[kind].sourceFingerprint=r.source.fingerprint;}
 details[kind].artifact=a.id;details[kind].providerDigest=a.digest;details[kind].reportSHA256=decoded.sha256;
}
const result={status:'required-PR-checks-independently-reviewed',at:new Date().toISOString(),head,checkout,tree,details,scope:'PR evidence only; never a substituted main release gate or a claim to repair native Chrome shutdown',goalComplete:false};await writeFile(path.join(q,'pr195-ci-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
