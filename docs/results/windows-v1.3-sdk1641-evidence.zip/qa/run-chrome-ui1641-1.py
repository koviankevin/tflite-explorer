import datetime,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];out=q/'chrome-ui1641-1';log=q/'chrome-ui1641-1.log';status=q/'chrome-ui1641-1-status.json'
assert not out.exists() and not log.exists() and not status.exists()
state={'status':'create-intent','case':'chrome','outputs':[str(out),str(log)],'cleanup':'Preserve public synthetic results; no deletion authorized'}
def save():
 with status.open('w',encoding='utf8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save()
env={**os.environ,'MODEL_LENS_QA_PYTHON':sys.executable,'DEBUG':'pw:browser'}
node=r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
with log.open('xb') as f:
 p=subprocess.Popen([node,str(q/'windows-operator-sdk1641.mjs'),'chrome',str(root/'build/qa/op-validation/v1.3.0-prepared-artifacts/core'),str(out),'--allow-local-browser'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT);state.update(status='running',pid=p.pid);save();code=p.wait()
state.update(status='producer-exited',exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(json.dumps(state));sys.exit(code)
