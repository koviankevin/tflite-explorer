import datetime,hashlib,json,os,pathlib,subprocess,sys,time,urllib.error,urllib.request
q=pathlib.Path(__file__).resolve().parent;output=q/'sdk1641-public-smoke-dispatch.json';assert not output.exists(),'Reconcile any existing POST/run before another dispatch'
source='26523731a00e6bf08954d6f7ba94c29178652d58';tree='7446725c68bf0d7dd31b1d2169ff852b5fba8d07';body={'ref':'main','inputs':{'scenario':'production','expected_build_id':'44782d0412ebc0b8'}}
state={'status':'create-intent','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source,'tree':tree,'workflow':'production-smoke.yml','inputs':body['inputs'],'postAttempted':False,'scope':'Verify current unchanged public v1.3.0 with the merged SDK; read-only to website, no deployment or fixed asset mutation','credentials':'Existing gh token memory-only; api.github.com only, authenticated redirects refused'}
def save():
 p=output.with_suffix('.tmp')
 with p.open('w',encoding='utf8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(p,output)
save()
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):raise urllib.error.HTTPError(req.full_url,code,'Authenticated redirect refused',headers,fp)
try:
 result=subprocess.run([r'H:\mc2llvm\.work\gh\bin\gh.exe','auth','token','--hostname','github.com'],capture_output=True,timeout=240);assert result.returncode==0
 token=result.stdout.decode('ascii').strip();assert 20<=len(token)<=1000 and not any(c.isspace() for c in token);opener=urllib.request.build_opener(NoRedirect)
 def api(route,data=None):
  assert route.startswith('repos/koviankevin/tflite-explorer/')
  if data is not None:assert route=='repos/koviankevin/tflite-explorer/actions/workflows/production-smoke.yml/dispatches' and data==body
  req=urllib.request.Request('https://api.github.com/'+route,data=json.dumps(data).encode() if data is not None else None,method='POST' if data is not None else 'GET',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'ModelLens-Authorized-Public-Verification','Content-Type':'application/json'})
  with opener.open(req,timeout=30) as response:raw=response.read(8*1024**2+1);assert len(raw)<=8*1024**2;return response.status,json.loads(raw) if raw else None
 _,main=api('repos/koviankevin/tflite-explorer/commits/main');assert main['sha']==source and main['commit']['tree']['sha']==tree
 with urllib.request.urlopen('https://koviankevin.github.io/tflite-explorer/site-manifest.json',timeout=30) as response:raw=response.read(4*1024**2+1)
 assert hashlib.sha256(raw).hexdigest()=='55708e5f85b34b0cbe041efb508a8f23d6b1cb5ea60e0ee6c349e13d2046ff7e';live=json.loads(raw);assert live['current']['release']['buildId']==body['inputs']['expected_build_id'] and live['current']['release']['source']['commit']=='7debc69df1a1c91e8ed3928a8a4932a493324180'
 listing='repos/koviankevin/tflite-explorer/actions/runs?head_sha='+source+'&event=workflow_dispatch&per_page=100';_,before=api(listing)
 assert not any(r['path']=='.github/workflows/production-smoke.yml' for r in before['workflow_runs']),'Existing workflow found; reconcile rather than repeat'
 state.update(status='dispatching',postAttempted=True,publicIdentityMatched=True,mainLeaseMatched=True);save();status,_=api('repos/koviankevin/tflite-explorer/actions/workflows/production-smoke.yml/dispatches',body);assert status in [200,204]
 state.update(status='accepted-awaiting-run',httpStatus=status,acceptedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 for _ in range(18):
  _,after=api(listing);runs=[r for r in after['workflow_runs'] if r['path']=='.github/workflows/production-smoke.yml' and r['head_sha']==source]
  if runs:
   assert len(runs)==1;state.update(status='dispatched',run=runs[0]['id'],url=runs[0]['html_url']);save();break
  time.sleep(5)
except Exception as error:
 state.update(status='unknown-post-result-reconcile' if state['postAttempted'] else 'failed-before-post',errorType=type(error).__name__)
 if isinstance(error,urllib.error.HTTPError):state['httpStatus']=error.code
finally:state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(state),flush=True);sys.exit(0 if state['status']=='dispatched' else 1)
