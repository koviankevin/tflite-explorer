import base64,hashlib,json,os,pathlib,shutil,stat,tarfile,urllib.parse,urllib.request
q=pathlib.Path(__file__).resolve().parent;out=q/'sdk1641';archive=q/'sdk1641.tgz';metadata=q/'sdk1641-registry.json'
assert not out.exists() and not archive.exists() and not metadata.exists()
with urllib.request.urlopen('https://registry.npmjs.org/playwright-core/1.64.1',timeout=30) as response:raw=response.read(2*1024**2+1)
assert len(raw)<=2*1024**2;m=json.loads(raw);assert m['name']=='playwright-core' and m['version']=='1.64.1' and not m.get('dependencies')
dist=m['dist'];url=urllib.parse.urlparse(dist['tarball']);assert url.scheme=='https' and url.hostname=='registry.npmjs.org' and url.path=='/playwright-core/-/playwright-core-1.64.1.tgz'
assert dist['integrity'].startswith('sha512-');expected=base64.b64decode(dist['integrity'][7:],validate=True);assert len(expected)==64
with metadata.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
digest=hashlib.sha512();count=0
with urllib.request.urlopen(dist['tarball'],timeout=30) as response,archive.open('xb') as f:
 while True:
  chunk=response.read(1024**2)
  if not chunk:break
  count+=len(chunk);assert count<=32*1024**2;digest.update(chunk);f.write(chunk)
 f.flush();os.fsync(f.fileno())
assert digest.digest()==expected
reserved={'CON','PRN','AUX','NUL'}|{'COM'+str(i) for i in range(1,10)}|{'LPT'+str(i) for i in range(1,10)}
with tarfile.open(archive,'r:gz') as t:
 items=t.getmembers();assert 0<len(items)<=8192 and sum(i.size for i in items if i.isfile())<=128*1024**2;names=set()
 for i in items:
  assert i.isfile() or i.isdir();p=pathlib.PurePosixPath(i.name);assert p.parts[0]=='package' and not p.is_absolute() and '\\' not in i.name and ':' not in i.name and '\x00' not in i.name
  assert all(x not in ('','..','.') and not x.endswith((' ','.')) and x.split('.')[0].upper() not in reserved for x in p.parts)
  assert i.name.casefold() not in names;names.add(i.name.casefold())
 out.mkdir()
 for i in items:
  p=out/pathlib.Path(*pathlib.PurePosixPath(i.name).parts);assert p.resolve().is_relative_to(out.resolve())
  if i.isdir():p.mkdir(parents=True,exist_ok=True)
  else:
   p.parent.mkdir(parents=True,exist_ok=True)
   with t.extractfile(i) as src,p.open('xb') as dst:shutil.copyfileobj(src,dst,1024**2)
package=json.loads((out/'package/package.json').read_bytes());assert package['version']=='1.64.1' and package['name']=='playwright-core'
browsers=json.loads((out/'package/browsers.json').read_bytes());assert next(x for x in browsers['browsers'] if x['name']=='chromium')['browserVersion']=='156.0.8078.4'
result={'status':'isolated-SDK-integrity-and-paths-verified','package':'playwright-core','version':'1.64.1','archiveBytes':count,'integrity':dist['integrity'],'archiveSHA256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(items),'projectDependenciesUnchanged':True,'browserDownloaded':False}
with (q/'sdk1641-acquisition.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
