import datetime,hashlib,json,os,pathlib,re
q=pathlib.Path(__file__).resolve().parent;load=lambda n:json.loads((q/n).read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cases=[]
for name in ['baseline-1','stdio-1','stdio-2','baseline-2','stdio-3','sdk1641-1','sdk1641-2']:
 r=load(name+'.json');s=load(name+'-status.json');log=(q/(name+'.log')).read_text('utf8',errors='replace');events={e['kind']:e['elapsedMs'] for e in r['events']}
 assert s['status']=='producer-exited' and s['exitCode'] in [0,1]
 row={'case':name,'status':r['status'],'producerExitCode':s['exitCode'],'reportSHA256':sha(q/(name+'.json')),'logSHA256':sha(q/(name+'.log'))}
 if name=='stdio-1':
  assert s['exitCode']==1 and 'input.on is not a function' in r['error'] and 'browser-close-start' not in events
  assert load('stdio-1-orphan-census.json')['nativeIdentity'] is None;row['classification']='setup-interface failure; not a shutdown result'
 elif name=='baseline-1':
  assert s['exitCode']==1 and r['status']=='failed' and 'normal browser.close exceeded10s' in r['error'];assert events['failed']-events['browser-close-start']>=10000
  roles=r['rolesAtFailure']['roles'];assert len(roles)==2 and all(x['identityStillMatches'] for x in roles) and {x['type'] for x in roles}=={'untyped','crashpad-handler'}
  assert '<will force kill>' in log;row.update(classification='original10s failure; subsequent SDK forced cleanup not normal exit',closeMs=events['failed']-events['browser-close-start'],disconnectMs=events['browser-disconnected']-events['browser-close-start'])
 else:
  assert s['exitCode']==0 and r['status']=='completed-diagnostic' and r['browserClosed'] and r['errors']==[] and r['observerClose']['exitCode']==0
  assert r['browserVersion']=='156.0.8078.76' and r['processCleanup']['allReaped'] and r['processCleanup']['remaining']==[]
  assert events['idle-end']-events['idle-start']>=25000 and 0<events['browser-close-end']-events['browser-close-start']<10000
  assert '<will force kill>' not in log and '<forcefully close>' not in log and '<kill>' not in log and 'exitCode=0, signal=null' in log
  if name.startswith('stdio-'):assert r['control']['launchesIntercepted']==1 and r['control']['remoteDebuggingPipeUnchanged']
  if name.startswith('sdk1641-'):assert r['sdkVersion']=='1.64.1'
  row.update(closeMs=events['browser-close-end']-events['browser-close-start'],observedNativeIdentities=len(r['processCleanup']['identities']),normalNativeExit=True)
 cases.append(row)
ui=[]
for channel in ['chrome','msedge']:
 name=channel+'-ui1641-1';r=load(name+'/report.json');state=load(name+'-status.json');log=(q/(name+'.log')).read_text('utf8',errors='replace')
 assert state['status']=='producer-exited' and state['exitCode']==0 and r['status']=='passed' and r['functionalStatus']=='passed' and r['sdkVersion']=='1.64.1' and r['errors']==[]
 assert r['source']['commit']=='3f2115cbb71e9f8797ba0a0a617167de5144e463' and r['release']['source']['commit']=='7debc69df1a1c91e8ed3928a8a4932a493324180' and r['release']['buildId']=='44782d0412ebc0b8'
 assert r['documentFixture']['httpDocumentTransportVerified'] is False and r['browserClosed'] and r['processCleanup']['allReaped'] and r['processCleanup']['remaining']==[] and r['observerClose']['exitCode']==0
 assert len(r['workers'])==7 and all(w['closed'] for w in r['workers']) and r['flow']['modelWorkers']==5 and r['flow']['automaticRuntimeWorkers']==0
 assert sum('/src/model-worker.js?' in w['url'] for w in r['workers'])==5 and sum('/vendor/netron/worker.js?' in w['url'] for w in r['workers'])==1 and sum('/src/edit-recovery-worker.js?' in w['url'] for w in r['workers'])==1
 assert [(c['name'],c['status']) for c in r['flow']['cases']]==[('SPLIT','passed'),('PAD','not-run'),('SLICE','rejected'),('Large','mixed')]
 assert r['flow']['cases'][2]['downloads']==0 and r['flow']['cases'][3]['operators']==21006 and r['flow']['cases'][3]['visibleReportRows']==200
 for c in r['flow']['cases']:
  if c['name']=='SLICE':continue
  layout=c['layout'];assert layout['width']==1280 and layout['height']==640 and layout['documentWidth']<=1281 and layout['scroll']<=layout['client']+1
  output=q/name/('operand-'+c['name']+'-edited.tflite');assert sha(output)==c['outputSHA256']
  exported=load(name+'/operand-'+c['name']+'.report.json');assert len(exported['operatorValidation'])==c['operators']
 assert '<will force kill>' not in log and '<forcefully close>' not in log and '<kill>' not in log and 'exitCode=0, signal=null' in log
 ui.append({'channel':channel,'browserVersion':r['browserVersion'],'status':'original-OP-flow-and-normal-native-exit-passed','appSource':r['release']['source']['commit'],'driverSource':r['source']['commit'],'sdkVersion':r['sdkVersion'],'workers':7,'modelWorkers':5,'automaticRuntimeWorkers':0,'cases':4,'completeJSONRows':21006,'visibleRows':200,'reportSHA256':sha(q/name/'report.json'),'logSHA256':sha(q/(name+'.log')),'nativeIdentities':len(r['processCleanup']['identities'])})
result={'status':'controls-and-current-published-UI-independently-reviewed','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controls':cases,'currentPublishedUI':ui,'findings':['Original1.56.1 empty-page configuration both fails and passes; one-factor stdio comparison does not establish causality.','New1.64.1 uses Chromium156 generation and passed two empty controls plus exactv1.3.0 original OP flow on installedChrome/Edge. This is compatibility evidence, not proof of the historical shutdown root cause.','The setup-interface failure is excluded from shutdown comparisons and retained.','Physical1GiB/RSS acceptance is separate and still pending; no projection from64-byte-report fixture or empty pages.'],'projectOrProductionChange':False,'goalComplete':False}
with (q/'events.jsonl').open('a',encoding='utf8') as f:json.dump({'event':'create_intent','operation_id':'review-controls-ui','path':str(q/'controls-ui-review.json'),'purpose':'Independent original deadline/native rows, SDK cleanup logs, actual downloaded JSON/TFLite and UI recheck','cleanup_condition':'Retain audit proof'},f);f.write('\n');f.flush();os.fsync(f.fileno())
with (q/'controls-ui-review.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'status':result['status'],'controls':[(x['case'],x['status'],x.get('closeMs')) for x in cases],'currentPublishedUI':ui,'historicalRootCauseFixed':False,'physicalAcceptance':'pending','goalComplete':False}))
