# v1.3.0 Windows / SDK 1.64.1 evidence

This archive preserves original public synthetic reports, positive and negative results,
native PID/creation-time samples, setup failures, driver overlays, CI provider ZIPs and
independent readers. No original evidence bytes were rewritten. manifest.json binds
every input and deduplicated member with SHA-256. Large TFLite metadata fixtures stay
local with hashes; physical 1.25 GiB weight files are not copied into the repository.

Exact public app: 7debc69df1a1c91e8ed3928a8a4932a493324180 / build 44782d0412ebc0b8.
Physical driver: 3f2115cbb71e9f8797ba0a0a617167de5144e463 with explicitly isolated,
integrity-checked SDK 1.64.1, original eight-cycle and memory/10-second close policies.
Chrome: memory/export sub-checks passed, WHOLE ATTEMPT FAILED normal close; subsequent
SDK forced cleanup is preserved and is never classified as normal native exit.
Edge: whole physical attempt passed, including observed native normal exit.

New canonical native OP driver: c36f82d8d8f604fd4d110e24b6fa83fd29e4be7c, merged through
PR195 as 26523731a00e6bf08954d6f7ba94c29178652d58 with equal full Git tree. Observed
subtree coverage is fixed; Chrome close root cause is NOT fixed. Old root-only UI
reports do not establish child-process exit. Earlier setup-only failures ran no cycles.

Current public website: read-only run 41225507999, all 35 cases passed with new SDK.
This is not a deployment, a replacement fixed asset, a new Windows physical acceptance
gate, or proof that any arbitrary operator/kernel is runnable. The product remains 1.3.0.

Readers retain original source-relative imports. Restore qa/ under build/qa/native-close-
followup of the appropriate recorded Git source, and source/ as reference snapshots.
Do not automatically execute controllers: they can start isolated browsers or dispatch
workflows. Original source commits, runtime policy, provider digest, CRC and report
assertions must be independently checked before interpreting any outcome.

No forced GC, RSS subtraction/trimming, fabricated worker closure, safety rule changes,
mobile/Firefox/WebKit browser acceptance, private models, or new two-hour soak.
