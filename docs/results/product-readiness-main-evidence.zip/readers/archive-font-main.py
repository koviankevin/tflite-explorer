import datetime,hashlib,io,json,os,pathlib,subprocess,zipfile
q=pathlib.Path(__file__).resolve().parent;repo=q.parents[2];out=repo/'docs/results'
load=lambda n:json.loads((q/n).read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
source='bb3bd37d215b30ae46eab97f63776d3e213d0a82'
archive=out/'product-readiness-main-evidence.zip';receipt_path=out/'product-readiness-main-verification.json'
assert not archive.exists() and not receipt_path.exists(), 'Inspect existing deliverables, never overwrite'
reviews={k:load(f'font-main-{k}-review.json') for k in ['browser','contract','site']}
for kind,v in reviews.items():assert v['status']=='passed-original-gate-review' and v['source']==source
core=load('font-main-core-reuse-review.json');smoke=load('font-main-delivery-smoke-review.json')
assert core['status']=='core-evidence-reusable' and core['files']==88 and core['source']==source
assert smoke['status']=='passed-reviewed' and smoke['source']==source and smoke['checks']==34 and smoke['fontFrames']==15
files={}
def add(name,p):
    b=p.read_bytes();assert 0<len(b)<=8*1024**2,(name,len(b));assert name not in files
    files[name]=b
for suffix in ['run.json','jobs.json','artifacts.json','artifact.zip','review.json']:
    add('core/main-core-'+suffix,q/('main-core-'+suffix))
for kind in ['browser','contract','site']:
    for suffix in ['run.json','jobs.json','artifacts.json','artifact.zip','report.json','review.json']:
        add(kind+'/font-main-'+kind+'-'+suffix,q/('font-main-'+kind+'-'+suffix))
    r=load(f'font-main-{kind}-run.json');a=load(f'font-main-{kind}-artifacts.json')['artifacts'];v=reviews[kind]
    assert r['status']=='completed' and r['conclusion']=='success' and r['head_sha']==source and r['run_attempt']==1
    chosen=[x for x in a if x['id']==v['artifactId']];assert len(chosen)==1
    raw=(q/f'font-main-{kind}-artifact.zip').read_bytes();assert 'sha256:'+sha(raw)==chosen[0]['digest']==v['providerDigest']
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        assert z.testzip() is None and len(z.namelist())==1
        b=z.read(z.namelist()[0]);assert b==(q/f'font-main-{kind}-report.json').read_bytes();assert sha(b)==v['reportSHA256']
for name in ['font-main-core-reuse-review.json','font-main-docs-source-reuse-review.json','font-main-delivery-smoke.zip','font-main-delivery-smoke.json','font-main-delivery-smoke.png','font-main-delivery-smoke-review.json','font-main-archive-integrity-review.json','chrome5-terminal-identities-review.json','pr184-ci-review.json']:
    add('reviews/'+name,q/name)
for name in ['review-font-main-gate.mjs','review-font-core-reuse.mjs','review-font-delivery-smoke.mjs','download-font-main-gate.py','download-font-delivery-smoke.py','archive-font-main.py']:
    add('readers/'+name,q/name)
git=lambda args:subprocess.check_output(['git',*args],cwd=repo)
head=git(['rev-parse','HEAD']).decode().strip()
changed=git(['diff','--name-only',source,head]).decode().splitlines()
assert all(n in ['docs/font-reflow.md','docs/known-issues.md','docs/model-edit-workspace.md','docs/product-readiness-next.md'] for n in changed),changed
for name in ['LICENSE','vendor/netron/LICENSE','test/performance-policy.json','test/browser/lifecycle-policy.mjs','test/browser/runtime-lifecycle-policy.mjs','scripts/lib/release-gates.mjs']:
    files['tested-source/'+name]=git(['show',source+':'+name])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,b in sorted(files.items()):z.writestr(name,b)
members=[]
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(files)
    for name,b in sorted(files.items()):
        assert z.read(name)==b
        members.append(dict(path=name,bytes=len(b),sha256=sha(b)))
raw=archive.read_bytes()
receipt=dict(format='model-lens-product-readiness-main-verification',version=1,status='required-main-gates-reviewed-not-published',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),testedApplicationSource=source,testedApplicationTree='e255abf8e399538f2a4b31de8e188b0c00bfc4fd',archiveFromLocalHead=head,
    core=core,browser=reviews['browser'],contract=reviews['contract'],site=reviews['site'],fullWebsiteSmoke=smoke,
    priorEvidence=['product-readiness-stage1.json','product-readiness-stage2.json','product-readiness-stage3.json','product-readiness-stage3-update.json','font-reflow-verification.json'],
    archive=dict(path=archive.name,bytes=len(raw),sha256=sha(raw),members=members),
    remaining=['Formal exact-source prepare, inspected immutable artifact then same-build/site publication, live HTTPS and fixed Release verification.','Full Windows physical Chrome normal-close remains failed; no root-cause fix is claimed.','Unknown custom references remain conservative; arbitrary kernel/dialect/packing semantics and historical startup timeout root cause remain unverified.'],
    constraints=['No mobile/Firefox/WebKit/company data/new two-hour soak.','No automatic interpreter during ordinary edit/export.','No forced GC, RSS subtraction, changed thresholds/timers/security rules or successful deployment reruns.','No Sites/GH Studio synchronization per explicit user scope.'],goal='active; full product completion unproven')
with receipt_path.open('x',encoding='utf8') as f:f.write(json.dumps(receipt,indent=2)+'\n');f.flush();os.fsync(f.fileno())
review=dict(status='archive-verified',path=str(archive),members=len(members),bytes=len(raw),sha256=sha(raw),receiptSHA256=sha(receipt_path.read_bytes()),source=source)
with (q/'main-delivery-archive-review.json').open('x',encoding='utf8') as f:f.write(json.dumps(review,indent=2)+'\n');f.flush();os.fsync(f.fileno())
print(json.dumps(review),flush=True)
