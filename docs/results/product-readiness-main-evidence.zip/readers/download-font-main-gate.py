import datetime,hashlib,json,os,pathlib,subprocess,sys,zipfile
q=pathlib.Path(__file__).resolve().parent
gh=r'H:\mc2llvm\.work\gh\bin\gh.exe'
kind=sys.argv[1]
runid,prefix={'browser':(41174035077,'browser-lifecycle'),'contract':(41174041946,'release-contract'),'site':(41174045604,'versioned-site-browser')}[kind]
source='bb3bd37d215b30ae46eab97f63776d3e213d0a82'
def save(name,raw):
    p=q/name
    if p.exists():
        assert p.read_bytes()==raw, 'Existing evidence differs; never overwrite'
    else:
        with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
def fetch(endpoint):
    r=subprocess.run([gh,'api','repos/koviankevin/tflite-explorer/'+endpoint],capture_output=True,timeout=75)
    assert r.returncode==0, f'GitHub read failed ({r.returncode})'
    return r.stdout
# Only completed runs are retained. A live run is not a failed test or a reason to restart.
run=json.loads(fetch(f'actions/runs/{runid}'))
assert run['status']=='completed', 'Run remains live; poll same run, do not download/restart yet'
assert run['conclusion']=='success' and run['head_sha']==source
for label,data in [('run',run),('jobs',json.loads(fetch(f'actions/runs/{runid}/jobs?per_page=100'))),('artifacts',json.loads(fetch(f'actions/runs/{runid}/artifacts?per_page=100')))]:
    save(f'font-main-{kind}-{label}.json',(json.dumps(data,indent=2)+'\n').encode())
metadata=json.loads((q/f'font-main-{kind}-artifacts.json').read_bytes())
assert metadata['total_count']==len(metadata['artifacts'])
matches=[a for a in metadata['artifacts'] if a['name']==f'{prefix}-{source}-{run["run_attempt"]}']
assert len(matches)==1
a=matches[0]
assert not a['expired'] and 0<a['size_in_bytes']<=4*1024**2
p=q/f'font-main-{kind}-artifact.zip'
raw=p.read_bytes() if p.exists() else fetch(f'actions/artifacts/{a["id"]}/zip')
assert 'sha256:'+hashlib.sha256(raw).hexdigest()==a['digest']
with zipfile.ZipFile(__import__('io').BytesIO(raw)) as z:
    assert z.testzip() is None and len(z.namelist())==1
    report_raw=z.read(z.namelist()[0]);report=json.loads(report_raw)
save(p.name,raw)
save(f'font-main-{kind}-report.json',report_raw)
print(json.dumps(dict(kind=kind,run=runid,source=source,artifact=a['id'],digest=a['digest'],status=report.get('status'))),flush=True)
