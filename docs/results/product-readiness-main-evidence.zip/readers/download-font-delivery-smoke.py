import hashlib,json,os,pathlib,subprocess,zipfile,io
q=pathlib.Path(__file__).resolve().parent
run=json.loads((q/'font-main-site-run.json').read_bytes());metadata=json.loads((q/'font-main-site-artifacts.json').read_bytes())
assert run['id']==41174045604 and run['status']=='completed' and run['conclusion']=='success'
assert run['head_sha']=='bb3bd37d215b30ae46eab97f63776d3e213d0a82'
items=[a for a in metadata['artifacts'] if a['name']==f'versioned-delivery-smoke-{run["head_sha"]}-{run["run_attempt"]}'];assert len(items)==1
a=items[0];assert not a['expired'] and 0<a['size_in_bytes']<=4*1024**2
p=q/'font-main-delivery-smoke.zip'
if p.exists():raw=p.read_bytes()
else:
 r=subprocess.run([r'H:\mc2llvm\.work\gh\bin\gh.exe','api',f'repos/koviankevin/tflite-explorer/actions/artifacts/{a["id"]}/zip'],capture_output=True,timeout=75)
 assert r.returncode==0,'GitHub artifact read failed'
 raw=r.stdout
assert 'sha256:'+hashlib.sha256(raw).hexdigest()==a['digest']
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 assert sorted(z.namelist())==['production-smoke.json','production-smoke.png'] and z.testzip() is None
 outputs=[(p.name,raw),('font-main-delivery-smoke.json',z.read('production-smoke.json')),('font-main-delivery-smoke.png',z.read('production-smoke.png'))]
 for name,data in outputs:
  target=q/name
  if target.exists():assert target.read_bytes()==data,'Do not overwrite different artifact'
  else:
   with target.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
r=json.loads(outputs[1][1]);print(json.dumps(dict(artifact=a['id'],digest=a['digest'],status=r.get('status'),checks=len(r.get('checks',[])),fontRequired=r.get('fontReflowRequired'),keys=list(r))),flush=True)
