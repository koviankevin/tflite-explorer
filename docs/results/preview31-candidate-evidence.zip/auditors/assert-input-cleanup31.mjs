import assert from 'node:assert/strict';
export function assertInputCleanup31(r,lifecycle=false){
    const t=r.tfliteRuntime;assert.equal(t.inputCleanupRequired,true);assert.deepEqual(t.inputCleanup.map(c=>c.kind),['escape','cancel-button','finished-passed','finished-passed','finished-not-verified','finished-failed','finished-not-verified','finished-not-verified','finished-passed','finished-passed','finished-passed','finished-not-verified','finished-passed','finished-passed']);
    const expected={open:false,controls:0,fileInputs:0,callbackCleared:true,error:''};for(const {kind,...state}of t.inputCleanup)assert.deepEqual(state,expected);
    if(lifecycle){const a=r.runtimeLifecycle;assert.equal(a.inputCleanupRequired,true);assert.deepEqual(a.inputCleanup.map(c=>c.kind),Array.from({length:8},(_,i)=>Array.from({length:3},(_,j)=>`cycle-${i+1}-run-${j+1}`)).flat());for(const {kind,...state}of a.inputCleanup)assert.deepEqual(state,expected);}
    return {runtimeDialogChecks:t.inputCleanup.length,lifecycleDialogChecks:lifecycle?24:0,controlsReleased:true,confirmCallbacksCleared:true,errorCleared:true};
}
