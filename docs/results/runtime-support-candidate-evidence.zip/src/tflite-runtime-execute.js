import {RUNTIME_ENGINE,RUNTIME_LIMITS,runtimeSkipped} from './tflite-runtime-policy.js';
import {runtimeInput,validateRuntimeInputs} from './tflite-runtime-inputs.js';
import {runtimeArchive} from './tflite-runtime-archive.js';
import {runtimeFailureLocations,runtimeUnsupportedKernel} from './tflite-runtime-diagnostics.js';
const scope='主 subgraph 的載入／CPU 配置及一組指定輸入；不代表數值精度、等價性、全部 signatures 或分支覆蓋。';
export async function executeRuntime({blob,plan,rt,specs=plan?.inputs?.map(()=>({mode:'zero'})),progress=()=>{},diagnostics=()=>[],transferableIO=false,ioBuffer=null}){
    if(!plan?.eligible||blob.size!==plan.modelBytes||blob.size>RUNTIME_LIMITS.modelBytes)return runtimeSkipped(plan?.reason||'模型與執行檢查資料不符。',plan?.engine);
    let stage='inputs',model=null,environment=null,ins=[],outs=[],compiled=false,invoked=false,modelSHA256=null,inputDetails=[],outputDetails=[];
    const started=performance.now();
    const engine=rt?.engine||RUNTIME_ENGINE;
    const record=(status,reason,unsupportedKernel)=>{const lines=diagnostics().slice(-12).map(s=>String(s).slice(0,512));return {schemaVersion:1,engine,status,stage,reason,compiled,invoked,modelSHA256,elapsedMs:Math.round(performance.now()-started),scope,diagnostics:lines,...(status==='failed'||unsupportedKernel?{failureKind:unsupportedKernel?'unsupported-kernel':/allocate|allocation/i.test(reason)?'tensor-allocation':'runtime',failureLocations:runtimeFailureLocations(lines,plan.diagnosticContext)}:{}),...(unsupportedKernel?{unsupportedKernel}:{})};};
    const capture=(status,reason,unsupportedKernel)=>{
        const result=record(status,reason,unsupportedKernel);
        if(ins.length||invoked)try{
            // Keep the declared interface when an exception prevents run() or
            // input construction from returning every tensor. Produced values
            // retain their actual dtype/shape rather than hiding a mismatch.
            const details=Array.from({length:Math.max(outs.length,outputDetails.length)},(_,i)=>({...outputDetails[i],dtype:outs[i]?.dtype??outputDetails[i]?.dtype}));
            result.io=runtimeArchive({validation:result,inputs:ins,outputs:outs,inputDetails,outputDetails:details,specs,modelSHA256,transferable:transferableIO,ioBuffer});
            if(result.io.manifest.capture?.status==='partial'){
                const missing=result.io.manifest.capture.missing;
                result.ioError=`執行記錄部分保存：${missing.length} 個 tensor 未能保存；可取得的資料已保留。${missing[0].side} #${missing[0].index}：${missing[0].reason}；詳見 IO ZIP 的 manifest.json。`;
            }
        }catch(error){result.ioError=`執行記錄未能保存：${String(error.message).slice(0,512)}`;}
        return result;
    };
    try{
        validateRuntimeInputs(plan.inputs,specs);
        if(plan.runtimeBackend==='interpreter'&&rt?.backend!=='interpreter')throw Error('值相依 shape 必須使用標準 Interpreter；拒絕使用已知可能回傳錯誤數值的 CompiledModel。');
        stage='compile';progress('本機 runtime：載入模型及配置 CPU tensors…');
        const bytes=new Uint8Array(await blob.arrayBuffer());
        if(globalThis.crypto?.subtle)modelSHA256=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
        environment=await rt.Environment.create({webGpuDevice:null});
        model=await rt.loadAndCompile(bytes,{accelerator:'wasm',environment,cpuOptions:{numThreads:1}});compiled=true;
        stage='interface';inputDetails=model.getInputDetails();outputDetails=model.getOutputDetails();
        const matches=(actual,expected)=>actual.length===expected.length&&actual.every((v,i)=>v.dtype===expected[i].dtype&&JSON.stringify(Array.from(v.shape))===JSON.stringify(expected[i].shape));
        if(!matches(inputDetails,plan.inputs)||!matches(outputDetails,plan.outputs))return capture('failed','runtime 推導的輸入／輸出 shape 或 dtype 與匯出模型宣告不符；請修正 output tensor。');
        stage='inputs';for(let i=0;i<inputDetails.length;i++){const t=inputDetails[i];ins.push(new rt.Tensor(await runtimeInput({...t,shape:Array.from(t.shape)},specs[i]),t.shape,t.dtype,environment));}
        stage='invoke';progress('本機 runtime：使用指定測試輸入執行；不驗證精度…');
        const values=await model.run(ins);outs=Array.isArray(values)?values:Object.values(values);invoked=true;
        if(!matches(outs.map(t=>({dtype:t.dtype,shape:t.shape})),plan.outputs))return capture('failed','執行後輸出 shape 或 dtype 與模型宣告不符。');
        stage='complete';return capture('passed','已載入、配置並以指定輸入執行一次；精度與其他分支仍需測試。');
    }catch(error){const reason=String(error?.message||error).slice(0,1024),unsupportedKernel=runtimeUnsupportedKernel(diagnostics(),stage),unsupported=unsupportedKernel||/not supported|unsupported|缺少|尚不支援/i.test(reason),allocation=/allocate|allocation|prepare.*fail/i.test(reason),hint=stage==='compile'?'失敗發生在套用測試輸入之前，切換零值／亂數無法修復此階段；請依原始診斷檢查模型、tensor 參數及 runtime 支援。':allocation?'runtime 可能在 run() 階段才配置 tensors；請依原始 kernel 訊息與 OP／tensor 對照確認原因，不能只依階段名稱判定為測試輸入錯誤。':'需依此 runtime／輸入的診斷確認原因。';return capture(unsupported?'not-verified':'failed',`${unsupportedKernel?`runtime 未註冊 ${unsupportedKernel.kernel} version ${unsupportedKernel.version}；請改用支援此 OP／版本的 runtime 驗證。`:`${stage==='invoke'?'指定輸入執行':stage==='inputs'?'測試輸入':'runtime 載入／配置'}失敗。`}${hint}\n原始 runtime 錯誤：${reason}`,unsupportedKernel);}
    finally{for(const t of new Set([...outs,...ins]))try{t.delete();}catch{}try{model?.delete();}catch{}try{environment?.delete();}catch{}}
}
