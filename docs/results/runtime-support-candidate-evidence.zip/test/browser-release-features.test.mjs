import {searchPatternRevealRequired} from './browser/release-features.mjs';
import {axisTransformValidationRequired} from './browser/release-features.mjs';
import {softmaxValidationRequired} from './browser/release-features.mjs';
import {runtimeSupportRequired} from './browser/release-features.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {browserReleaseFeatures,fontReflowRequired,operatorValidationRequired,quantizationValidationRequired,legacyShapeValidationRequired} from './browser/release-features.mjs';
import {partialRuntimeIORequired,deleteShapeRequired} from './browser/release-features.mjs';
import {graphReadabilityRequired} from './browser/release-features.mjs';

test('runtime support classification is mandatory from v1.12.5 and preserves prior Softmax coverage',()=>{
    for(const version of ['0.2.0-preview.34','1.0.0','1.12.3','1.12.4'])assert.equal(runtimeSupportRequired(version),false);
    for(const version of ['1.12.5','1.12.6','1.13.0','2.0.0','1.12.5+verified.1']){assert.equal(runtimeSupportRequired(version),true);assert.equal(softmaxValidationRequired(version),true);}
    for(const version of [null,'','v1.12.5'])assert.throws(()=>runtimeSupportRequired(version));
});

test('panel and connection checks apply to v1.7 and future formal releases without breaking immutable older builds',()=>{
    for(const v of ['1.0.0','1.6.1','0.2.0-preview.34'])assert.equal(graphReadabilityRequired(v),false);
    for(const v of ['1.7.0','1.7.1','1.8.0','2.0.0'])assert.equal(graphReadabilityRequired(v),true);
    for(const v of [null,'','v1.7.0'])assert.throws(()=>graphReadabilityRequired(v));
});

test('partial runtime IO is required for current and unknown candidates, while exact published history remains compatible',()=>{
    for(const version of ['0.2.0-preview.7','0.2.0-preview.34','1.0.0','1.0.1','1.1.0','1.2.0','1.2.1','1.3.0','1.3.1','1.4.0'])assert.equal(partialRuntimeIORequired(version),false,version);
    for(const version of ['1.4.1','1.4.2','1.4.3','1.4.4','1.4.5','1.4.6','2.0.0','1.4.0+company.1','0.2.0-preview.35'])assert.equal(partialRuntimeIORequired(version),true,version);
    for(const version of [null,'candidate','v1.4.1'])assert.throws(()=>partialRuntimeIORequired(version));
});

test('legacy shape checks skip exact older immutable releases and remain required for new or unknown labels',()=>{
    for(const v of ['0.2.0-preview.7','0.2.0-preview.34','1.0.0','1.0.1','1.1.0','1.2.0','1.2.1','1.3.0','1.3.1','1.4.0'])assert.equal(legacyShapeValidationRequired(v),false,v);
    for(const v of ['1.4.1','1.4.2','1.4.3','1.4.4','1.4.5','1.4.6','1.5.0','2.0.0','1.4.0+company.1','0.2.0-preview.35'])assert.equal(legacyShapeValidationRequired(v),true,v);
    for(const v of [null,'candidate','v1.4.1'])assert.throws(()=>legacyShapeValidationRequired(v));
});
const all={demoRuntime:true,inputCleanup:true,workspaceStorage:true,desktopRuntimeRSS:true};
test('Softmax metadata and manual numerical checks remain required from v1.12.4 including suffixed versions',()=>{
    for(const v of ['0.2.0-preview.34','1.12.0','1.12.3'])assert.equal(softmaxValidationRequired(v),false);
    for(const v of ['1.12.4','1.12.4-rc.1','1.12.4+company.1','1.13.0','2.0.0'])assert.equal(softmaxValidationRequired(v),true);
    for(const v of [null,'','v1.12.4','1.12'])assert.throws(()=>softmaxValidationRequired(v));
});
test('axis metadata checks remain required after v1.12.2 while exact older builds stay usable',()=>{
    for(const v of ['0.2.0-preview.34','1.7.3','1.12.1'])assert.equal(axisTransformValidationRequired(v),false);
    for(const v of ['1.12.2','1.12.3','1.13.0','2.0.0','1.12.2+company.1','1.12.2-rc.1'])assert.equal(axisTransformValidationRequired(v),true);
    for(const v of [null,'1.12','v1.12.2'])assert.throws(()=>axisTransformValidationRequired(v));
});

test('automatic deletion shape propagation is required from v1.11 while immutable older releases remain usable',()=>{
    for(const v of ['1.9.1','1.10.0','0.2.0-preview.34'])assert.equal(deleteShapeRequired(v),false);
    for(const v of ['1.11.0','1.12.0','2.0.0'])assert.equal(deleteShapeRequired(v),true);
    assert.throws(()=>deleteShapeRequired('v1.11.0'));
});

test('quantization browser coverage skips only exact immutable pre-feature releases',()=>{
    for(const version of ['0.2.0-preview.7','0.2.0-preview.34','1.0.0','1.0.1','1.1.0','1.2.0','1.2.1','1.3.0','1.3.1'])assert.equal(quantizationValidationRequired(version),false,version);
    for(const version of ['1.4.0','1.4.2','1.4.3','1.4.4','1.4.5','1.4.6','2.0.0','1.3.2','1.3.1+company.1','0.2.0-preview.35'])assert.equal(quantizationValidationRequired(version),true,version);
    assert.throws(()=>quantizationValidationRequired('candidate'),/version/);
});

test('stable and future releases retain all current browser coverage',()=>{
    for(const version of ['1.0.0','1.0.1','1.1.0','1.4.2','1.4.3','1.4.4','1.4.5','1.4.6','2.0.0','1.0.1-rc.1','1.0.0+company.2','0.2.1'])assert.deepEqual(browserReleaseFeatures(version),all,version);
});
test('the preview28 published-demo boundary remains explicit',()=>{
    assert.equal(browserReleaseFeatures('0.2.0-preview.27').demoRuntime,false);assert.equal(browserReleaseFeatures('0.2.0-preview.28').demoRuntime,true);
});
test('the preview31 input-cleanup and RSS boundaries remain explicit',()=>{
    for(const feature of ['inputCleanup','desktopRuntimeRSS']){assert.equal(browserReleaseFeatures('0.2.0-preview.30')[feature],false);assert.equal(browserReleaseFeatures('0.2.0-preview.31')[feature],true);}
});
test('the preview34 workspace-storage boundary remains explicit',()=>{
    assert.equal(browserReleaseFeatures('0.2.0-preview.33').workspaceStorage,false);assert.equal(browserReleaseFeatures('0.2.0-preview.34').workspaceStorage,true);
});
test('immutable legacy previews cannot acquire unsupported modern scenarios',()=>{
    for(const n of [7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26])assert.deepEqual(browserReleaseFeatures(`0.2.0-preview.${n}`),{demoRuntime:false,inputCleanup:false,workspaceStorage:false,desktopRuntimeRSS:false});
});
test('unknown but valid labels cannot silently reduce required coverage',()=>{
    for(const version of ['0.2.0-beta.1','0.2.0-preview.12+repacked.1'])assert.deepEqual(browserReleaseFeatures(version),all,version);
});
test('missing or malformed release metadata fails selection instead of skipping tests',()=>{
    for(const version of [undefined,null,{},[],0,'','1','1.0','v1.0.0',' 1.0.0','1.0.0/../x','0.2.0-preview.0','0.2.0-preview.9007199254740992'])assert.throws(()=>browserReleaseFeatures(version),undefined,String(version));
});

test('font reflow is required for new sources while exact immutable pre-fix releases remain usable',()=>{
    for(const version of ['1.0.0','1.0.1','1.1.0','0.2.0-preview.1','0.2.0-preview.28','0.2.0-preview.34'])assert.equal(fontReflowRequired(version),false,version);
    for(const version of ['1.2.0','1.2.1','1.4.2','1.4.3','1.4.4','1.4.5','1.4.6','2.0.0','1.1.0+repacked.1','0.2.0-preview.35','0.2.0-preview.01','0.2.0-preview.12+repacked.1','0.2.1','1.2.0-rc.1'])assert.equal(fontReflowRequired(version),true,version);
});

test('font reflow cannot be skipped using missing or malformed release metadata',()=>{
    for(const version of [undefined,null,'','1.2','v1.2.0','1.2.0/../x','0.2.0-preview.0'])assert.throws(()=>fontReflowRequired(version));
});

test('per-OP validation is required for new releases without breaking exact immutable rollback labels',()=>{
    for(const v of ['1.0.0','1.0.1','1.1.0','1.2.0','1.2.1','0.2.0-preview.34'])assert.equal(operatorValidationRequired(v),false,v);
    for(const v of ['1.3.0','1.4.2','1.4.3','1.4.4','1.4.5','1.4.6','2.0.0','1.2.1+repacked.1','0.2.0-preview.35','0.2.0-preview.01'])assert.equal(operatorValidationRequired(v),true,v);
    for(const v of [undefined,null,'','v1.3.0','1.3.0/../x'])assert.throws(()=>operatorValidationRequired(v));
});

test('search editor reveal stays required after v1.12.1 without breaking immutable rollback builds',()=>{
    for(const v of ['0.2.0-preview.34','1.9.1','1.12.0'])assert.equal(searchPatternRevealRequired(v),false);
    for(const v of ['1.12.1','1.12.2','1.13.0','2.0.0'])assert.equal(searchPatternRevealRequired(v),true);
    for(const v of [null,'v1.12.1','1.12'])assert.throws(()=>searchPatternRevealRequired(v));
});
