import pathlib,json,hashlib,zipfile
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];load=lambda n:json.loads((q/n).read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
r=load('memory-failure-review.json');assert r['status']=='verified-original-failure-no-retry-no-publish' and r['evaluation']['status']=='failed' and r['run']==41252363060
names=['main-gates-plan.json','main-gates-accepted-run-identities.json','main-candidate-intent.json','main-candidate-build.json','pr206-merge-proof.json','pr206-final-ci-review.json','core-reuse-proof.json','gate-scope-plan.json','read-main-gate.py','download-failed-main-browser.py','review-memory-failure.mjs','memory-failure-review.json','archive-memory-failure.py','main-browser-failure-log.json','main-delivery-artifact.zip','main-delivery-report.json','main-delivery-smoke-review.json','review-main-delivery-smoke.mjs']
for kind in ['core','browser','contract','site']:
 names+=['main-'+kind+'-'+n for n in ['run.json','jobs.json','artifacts.json','artifact.zip','report.json']]
 if kind!='browser':names+=['main-'+kind+'-review.json']
 if kind!='core':names+=['main-'+kind+'-'+n for n in ['dispatch.json','before-runs.json']]
records=[{'path':n,'bytes':(q/n).stat().st_size,'sha256':sha((q/n).read_bytes())} for n in names]
manifest=(json.dumps({'format':'model-lens-legacy-shape-memory-failure-originals','source':r['source'],'tree':r['tree'],'records':records,'privacy':'Original official provider ZIPs/logs/metadata and independent readers. No model/weight/BIN/BMP or transient download URLs. No successful deployment repeated;originalfailurepreserved.'},indent=2)+'\n').encode();dest=root/'docs/results/legacy-shape-memory-failure-evidence.zip'
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.writestr('manifest.json',manifest)
 for n in names:z.write(q/n,n)
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None and len(z.infolist())==len(records)+1
 for row in records:assert sha(z.read(row['path']))==row['sha256']
result={**r,'otherGates':{k:load('main-'+k+'-review.json') for k in ['core','contract','site']},'site37':load('main-delivery-smoke-review.json'),'originals':{'path':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'manifestSHA256':sha(manifest),'records':len(records)},'goalComplete':False}
(root/'docs/results/legacy-shape-memory-failure.json').open('x',encoding='utf-8').write(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'records':len(records),'bytes':dest.stat().st_size,'sha256':result['originals']['sha256']}))
