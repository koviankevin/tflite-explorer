import pathlib,json,subprocess,sys,datetime
q=pathlib.Path(__file__).resolve().parent;kind=sys.argv[1];plan=json.loads((q/'main-gates-plan.json').read_bytes());assert kind in plan['workflows'];workflow=plan['workflows'][kind];intent=json.loads((q/('main-'+kind+'-dispatch.json')).read_bytes());gh=r'H:\mc2llvm\.work\gh\bin\gh.exe';prefix='repos/'+plan['repository']+'/'
def api(route):return json.loads(subprocess.check_output([gh,'api',prefix+route],timeout=45).decode('utf-8-sig'))
runs=api('actions/runs?head_sha='+plan['source']+'&event=workflow_dispatch&per_page=100');assert len(runs['workflow_runs'])==runs['total_count'];selected=[r for r in runs['workflow_runs'] if r['id'] not in intent['knownBeforeIds'] and r['path']=='.github/workflows/'+workflow];assert len(selected)==1;r=api('actions/runs/'+str(selected[0]['id']));jobs=api('actions/runs/'+str(r['id'])+'/jobs?per_page=100')
assert r['head_sha']==plan['source'] and r['head_branch']=='main' and r['event']=='workflow_dispatch' and r['run_attempt']==1 and r['repository']['full_name']==plan['repository']
assert datetime.datetime.fromisoformat(r['created_at'].replace('Z','+00:00'))>=datetime.datetime.fromisoformat(intent['createdAt']).replace(microsecond=0)
if r['status']!='completed':
 print(json.dumps({'kind':kind,'run':r['id'],'status':r['status'],'jobs':[{k:j[k] for k in ['id','name','status','conclusion']} for j in jobs['jobs']]}));raise SystemExit(0)
artifacts=api('actions/runs/'+str(r['id'])+'/artifacts')
for suffix,obj in [('run',r),('jobs',jobs),('artifacts',artifacts)]:
 (q/('main-'+kind+'-'+suffix+'.json')).open('x',encoding='utf-8').write(json.dumps(obj,indent=2)+'\n')
assert r['conclusion']=='success','Original terminal failure retained;inspect without automatic retries.'
print(json.dumps({'kind':kind,'run':r['id'],'status':r['status'],'conclusion':r['conclusion'],'artifacts':[{'id':a['id'],'name':a['name'],'bytes':a['size_in_bytes'],'digest':a['digest']} for a in artifacts['artifacts']]}))
