import datetime,hashlib,json,os,pathlib
q=pathlib.Path(__file__).resolve().parent;raw=(q/'close-waits-detached-1.json').read_bytes();r=json.loads(raw);log=(q/'close-waits-detached-1.log').read_text('utf-8');status=json.loads((q/'close-waits-detached-1-status.json').read_bytes())
assert status['status']=='producer-exited' and status['exitCode']==1 and status['autoRetries'] is False
assert r['status']=='failed' and r['variant']=='detached' and r['modelAcceptance']=='not evaluated' and not r.get('browserClosed') and r['errors']==[]
events={x['kind']:x for x in r['events']};start=events['browser-close-start']['elapsedMs']
assert events['observer-detach-end']['elapsedMs']<=events['context-close-start']['elapsedMs']
assert 10000<=events['failed']['elapsedMs']-start<12000
roles=r['rolesAtFailure']['roles'];assert len(roles)==2 and all(x['identityStillMatches'] for x in roles) and {x['type'] for x in roles}=={'untyped','crashpad-handler'}
w=r['waitChainsAtFailure'];assert w['mode']=='owned-browser-threads' and w['privilegeChanges'] is False and w['flags']==0 and w['sampledThreads']==w['totalOwnedThreads']==52
assert all(w['identityStillMatches'].values()) and len(w['threads'])==52
assert sum(t['success'] for t in w['threads'])==51 and [t['winerror'] for t in w['threads'] if not t['success']]==[87]
assert all(len(t['nodes'])==1 and not t['cycle'] for t in w['threads'] if t['success'])
assert all(not any(k in n for k in ['name','objectName','stack','memory']) for t in w['threads'] for n in t['nodes'])
assert '<will force kill>' in log and r['observerClose']=={'exitCode':0,'stderr':''}
result={'status':'detached-empty-close-still-failed-wait-reason-unresolved','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reportSHA256':hashlib.sha256(raw).hexdigest(),'observerCDPDetachedBeforeClose':True,'remainingRoles':roles,'normalCloseFailedAfterMs':events['failed']['elapsedMs']-start,'browserDisconnectedAfterMs':events['browser-disconnected']['elapsedMs']-start,'waitThreads':52,'singleNodeSuccessfulQueries':51,'queryErrors':[87],'privilegeChanges':False,'modelAcceptance':'not evaluated','scope':'No website model/download/WASM. Own observer CDP sessions are not necessary for this reproduced failure. Only this live role/identity is classified;no historical child attribution.','limitation':'Single WCT node may mean running or an unsupported synchronization element;no evidence of a wait dependency or proof that no block exists. No object names/stack memory/privilege changes. SDK forcedcleanup is not normal-close.','apiSource':'https://learn.microsoft.com/windows/win32/api/wct/nf-wct-getthreadwaitchain'}
with (q/'close-waits-detached-1-review.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(result))
