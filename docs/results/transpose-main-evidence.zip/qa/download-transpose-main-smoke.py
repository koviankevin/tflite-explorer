import base64,datetime,hashlib,io,json,os,pathlib,sys,urllib.request,zipfile
q=pathlib.Path(__file__).resolve().parent
run=json.loads((q/'transpose-main-site-run.json').read_bytes());metadata=json.loads((q/'transpose-main-site-artifacts.json').read_bytes())
assert run['id']==41200635819 and run['status']=='completed' and run['conclusion']=='success' and run['head_sha']=='8bf6c9bbeedb2b083f8791e33c9d28d3a4a2bd32'
items=[a for a in metadata['artifacts'] if a['name']==f'versioned-delivery-smoke-{run["head_sha"]}-{run["run_attempt"]}'];assert len(items)==1
a=items[0];assert not a['expired'] and 0<a['size_in_bytes']<4*1024**2
paths=[q/('transpose-main-delivery-smoke'+ext) for ext in ['.zip','.json','.png']];assert all(not p.exists() for p in paths)
intent={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifact':a['id'],'expectedDigest':a['digest'],'outputs':list(map(str,paths)),'purpose':'Inspect actual isolated versioned website smoke and screenshot;no new test','cleanup':'Retain original provider ZIP and bounded evidence;no deletion authorised','credentials':'Connector signed download reference is transient;never printed or saved'}
with (q/'transpose-main-smoke-download-intent.json').open('x',encoding='utf-8') as f:json.dump(intent,f,indent=2);f.flush();os.fsync(f.fileno())
url=base64.b64decode(sys.argv[1]).decode('utf-8');assert url.startswith('https://')
with urllib.request.urlopen(url,timeout=30) as r:raw=r.read(4*1024**2+1)
del url
assert len(raw)==a['size_in_bytes'] and 'sha256:'+hashlib.sha256(raw).hexdigest()==a['digest']
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert sorted(z.namelist())==['production-smoke.json','production-smoke.png'] and z.testzip() is None
    data=z.read('production-smoke.json');png=z.read('production-smoke.png');assert len(data)<4*1024**2 and png.startswith(b'\x89PNG\r\n\x1a\n')
    parsed=json.loads(data)
for p,b in zip(paths,[raw,data,png]):
    with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
print(json.dumps({'artifact':a['id'],'digest':a['digest'],'bytes':len(raw),'status':parsed.get('status'),'checks':len(parsed.get('checks',[])),'source':parsed.get('driverSourceCommit'),'release':parsed.get('siteRelease',{}).get('version')}))
