"""Read only --type/--utility-sub-type for exact, directly owned browser identities."""
import json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;native=q.parents[2]/'test/browser/windows-process-memory.py'
scope={'__name__':'owned_role_observer'};exec(compile(native.read_text('utf-8').split('observer=Observer()')[0],str(native),'exec'),scope)
request=json.load(sys.stdin);rows=request['rows'];assert isinstance(rows,list) and 0<len(rows)<=64
table=scope['snapshot']();root=table.get(request['rootPid']);assert root and root['name']=='chrome.exe' and root['parent']==os.getppid()
expected={x['pid']:x for x in rows};assert len(expected)==len(rows) and root['pid'] in expected
before=[]
for original in rows:
    assert original['name']=='chrome.exe' and isinstance(original['pid'],int) and original['startTicks'].isdigit()
    found=scope['inspect'](original)
    if found:before.append(found)
script=r'''
$items = [Console]::In.ReadToEnd() | ConvertFrom-Json
$result = @()
foreach ($item in $items) {
  $processRecord = Get-CimInstance Win32_Process -Filter ("ProcessId = " + [int]$item.pid) -ErrorAction Stop
  if ($null -ne $processRecord) {
    $kind = 'untyped'
    $utility = $null
    if ($processRecord.CommandLine -match '--type=([A-Za-z0-9_-]{1,80})(?:\s|$)') { $kind = $Matches[1] }
    if ($processRecord.CommandLine -match '--utility-sub-type=([A-Za-z0-9_.-]{1,100})(?:\s|$)') { $utility = $Matches[1] }
    $result += [pscustomobject]@{pid=[int]$item.pid;type=$kind;utility=$utility}
  }
}
ConvertTo-Json -InputObject @($result) -Depth 3 -Compress
'''
result=subprocess.run(['powershell.exe','-NoLogo','-NoProfile','-NonInteractive','-Command',script],input=json.dumps(before),capture_output=True,text=True,encoding='utf-8',timeout=15,creationflags=subprocess.CREATE_NO_WINDOW)
assert result.returncode==0,'Owned role query failed; full command output not retained'
classified=json.loads(result.stdout);assert isinstance(classified,list) and len(classified)<=len(before)
roles=[]
for row in classified:
    assert row['pid'] in expected
    original=expected[row['pid']]
    still=scope['inspect'](original)
    roles.append({'pid':row['pid'],'startTicks':original['startTicks'],'identityStillMatches':still is not None,'type':row['type'] if still else None,'utility':row['utility'] if still else None})
print(json.dumps({'rootPid':root['pid'],'roles':roles,'scope':'Only type classification,guarded by exact native identities before and after query;not wait-chain or root-cause proof'}))
