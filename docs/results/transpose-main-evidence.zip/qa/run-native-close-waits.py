import datetime,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];out=q/'close-waits-detached-1.json';log=q/'close-waits-detached-1.log';status=q/'close-waits-detached-1-status.json'
assert all(not p.exists() for p in [out,log,status])
state={'status':'create-intent','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'outputs':[str(out),str(log)],'case':'one predeclared detached empty page;postfailure wait-chain observation','modelAcceptance':'not evaluated','autoRetries':False,'cleanup':'Preserve diagnostics;no deletion authorised'}
def save():
    with status.open('w',encoding='utf-8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save()
native=root/'test/browser/windows-process-memory.py';scope={'__name__':'owned_census'};exec(compile(native.read_text('utf-8').split('observer=Observer()')[0],str(native),'exec'),scope)
table=scope['snapshot']();prior=json.loads((q/'close-roles-empty-1.json').read_bytes());live=[]
for identity in prior['failureNativeObservation']['identities']:
    row=table.get(identity['pid'])
    if row:
        found=scope['inspect']({**row,'startTicks':identity['startTicks']})
        if found:live.append(found)
assert not live,'Previous owned browser remains live;do not start another'
env={**os.environ,'MODEL_LENS_QA_PYTHON':sys.executable,'CLOSE_PROBE_REPORT':str(out),'DEBUG':'pw:browser'}
node=r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
with log.open('xb') as f:
    p=subprocess.Popen([node,str(q/'native-close-waits.mjs'),'detached','--allow-local-browser'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
    state.update(status='running',pid=p.pid);save();code=p.wait()
state.update(status='producer-exited',exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
print(json.dumps(state));sys.exit(code)
