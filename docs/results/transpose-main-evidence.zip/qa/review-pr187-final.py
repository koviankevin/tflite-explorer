import datetime,hashlib,json,os,pathlib,re,subprocess,zipfile
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];candidate=root.with_name('tflite-explorer-transpose')
load=lambda name:json.loads((q/name).read_bytes());sha=lambda data:hashlib.sha256(data).hexdigest()
head='61bcfc57479a8d8b9b4ca310bcf5f2f43fd36a1f';base='4e998efaba31c1e58708fddce862b6665c47915f';checkout='79755bae20e8afa021dcd4231c5389f8c43f360c';tree='25de84fe66ac128a7153b10343fe300e1b74fc01'
git=lambda *args:subprocess.check_output(['git',*args],cwd=candidate,text=True).strip()
assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain')
assert git('rev-parse','e9f54524b168616f9210ebba3943a5b474bb900f^{tree}')==tree
assert not git('diff','--name-only','4b0822e0df200bfb969a8fa7ea7ab9d387d98484',head,'--','src','vendor','scripts','test','package.json','package-lock.json','.github')
meta=load('pr187-final-meta.json');assert meta['head']['sha']==head and meta['base']['sha']==base and meta['mergeable_state']=='clean'
actual=load('pr187-final-checkout.json');assert actual['sha']==checkout and actual['commit']['tree']['sha']==tree
assert [p['sha'] for p in actual['parents']]==[base,head]
rows=[];logs={};git_blob_fallback=[]
for kind,runid,path,jobname in [('node',41200115003,'pr-validation.yml','node-and-build'),('contract',41200114962,'release-contract.yml','release-contract'),('core',41200114934,'performance.yml','measure')]:
    run=load(f'pr187-final-{kind}-run.json');jobs=load(f'pr187-final-{kind}-jobs.json');log=load(f'pr187-final-{kind}-job-log.json')
    if isinstance(log,dict):log=log['content']
    for _ in range(2):
        try:decoded=json.loads(log)
        except (ValueError,TypeError):break
        if isinstance(decoded,str):log=decoded
        else:break
    assert isinstance(log,str);logs[kind]=log
    assert run['id']==runid and run['status']=='completed' and run['conclusion']=='success' and run['event']=='pull_request' and run['head_sha']==head and run['run_attempt']==1
    assert run['path']=='.github/workflows/'+path and run['head_repository']['full_name']=='koviankevin/tflite-explorer'
    assert jobs['total_count']==len(jobs['jobs'])==1;job=jobs['jobs'][0]
    assert job['name']==jobname and job['status']=='completed' and job['conclusion']=='success'
    assert f'HEAD is now at {checkout[:7]} Merge {head} into {base}' in log and 'Cleaning up orphan processes' in log
    rows.append({'kind':kind,'run':runid,'job':job['id'],'decodedLogSHA256':sha(log.encode('utf-8'))})
    if kind=='node':
        counts={k:int(re.findall(r'# '+k+r' (\d+)',log)[-1]) for k in ['tests','pass','fail','cancelled','skipped']}
        assert counts=={'tests':820,'pass':785,'fail':0,'cancelled':0,'skipped':35}
        assert '"runtimeRequired":true' in log
        for name in ['Run npm ci --ignore-scripts','Run node --test test/*.test.mjs','Run node scripts/build.mjs']:
            assert any(s['name']==name and s['conclusion']=='success' for s in job['steps'])
        assert re.search(r'ok \d+ - signed TRANSPOSE permutations survive actual model edits and produce the pinned CPU outputs',log)
        builds=[json.loads(line[line.index('{'):]) for line in log.splitlines() if '"directory"' in line and '"release"' in line]
        assert len(builds)==1 and builds[0]['files']==322 and builds[0]['release']['version']=='1.2.1' and builds[0]['release']['source']['commit']==checkout and builds[0]['release']['source']['tree']==tree and not builds[0]['release']['source']['dirty']
        rows[-1]['counts']=counts
for kind in ['contract','core']:
    artifacts=load(f'pr187-final-{kind}-artifacts.json');assert artifacts['total_count']==len(artifacts['artifacts'])==1
    a=artifacts['artifacts'][0];raw=(q/f'pr187-final-{kind}-artifact.zip').read_bytes()
    assert len(raw)==a['size_in_bytes'] and 'sha256:'+sha(raw)==a['digest'] and not a['expired']
    assert a['name']==('release-contract' if kind=='contract' else 'core-performance')+'-'+checkout+'-1'
    with zipfile.ZipFile(q/f'pr187-final-{kind}-artifact.zip') as z:
        assert z.testzip() is None and len(z.namelist())==1;report_raw=z.read(z.namelist()[0])
    r=json.loads(report_raw);assert r==load(f'pr187-final-{kind}-report.json')
    assert r['status']=='passed' and r['source']['commit']==checkout and r['source']['tree']==tree and not r['source']['dirty'] and r['sourceUnchanged']
    if kind=='contract':
        assert r['plan']['required'] is True and r['exitCode']==0 and r['counts']=={'tests':78,'pass':78,'fail':0,'skipped':0,'cancelled':0}
    else:
        assert r['referenceEnvironment'] and len(r['samples'])==9
        for f in r['source']['files']:
            p=pathlib.PurePosixPath(f['path']);assert not p.is_absolute() and '..' not in p.parts
            data=(candidate/p).read_bytes()
            if p.suffix in ['.js','.mjs','.json','.html','.css','.yml']:data=data.replace(b'\r\n',b'\n')
            if sha(data)!=f['sha256']:
                # LICENSE/Markdown are not canonicalized by the producer; a
                # Windows autocrlf working copy differs from Linux. Verify the
                # exact tracked blob from the already authenticated same tree.
                data=subprocess.check_output(['git','show',head+':'+f['path']],cwd=candidate)
                if p.suffix in ['.js','.mjs','.json','.html','.css','.yml']:data=data.replace(b'\r\n',b'\n')
                git_blob_fallback.append(f['path'])
            assert sha(data)==f['sha256'],f['path']
        assert len(r['source']['files'])==327
        assert sha(json.dumps(r['source']['files'],ensure_ascii=False,separators=(',',':')).encode('utf-8'))==r['source']['fingerprint']
        policy=(candidate/'test/performance-policy.json').read_bytes().replace(b'\r\n',b'\n')
        assert json.loads(policy)==r['policy'] and sha(policy)==r['policySHA256']
node=r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
code="import {readFile} from 'node:fs/promises';import {evaluatePerformanceRun} from './scripts/lib/performance-policy.mjs';const r=JSON.parse(await readFile('build/qa/windows-large/pr187-final-core-report.json'));const result=evaluatePerformanceRun(r.policy,r.samples);if(result.status!=='passed')throw Error(JSON.stringify(result));console.log(JSON.stringify({status:result.status,issues:result.issues}));"
checked=subprocess.run([node,'--input-type=module','-e',code],cwd=root,encoding='utf-8',capture_output=True,check=True)
assert json.loads(checked.stdout)['status']=='passed'
result={'status':'passed-reviewed-final-pr-ci','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':187,'head':head,'base':base,'actualCheckout':checkout,'tree':tree,'rows':rows,'contractCounts':{'tests':78,'pass':78,'fail':0,'skipped':0,'cancelled':0},'coreSamples':9,'coreSourceFiles':327,'gitBlobFallbackForWindowsNewlines':git_blob_fallback,'candidateAppTestSourcesUnchanged':True,'branchStrictPolicyPreserved':True,'scope':'PR checks/source/artifact integrity only. Node35 preexisting optional skips are not full-suite passes;required contracts have zero skips. This is not a main-dispatch release receipt or a repair of Chrome normal-close.'}
with (q/'pr187-final-ci-review.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(result))
