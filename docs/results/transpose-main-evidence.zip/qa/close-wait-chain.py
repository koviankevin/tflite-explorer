"""Bounded read-only WCT metadata. No debug privilege changes, stacks or object names.

API/layout: https://learn.microsoft.com/windows/win32/api/wct/nf-wct-getthreadwaitchain
https://learn.microsoft.com/windows/win32/api/wct/ns-wct-waitchain_node_info
Flag0 stops at the first thread in another process; partial/no-access is not proof.
"""
import ctypes as c
from ctypes import wintypes as w
import json,os,pathlib,sys,time
assert sys.platform=='win32'
k=c.WinDLL('kernel32',use_last_error=True);a=c.WinDLL('advapi32',use_last_error=True)
class Lock(c.Structure):_fields_=[('name',w.WCHAR*128),('timeout',c.c_int64),('alertable',w.BOOL)]
class Thread(c.Structure):_fields_=[('pid',w.DWORD),('tid',w.DWORD),('wait',w.DWORD),('switches',w.DWORD)]
class Info(c.Union):_fields_=[('lock',Lock),('thread',Thread)]
class Node(c.Structure):_fields_=[('kind',w.DWORD),('status',w.DWORD),('info',Info)]
class Entry(c.Structure):_fields_=[('size',w.DWORD),('usage',w.DWORD),('tid',w.DWORD),('pid',w.DWORD),('basePriority',w.LONG),('deltaPriority',w.LONG),('flags',w.DWORD)]
assert c.sizeof(Node)==280 and c.sizeof(Entry)==28
a.OpenThreadWaitChainSession.argtypes=[w.DWORD,c.c_void_p];a.OpenThreadWaitChainSession.restype=c.c_void_p
a.CloseThreadWaitChainSession.argtypes=[c.c_void_p];a.CloseThreadWaitChainSession.restype=None
a.GetThreadWaitChain.argtypes=[c.c_void_p,c.c_size_t,w.DWORD,w.DWORD,c.POINTER(w.DWORD),c.POINTER(Node),c.POINTER(w.BOOL)];a.GetThreadWaitChain.restype=w.BOOL
k.GetCurrentThreadId.argtypes=[];k.GetCurrentThreadId.restype=w.DWORD
k.CreateToolhelp32Snapshot.argtypes=[w.DWORD,w.DWORD];k.CreateToolhelp32Snapshot.restype=w.HANDLE
for name in ['Thread32First','Thread32Next']:
    getattr(k,name).argtypes=[w.HANDLE,c.POINTER(Entry)];getattr(k,name).restype=w.BOOL
k.CloseHandle.argtypes=[w.HANDLE];k.CloseHandle.restype=w.BOOL
kinds={1:'critical-section',2:'send-message',3:'mutex',4:'alpc',5:'com',6:'thread-wait',7:'process-wait',8:'thread',9:'com-activation',10:'unknown',11:'socket-io',12:'smb-io'}
statuses={1:'no-access',2:'running',3:'blocked',4:'pid-only',5:'pid-only-rpcss',6:'owned',7:'not-owned',8:'abandoned',9:'unknown',10:'error'}
session=a.OpenThreadWaitChainSession(0,None)
if not session:raise c.WinError(c.get_last_error())
def chain(pid,tid):
    count=w.DWORD(16);nodes=(Node*16)();cycle=w.BOOL();c.set_last_error(0)
    ok=bool(a.GetThreadWaitChain(session,0,0,tid,c.byref(count),nodes,c.byref(cycle)));error=0 if ok else c.get_last_error();rows=[]
    if ok or error in [234,565]:
        for n in list(nodes)[:min(16,count.value)]:
            if n.kind not in kinds or n.status not in statuses:continue
            row={'kind':kinds[n.kind],'status':statuses[n.status]}
            if n.kind==8:row.update(pid=n.info.thread.pid,tid=n.info.thread.tid,wait=n.info.thread.wait,switches=n.info.thread.switches)
            rows.append(row)
        assert rows and rows[0].get('pid')==pid and rows[0].get('tid')==tid,'Initial thread identity mismatch'
    return {'pid':pid,'tid':tid,'success':ok,'winerror':error,'nodeCount':count.value,'cycle':bool(cycle.value),'nodes':rows,'truncated':count.value>16}
try:
    if sys.argv[1:]==['--self-test']:
        result={'mode':'self-test','thread':chain(os.getpid(),k.GetCurrentThreadId()),'privilegeChanges':False,'layoutBytes':c.sizeof(Node)}
    else:
        request=json.load(sys.stdin);q=pathlib.Path(__file__).resolve().parent;native=q.parents[2]/'test/browser/windows-process-memory.py';scope={'__name__':'owned_wait_chain'}
        exec(compile(native.read_text('utf-8').split('observer=Observer()')[0],str(native),'exec'),scope)
        rows=request['rows'];assert isinstance(rows,list) and 0<len(rows)<=16 and len({x['pid'] for x in rows})==len(rows)
        table=scope['snapshot']();root=table.get(request['rootPid']);assert root and root['parent']==os.getppid() and root['name']=='chrome.exe'
        expected={row['pid']:row for row in rows};assert root['pid'] in expected and all(scope['inspect'](x) for x in rows)
        owned=set(expected);threads=[];entry=Entry();entry.size=c.sizeof(entry);handle=k.CreateToolhelp32Snapshot(4,0)
        if handle==c.c_void_p(-1).value:raise c.WinError(c.get_last_error())
        try:
            ok=k.Thread32First(handle,c.byref(entry));seen=0
            while ok:
                seen+=1;assert seen<=262144
                if entry.pid in owned:threads.append((entry.pid,entry.tid))
                ok=k.Thread32Next(handle,c.byref(entry))
        finally:k.CloseHandle(handle)
        started=time.monotonic();observations=[]
        for pid,tid in threads[:128]:
            if time.monotonic()-started>5:break
            if scope['inspect'](expected[pid]):observations.append(chain(pid,tid))
        valid={pid:scope['inspect'](row) is not None for pid,row in expected.items()}
        result={'mode':'owned-browser-threads','privilegeChanges':False,'flags':0,'totalOwnedThreads':len(threads),'sampledThreads':len(observations),'threadBudget':128,'identityStillMatches':valid,'threads':observations,'scope':'No object names/stacks/memory;flag0 stops at external-process boundary. NoAccess,one-node or unsupported synchronization does not exclude a wait/deadlock.'}
finally:a.CloseThreadWaitChainSession(session)
print(json.dumps(result))
