import datetime,json,os,pathlib,subprocess,sys,time,urllib.error,urllib.request
q=pathlib.Path(__file__).resolve().parent;p=q/'transpose-main-gate-dispatch.json';assert not p.exists(),'Reconcile existing POST state;never repeat dispatch blindly'
source='8bf6c9bbeedb2b083f8791e33c9d28d3a4a2bd32';tree='25de84fe66ac128a7153b10343fe300e1b74fc01'
workflows=[('browser','browser-lifecycle.yml',{}),('contract','release-contract.yml',{}),('site','production-smoke.yml',{'scenario':'versioned','expected_build_id':'d69754e5b6791ecd'})]
state={'status':'create-intent','source':source,'tree':tree,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempts':[],'autoRetries':False,'scope':'Only changed browser/contract/site closures. Core88file closure unchanged;reuse existing eligible main41159138980 subject to release verifier. No publication yet.','cleanup':'Retain bounded source-bound run/artifact metadata;no cleanup authorised','credentialHandling':'Existing gh credential in process memory only;not printed/saved;authenticated redirects refused'}
def persist():
    with p.open('w',encoding='utf-8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
persist()
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):raise urllib.error.HTTPError(req.full_url,code,'Redirect refused',headers,fp)
try:
    r=subprocess.run([r'H:\mc2llvm\.work\gh\bin\gh.exe','auth','token','--hostname','github.com'],capture_output=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
    assert r.returncode==0 and r.stdout.strip(),'Existing credential unavailable';token=r.stdout.decode('utf-8').strip();del r
    opener=urllib.request.build_opener(NoRedirect())
    def api(route,body=None):
        assert route.startswith('repos/koviankevin/tflite-explorer/')
        request=urllib.request.Request('https://api.github.com/'+route,data=None if body is None else json.dumps(body).encode(),headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','User-Agent':'ModelLens-Scoped-Main-Gates','X-GitHub-Api-Version':'2022-11-28','Content-Type':'application/json'})
        with opener.open(request,timeout=30) as response:
            data=response.read(8*1024**2+1);assert len(data)<=8*1024**2
            return response.status,json.loads(data) if data else None
    listing='repos/koviankevin/tflite-explorer/actions/runs?head_sha='+source+'&event=workflow_dispatch&per_page=100'
    _,before=api(listing);assert before['total_count']==len(before['workflow_runs'])
    for kind,workflow,inputs in workflows:
        assert not any(x['path']=='.github/workflows/'+workflow for x in before['workflow_runs']),'Existing matching main gate;inspect instead of dispatch'
        _,main=api('repos/koviankevin/tflite-explorer/commits/main');assert main['sha']==source and main['commit']['tree']['sha']==tree
        row={'kind':kind,'workflow':workflow,'inputs':inputs,'status':'post-intent','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'postAttempted':True};state['attempts'].append(row);persist()
        status,_=api('repos/koviankevin/tflite-explorer/actions/workflows/'+workflow+'/dispatches',{'ref':'main','inputs':inputs})
        assert status in [200,204];row.update(status='accepted-awaiting-run-id',httpStatus=status);persist()
        for _ in range(12):
            _,after=api(listing);assert after['total_count']==len(after['workflow_runs'])
            matches=[x for x in after['workflow_runs'] if x['path']=='.github/workflows/'+workflow]
            if matches:
                assert len(matches)==1;row.update(status='dispatched',run=matches[0]['id'],url=matches[0]['html_url']);persist();print(json.dumps(row),flush=True);break
            time.sleep(5)
        assert row['status']=='dispatched','POST accepted but run not located;reconcile without repeated POST'
    state['status']='dispatched-all';del token
except Exception as e:
    state.update(status='stopped-inspect-existing-attempts',errorType=type(e).__name__)
    if isinstance(e,urllib.error.HTTPError):state['httpStatus']=e.code
finally:state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();persist()
print(json.dumps(state),flush=True);sys.exit(0 if state['status']=='dispatched-all' else 1)
