import datetime,hashlib,json,os,pathlib
q=pathlib.Path(__file__).resolve().parent;raw=(q/'close-roles-empty-1.json').read_bytes();r=json.loads(raw)
log=(q/'close-roles-empty-1.log').read_text('utf-8');status=json.loads((q/'close-roles-empty-1-status.json').read_bytes())
assert status['status']=='producer-exited' and status['exitCode']==1 and status['autoRetries'] is False
assert r['status']=='failed' and r['diagnosticOnly'] and r['modelAcceptance']=='not evaluated' and r['variant']=='attached' and not r.get('browserClosed') and r['errors']==[]
assert r['source']['commit']=='f592e3d9df7ed48fae2ca19e353c7215638959a3' and not r['source']['dirty']
assert 'normal browser.close exceeded10s' in r['error'] and r['observerClose']=={'exitCode':0,'stderr':''}
before={x['pid']:x for x in r['rolesBeforeClose']['roles']};after=r['rolesAtFailure']['roles'];native=r['failureNativeObservation']['rows']
assert len(after)==len(native)==2 and {x['pid'] for x in after}=={x['pid'] for x in native}
assert all(x['identityStillMatches'] and x['startTicks']==before[x['pid']]['startTicks'] for x in after)
root=next(x for x in after if x['pid']==r['root']['pid']);helper=next(x for x in after if x['pid']!=r['root']['pid'])
assert root['type']=='untyped' and helper['type']=='crashpad-handler'
assert any(x['type']=='renderer' for x in before.values()) and any(x['type']=='gpu-process' for x in before.values())
assert all(x['type'] not in ['renderer','gpu-process','utility'] for x in after)
assert all(not any(k in x for k in ['CommandLine','commandLine','environment']) for x in list(before.values())+after)
events={x['kind']:x for x in r['events']};start=events['browser-close-start']['elapsedMs'];disconnected=events['browser-disconnected']['elapsedMs']-start;failure=events['failed']['elapsedMs']-start
assert 0<=disconnected<1000 and 10000<=failure<12000
assert '<will force kill>' in log and f'PID {helper["pid"]}' in log and f'PID {root["pid"]}' in log
assert '--disable-updater-scheduler' in log and r['browserVersion']=='156.0.8078.76'
result={'status':'original-10s-close-failed-owned-helper-classified','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reportSHA256':hashlib.sha256(raw).hexdigest(),'root':root,'remainingHelper':helper,'disconnectedAfterMs':disconnected,'failedAfterMs':failure,'browserVersion':r['browserVersion'],'modelAcceptance':'not evaluated','scope':'Single empty website page;no application/model/download/WASM worker. Native Chrome itself can log internal services; that is not a website runtime. No full commands,process memory,unrelated user profiles or environment captured.','limits':['Classifies this actual live PID only;cannot retroactively label historical dead unknown children.','Root and crashpad-handler still live does not prove their wait dependency or root cause.','SDK later force kill is retained;not normal-close evidence or a passing model acceptance.']}
with (q/'close-roles-empty-1-review.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(result))
