import pathlib
q=pathlib.Path(__file__).resolve().parent
old=q.parents[3]/'tflite-explorer'/'build'/'qa'/'op-validation'
text=(old/'review-main-gate.mjs').read_text(encoding='utf-8')
text=text.replace("['browser','contract','site']","['core','browser','contract','site']").replace("op-main-","main-")
text=text.replace("{browser:'browser-lifecycle'","{core:'core-performance',browser:'browser-lifecycle'")
text=text.replace('24ace0c5323a4cc65bc85a4490856f70da9d321b','9885c97c58e30eb81f827df5a3da7520f502caa5').replace('f2fedd4285f94683c723e30763edd8518a38ac65','32128382bc42a2fa8e766e9f9aa66a556df02d59').replace('refs/heads/codex/op-validation-report-stream','HEAD')
(q/'review-main-gate.mjs').write_text(text,encoding='utf-8')
text=(old/'review-main-delivery-smoke.mjs').read_text(encoding='utf-8')
text=text.replace('op-main-','main-').replace("'main-delivery-smoke.json'","'main-delivery-report.json'").replace("'main-delivery-smoke.zip'","'main-delivery-artifact.zip'")
text=text.replace('41211812736','41240648865').replace('24ace0c5323a4cc65bc85a4490856f70da9d321b','9885c97c58e30eb81f827df5a3da7520f502caa5').replace('f2fedd4285f94683c723e30763edd8518a38ac65','32128382bc42a2fa8e766e9f9aa66a556df02d59')
text=text.replace("version,'1.3.0'","version,'1.3.1'")
text=text.replace('not publicly deployed v1.2.1.','not publicly deployed v1.3.1.').replace('Exact published v1.2.0 Windows eight cycles passed; later tiny candidate Chrome10s close still failed. This Linux gate does not repair that intermittent native close failure.','Historical default Windows Chrome long-load shutdown failure remains separately recorded; this Linux gate does not prove it fixed.')
(q/'review-main-delivery-smoke.mjs').write_text(text,encoding='utf-8')
print('created two source-bound independent review scripts')

