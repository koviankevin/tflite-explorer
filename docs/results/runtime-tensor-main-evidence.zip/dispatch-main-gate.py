import datetime,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];plan=json.loads((q/'main-gates-plan.json').read_bytes())
kind=sys.argv[1];assert kind in plan['workflows'];workflow=plan['workflows'][kind]
gh=r'H:\mc2llvm\.work\gh\bin\gh.exe';statepath=q/('main-'+kind+'-dispatch'+('-v2' if kind=='core' else '')+'.json');assert not statepath.exists(),'Reconcile existing dispatch, do not repeat.'
state={'status':'create-intent','kind':kind,'workflow':workflow,'source':plan['source'],'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'automaticRetries':False}
def save():
    with statepath.open('w',encoding='utf8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==plan['source']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
remote=json.loads(subprocess.check_output([gh,'api','repos/'+plan['repository']+'/git/ref/heads/main'],cwd=root).decode('utf-8-sig'))
assert remote['object']['sha']==plan['source'],'Main moved; inspect before dispatch.'
before=subprocess.check_output([gh,'api','repos/'+plan['repository']+'/actions/workflows/'+workflow+'/runs?event=workflow_dispatch&per_page=20'],cwd=root)
with (q/('main-'+kind+'-before-runs.json')).open('xb') as f:f.write(before)
state['knownBeforeIds']=[r['id'] for r in json.loads(before)['workflow_runs']];state['status']='dispatch-intent';save()
args=[gh,'workflow','run',workflow,'--repo',plan['repository'],'--ref','main']
if kind=='site':args+=['-f','scenario=versioned','-f','expected_build_id='+plan['candidateBuild']]
completed=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
state.update(status='accepted-await-authoritative-run' if completed.returncode==0 else 'dispatch-result-needs-reconciliation',
             exitCode=completed.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             stdout=completed.stdout.decode('utf8','replace')[:4096],stderr=completed.stderr.decode('utf8','replace')[:4096])
save();print(json.dumps({k:v for k,v in state.items() if k not in ['knownBeforeIds','stdout','stderr']}))
sys.exit(completed.returncode)
