import datetime,hashlib,json,pathlib,zipfile
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2]
load=lambda n:json.loads((q/n).read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
source='9885c97c58e30eb81f827df5a3da7520f502caa5';tree='32128382bc42a2fa8e766e9f9aa66a556df02d59'
reviews={}
for k in ['core','browser','contract','site']:
    r=load('main-'+k+'-review.json');assert r['status']=='passed-original-gate-review' and r['source']==source and r['tree']==tree
    reviews[k]=r
delivery=load('main-delivery-smoke-review.json');assert delivery['status']=='passed-reviewed' and delivery['source']==source
names=['main-gates-plan.json','main-gates-accepted-run-identities.json','main-pre-dispatch-reconciliation.json','main-core-dispatch.json','main-core-dispatch-v2.json','main-browser-dispatch.json','main-contract-dispatch.json','main-site-dispatch.json','main-delivery-artifact.zip','main-delivery-report.json','main-delivery-smoke-review.json','download-main-gate.py','review-main-gate.mjs','review-main-delivery-smoke.mjs','pr200-final-ci-review.json','pr200-final-merge-proof.json','prepare-main-review-readers.py','archive-main-gates.py','dispatch-main-gate.py','dispatch-main-gate-encoding-failure.py']
for k in reviews:
    names += ['main-'+k+'-'+s for s in ['run.json','jobs.json','artifacts.json','artifact.zip','report.json','review.json']]
records=[{'path':n,'bytes':(q/n).stat().st_size,'sha256':sha((q/n).read_bytes())} for n in names]
manifest={'format':'model-lens-runtime-tensor-main-originals','source':source,'tree':tree,'files':records,'privacy':'Metadata, diagnostics, original provider reports and review sources only. All model, weight, BMP and BIN bytes remain local and are omitted.'}
manifest_raw=(json.dumps(manifest,ensure_ascii=True,indent=2)+'\n').encode()
dest=root/'docs'/'results'/'runtime-tensor-main-evidence.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('manifest.json',manifest_raw)
    for n in names:z.write(q/n,n)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    for record in records:assert sha(z.read(record['path']))==record['sha256']
raw=dest.read_bytes()
receipt={'format':'model-lens-runtime-tensor-main-review','status':'passed-release-gates-not-yet-published','version':'1.3.1','source':source,'tree':tree,'candidateBuild':'22eff4ee82445816','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'gates':reviews,'deliverySmoke':delivery,'originals':{'path':dest.name,'bytes':len(raw),'sha256':sha(raw),'manifestSHA256':sha(manifest_raw),'records':len(records)},'limitations':['These exact main/workflow_dispatch gates do not constitute public deployment.','CPU failure of the official quantized model remains a real failure before test inputs; no original numerical equivalence claim.','Windows Chrome long-load native shutdown failure remains recorded; Linux gates and short Windows controls do not repair it.','No new mobile, Firefox/WebKit, private/company or two-hour acceptance.'],'goalComplete':False}
out=root/'docs'/'results'/'runtime-tensor-main.json';assert not out.exists();out.write_text(json.dumps(receipt,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':receipt['status'],'records':len(records),'archiveBytes':len(raw),'archiveSHA256':sha(raw),'runs':{k:v['run'] for k,v in reviews.items()}}))

