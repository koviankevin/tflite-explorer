import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
import {parseModel} from '../../../src/model-engine.js';
import {editTfliteModel} from '../../../src/tflite-model-edit.js';
import {exportTflite} from '../../../src/tflite-export.js';
import {editWorkspaceSnapshot,exportEditWorkspace} from '../../../src/model-edit-workspace.js';
import {modelEditDraft} from '../../../src/model-edit-draft.js';
import {validateTfliteConstants} from '../../../src/tflite-constant-checks.js';
import {captureGraphPattern,prepareGraphPattern,findSubgraphPatterns} from '../../../src/subgraph-pattern.js';
import {executeRuntime} from '../../../src/tflite-runtime-execute.js';
import {runtimePlan} from '../../../src/tflite-runtime-policy.js';
import {Archive} from '../../../vendor/netron/zip.js';
import {gitSource} from '../../../scripts/lib/release-artifact.mjs';
const q=new URL('./',import.meta.url),source=gitSource(),sha=b=>createHash('sha256').update(b).digest('hex');
assert.equal(source.commit,'abe045c6cc0fb8ae31f734012b75d2a949728cf9');assert.equal(source.dirty,false);
assert.equal(execFileSync('git',['diff','--name-only','7debc69df1a1c91e8ed3928a8a4932a493324180',source.commit,'--','src','vendor'],{encoding:'utf8'}).trim(),'');
const manifest=JSON.parse(await readFile(new URL('manifest.json',q),'utf8'));
const report={format:'model-lens-public-quantized-compatibility',status:'failed',source,
    publicApplication:{source:'7debc69df1a1c91e8ed3928a8a4932a493324180',build:'44782d0412ebc0b8',srcVendorDiff:[]},
    startedAt:new Date().toISOString(),corpus:manifest,phase:'setup',variants:[],runs:[],
    scope:'One official trained quantized network, two official BMP inputs using upstream byte convention, actual existing CPU WASM. No browser/soak/private data. Full edits and a real prefix cut with independent full-graph intermediate-output reference; supported-pattern and exact tensor/weight/options preservation.'};
const metadata=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',import.meta.url),'utf8'));
const parse=b=>parseModel((offset,bytes)=>b.subarray(offset,offset+bytes),b.length,metadata);
const raw=new Uint8Array(await readFile(new URL('person_detect.tflite',q)));assert.equal(sha(raw),manifest.files[0].sha256);
const file=new File([raw],'person_detect.tflite');
const base=new URL('../../../vendor/litert/2.6.0/',import.meta.url),diagnostics=[];
globalThis.self=globalThis;globalThis.require=createRequire(import.meta.url);globalThis.__dirname=fileURLToPath(base);
globalThis.importScripts=url=>vm.runInThisContext(readFileSync(new URL(url),'utf8'),{filename:fileURLToPath(url)});
globalThis.Module={locateFile:name=>fileURLToPath(new URL(name,base)),printErr:s=>{diagnostics.push(String(s));if(diagnostics.length>12)diagnostics.shift();}};
const rt=await import('../../../vendor/litert/2.6.0/core.js');let loaded=false;
const normalize=value=>JSON.parse(JSON.stringify(value,(_,v)=>typeof v==='bigint'?String(v):ArrayBuffer.isView(v)?Array.from(v):v));
const payload=(model,bytes,id)=>{const b=model.buffers[id];return b.size?bytes.subarray(Number(b.offset),Number(b.offset+b.size)):new Uint8Array(b.data||[]);};
const tensorMeta=t=>normalize({name:t.name,type:t.type,shape:t.shape,shape_signature:t.shape_signature,has_rank:t.has_rank,quantization:t.quantization,sparsity:t.sparsity,is_variable:t.is_variable});
try{
    report.phase='parse-original';const index=await parse(raw),graph=index.raw.subgraphs[0];
    assert.equal(index.raw.subgraphs.length,1);assert.ok(graph.operators.length>10&&graph.operators.length<=64);
    report.model={graphs:1,operators:graph.operators.length,tensors:graph.tensors.length,buffers:index.raw.buffers.length,operatorTypes:index.graphs[0].graph.nodes.map(n=>n.type.name)};
    assert.ok(report.model.operatorTypes.some(t=>/Depthwise/i.test(t)));
    const selected=[0,1,2];assert.ok(selected.some(i=>/Depthwise/i.test(report.model.operatorTypes[i])));
    const captured=captureGraphPattern(index.graphs[0],selected),spec={...prepareGraphPattern(captured.nodes,captured.edges),induced:true};
    const matches=await findSubgraphPatterns(index,spec);assert.equal(matches.truncated,false);assert.ok(matches.items.length>0);
    const matchKeys=r=>r.items.map(i=>JSON.stringify([i.graph,[...i.path].sort((a,b)=>a-b),i.connections.map(e=>e.join(':')).sort()])).sort();
    const originalKeys=matchKeys(matches);assert.equal(new Set(originalKeys).size,originalKeys.length);report.pattern={captured,originalMatches:originalKeys.length};
    await rt.loadLiteRt(new URL('litert_wasm_compat_internal.js',base).href);loaded=true;
    const bins=await Promise.all(manifest.inputs.map(async item=>{const bytes=new Uint8Array(await readFile(new URL(item.file,q)));assert.equal(sha(bytes),item.sha256);return {item,bytes};}));
    const run=async(label,model,blob,expected=null,classify=true)=>{
        const plan=runtimePlan(model,blob.size);assert.equal(plan.eligible,true,plan.reason);
        assert.equal(plan.inputs.length,1);assert.equal(plan.inputs[0].dtype,'int8');assert.deepEqual(plan.inputs[0].shape,[1,96,96,1]);
        const outputs=[];
        for(const [n,{item,bytes}] of bins.entries()){
            report.phase='CPU-'+label+'-'+item.file;diagnostics.length=0;
            const result=await executeRuntime({blob,plan,rt,specs:[{mode:'bin',file:new File([bytes],item.file)}],diagnostics:()=>diagnostics});
            assert.equal(result.status,'passed',JSON.stringify(result));assert.equal(result.compiled,true);assert.equal(result.invoked,true);
            const zipBytes=new Uint8Array(await result.io.archive.arrayBuffer()),zip=Archive.open(zipBytes,'zip');
            const io=JSON.parse(new TextDecoder().decode(zip.entries.get('manifest.json').peek()));assert.equal(io.validation.status,'passed');
            assert.equal(io.inputs.length,1);assert.deepEqual(new Uint8Array(zip.entries.get(io.inputs[0].file).peek()),bytes);
            const values=io.outputs.map(o=>new Uint8Array(zip.entries.get(o.file).peek()));
            if(expected)assert.deepEqual(values,expected[n]);
            let scores=null;if(classify){assert.equal(io.outputs.length,1);assert.equal(io.outputs[0].dtype,'int8');assert.equal(values[0].length,2);scores=Array.from(new Int8Array(values[0].buffer,values[0].byteOffset,2));assert.ok(scores[item.expectedHigherClass]>scores[1-item.expectedHigherClass],JSON.stringify({label,input:item.file,scores}));}
            const name=label+'-'+item.file+'.io.zip';await writeFile(new URL(name,q),zipBytes,{flag:'wx'});
            report.runs.push({label,input:item.file,status:result.status,compiled:true,invoked:true,stage:result.stage,modelSHA256:result.modelSHA256,
                inputSHA256:sha(bytes),outputs:io.outputs.map((o,i)=>({shape:o.shape,dtype:o.dtype,bytes:o.bytes,sha256:sha(values[i])})),scores,
                io:{file:name,bytes:zipBytes.length,sha256:sha(zipBytes)}});outputs.push(values);
        }
        return outputs;
    };
    const expected=await run('original',index.raw,file);
    const plans=index.raw.subgraphs.map((g,graph)=>({graph,operators:g.operators.map((_,template)=>({template}))}));
    const all=graph.operators.map((_,node)=>node),targets=all.map(node=>({graph:0,node}));
    const snapshot=editWorkspaceSnapshot(index,{targets,composition:true}),draft=modelEditDraft(snapshot);
    draft.apply({kind:'import',node:'op:0:0',nodes:all.map(node=>'op:0:'+node),label:'official public quantized network'});
    const originalByName=new Map(graph.tensors.map((t,i)=>[t.name,i]));assert.equal(originalByName.size,graph.tensors.length);
    const verifyVariant=async(label,result,sourceNodes,{fullPattern=true}={})=>{
        report.phase='reopen-'+label;const bytes=new Uint8Array(await result.blob.arrayBuffer()),reopened=await parse(bytes),candidate=reopened.raw.subgraphs[0];
        assert.equal(candidate.operators.length,sourceNodes.length);
        const weights=[];
        for(const [i,tensor] of candidate.tensors.entries()){
            const id=originalByName.get(tensor.name);assert.ok(id!==undefined,tensor.name);
            assert.deepEqual(tensorMeta(tensor),tensorMeta(graph.tensors[id]));
            const old=payload(index.raw,raw,graph.tensors[id].buffer),now=payload(reopened.raw,bytes,tensor.buffer);assert.deepEqual(now,old);
            if(old.length)weights.push({tensor:i,sourceTensor:id,bytes:old.length,sha256:sha(old)});
        }
        const ports=(g,ids)=>Array.from(ids,id=>id<0?null:g.tensors[id].name);
        for(const [i,op] of candidate.operators.entries()){
            const prior=graph.operators[sourceNodes[i]];
            assert.deepEqual(normalize(reopened.raw.operator_codes[op.opcode_index]),normalize(index.raw.operator_codes[prior.opcode_index]));
            assert.deepEqual(normalize(op.builtin_options),normalize(prior.builtin_options));assert.deepEqual(normalize(op.builtin_options_2),normalize(prior.builtin_options_2));
            assert.deepEqual(ports(candidate,op.inputs),ports(graph,prior.inputs));assert.deepEqual(ports(candidate,op.outputs),ports(graph,prior.outputs));
        }
        const search=await findSubgraphPatterns(reopened,spec),keys=matchKeys(search);assert.equal(search.truncated,false);assert.equal(new Set(keys).size,keys.length);
        if(fullPattern)assert.deepEqual(keys,originalKeys);else assert.equal(keys.length,1);
        const constants=validateTfliteConstants(reopened.raw,0,(o,n)=>bytes.subarray(o,o+n));
        const outputName=label+'.tflite';await writeFile(new URL(outputName,q),bytes,{flag:'wx'});
        report.variants.push({label,file:outputName,bytes:bytes.length,sha256:sha(bytes),operators:candidate.operators.length,tensors:candidate.tensors.length,constantTensorRanges:weights,
            quantizationAndShapesPreserved:true,optionsAndConnectionsPreserved:true,patternMatches:keys.length,constants});
        return {index:reopened,blob:result.blob};
    };
    report.phase='identity-export';const identity=await verifyVariant('identity',editTfliteModel(index,file,plans),all);
    await run('identity',identity.index.raw,identity.blob,expected);
    report.phase='full-cut';const full=await verifyVariant('full-cut',exportTflite(index,0,all,file),all);
    await run('full-cut',full.index.raw,full.blob,expected);
    report.phase='composition';const composed=await verifyVariant('composition',await exportEditWorkspace(index,file,snapshot,draft.commands),all);
    await run('composition',composed.index.raw,composed.blob,expected);
    report.phase='prefix-cut';const cutResult=exportTflite(index,0,selected,file);
    const cut=await verifyVariant('prefix-cut',cutResult,selected,{fullPattern:false});
    report.phase='full-graph-reference';const referenceResult=editTfliteModel(index,file,[{graph:0,outputs:cutResult.outputs.map(t=>t.sourceId),updateSignatures:true}]);
    const reference=await verifyVariant('full-graph-intermediate-reference',referenceResult,all);
    const intermediate=await run('full-graph-intermediate-reference',reference.index.raw,reference.blob,null,false);
    await run('prefix-cut',cut.index.raw,cut.blob,intermediate,false);
    assert.deepEqual(gitSource(),source);report.sourceUnchanged=true;report.phase='complete';report.status='passed';
}catch(error){report.error=error.stack||String(error);report.diagnostics=diagnostics.slice();process.exitCode=1;}
finally{if(loaded)rt.unloadLiteRt();report.finishedAt=new Date().toISOString();await writeFile(new URL('report.json',q),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
    console.log(JSON.stringify({status:report.status,phase:report.phase,model:report.model,patternMatches:report.pattern?.originalMatches,runs:report.runs.length,variants:report.variants.map(v=>({label:v.label,operators:v.operators,bytes:v.bytes})),error:report.error}));}
