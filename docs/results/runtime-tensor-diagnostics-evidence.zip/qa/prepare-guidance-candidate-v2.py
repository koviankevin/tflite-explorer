import hashlib,json,pathlib
q=pathlib.Path(__file__).resolve().parent
changes=[('check-tensor-diagnostic-candidate.mjs','check-tensor-diagnostic-candidate-v2.mjs',{
    '3f61b54ec502339c5f0913100e95b179ded7ad51':'0537afa2a3cd8f11f0b0a61f7f40a095664fa190',
    "'candidate-site/'":"'candidate-site-v2/'",'9bca73cd610a0f6c':'55e5b2f7588ff74c',"'negative-after/'":"'negative-after-v2/'"}),
 ('tensor-diagnostic-flow.mjs','tensor-diagnostic-flow-v2.mjs',{
    'negative-after/report.json':'negative-after-v2/report.json',
    "assert.match(state.text,/套用測試輸入之前/);":"assert.match(state.text,/套用測試輸入之前/);assert.ok(state.text.indexOf('套用測試輸入之前')<state.text.indexOf('third_party'));"}),
 ('prepare-tensor-browser-driver.py','prepare-tensor-browser-driver-v2.py',{
    'tensor-diagnostic-flow.mjs':'tensor-diagnostic-flow-v2.mjs','windows-tensor-diagnostics.mjs':'windows-tensor-diagnostics-v2.mjs',
    'browser-driver-preparation.json':'browser-driver-preparation-v2.json'}),
 ('run-tensor-browser.py','run-tensor-browser-v2.py',{
    "('windows-'+channel)":"('windows-'+channel+'-v2')","channel+'-browser-status.json'":"channel+'-browser-status-v2.json'",
    "channel+'-browser.log'":"channel+'-browser-v2.log'",'windows-tensor-diagnostics.mjs':'windows-tensor-diagnostics-v2.mjs',
    "q/'candidate-site'":"q/'candidate-site-v2'"})]
record={'status':'create-intent','source':'0537afa2a3cd8f11f0b0a61f7f40a095664fa190','build':'55e5b2f7588ff74c',
        'purpose':'Verify actual guidance-first change; keep old candidate originals and reports unchanged.',
        'oldCandidatePreserved':True,'cases':'Same bounded actual CPU negative/preservation and one Chrome/Edge small UI case each; no large/soak/deployment repeat.',
        'outputs':[]}
out=q/'guidance-v2-preparation.json';assert not out.exists();out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
for source,dest,replacements in changes:
    before=(q/source).read_text('utf8');after=before
    for old,new in replacements.items():assert old in after;after=after.replace(old,new)
    path=q/dest;assert not path.exists();path.write_text(after,encoding='utf8')
    record['outputs'].append({'file':dest,'source':source,'sha256':hashlib.sha256(after.encode()).hexdigest()})
record['status']='fresh-guidance-candidate-overlays-prepared';out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps(record))
