import assert from 'node:assert/strict';
import {once} from 'node:events';
import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {runtimeFixture} from '../../../test/runtime-fixture.mjs';
const q=new URL('./',import.meta.url);
export async function tensorDiagnosticFlow({page,read,base,directory,check}){
    const evidence=JSON.parse(await readFile(new URL('negative-after-v2/report.json',q),'utf8'));
    const location=evidence.runtime[0].failureLocations.find(x=>x.tensor===64);assert.ok(location);
    const expected=location.candidates[0],runtimeWorkers=[],modelWorkers=[];let downloads=0;
    const track=w=>{const row={url:w.url(),closed:false};if(/\/tflite-runtime-worker\.js(?:\?|$)/.test(w.url()))runtimeWorkers.push(row);else if(/\/model-worker\.js(?:\?|$)/.test(w.url()))modelWorkers.push(row);else return;w.once('close',()=>row.closed=true);};
    const download=()=>downloads++;page.on('worker',track);page.on('download',download);
    const report={status:'failed',cases:[],runtimeWorkers,modelWorkers,downloads:0,expected};
    const until=async fn=>{const end=Date.now()+35000;while(!await read(fn)){assert.ok(Date.now()<end,'Tensor diagnostic DOM timeout: '+fn);await new Promise(r=>setTimeout(r,60));}};
    const ready=()=>until(()=>document.querySelector('#model-tabs').getAttribute('aria-busy')==='false'&&document.querySelector('#loading-card').hidden&&document.querySelector('#target').getAttribute('aria-busy')==='false');
    const choose=async filename=>{const event=page.waitForEvent('filechooser');await page.locator('#open-model').click();await(await event).setFiles(filename);await ready();};
    try{
        await page.goto(base,{waitUntil:'domcontentloaded'});await until(()=>!document.querySelector('#open-model').disabled);
        await choose(fileURLToPath(new URL('person_detect.tflite',q)));await page.locator('#graph-font-size').selectOption('32');await ready();
        assert.equal(runtimeWorkers.length,0);await page.locator('#run-mode').click();await until(()=>!document.querySelector('#run-workspace').hidden&&!document.querySelector('#edit-runtime-check').disabled);
        await page.locator('#edit-runtime-check').click();await until(()=>document.querySelector('#edit-runtime-dialog').open);
        await page.locator('#runtime-input-mode-0').selectOption('zero');await page.locator('#edit-runtime-run').click();
        await until(()=>document.querySelector('#edit-runtime-result').dataset.status==='failed'&&document.querySelector('#run-workspace').getAttribute('aria-busy')==='false');
        await until(()=>document.querySelectorAll('.runtime-location').length>0);
        const state=await read(()=>({text:document.querySelector('#edit-runtime-result').textContent,buttons:Array.from(document.querySelectorAll('.runtime-location'),b=>({text:b.textContent,target:b.dataset.runtimeLocate,disabled:b.disabled})),width:innerWidth,docWidth:document.documentElement.scrollWidth}));
        assert.match(state.text,/套用測試輸入之前/);assert.ok(state.text.indexOf('套用測試輸入之前')<state.text.indexOf('third_party'));assert.match(state.text,/Tensor 64 has invalid quantization parameters/);assert.match(state.text,/tensor #64.*使用者/s);assert.ok(!state.buttons.some(b=>b.text.includes('undefined')));assert.ok(state.docWidth<=state.width+1);
        const selected=state.buttons.find(b=>b.text.includes('tensor #64')&&b.target===`${expected.graph}:${expected.node}`);assert.ok(selected&&!selected.disabled);
        await page.screenshot({path:directory+'/tensor-runtime-failure-32px.png'});report.failureState=state;
        report.cases.push('official original fails before input; raw tensor diagnostics and noncausal reference buttons at32px');
        const target=`[data-runtime-locate="${expected.graph}:${expected.node}"]`;
        for(let n=0;n<100&&!await read(selector=>document.activeElement?.matches(selector),target);n++)await page.keyboard.press('Tab');
        assert.ok(await read(selector=>document.activeElement?.matches(selector),target));await page.keyboard.press('Enter');await ready();await until(()=>document.activeElement?.dataset.resultIndex==='0');
        report.located=await read(()=>({running:document.body.classList.contains('running-model'),query:document.querySelector('#query').value,focus:document.activeElement?.dataset.resultIndex,nodes:Array.from(document.querySelectorAll('#target [data-model-node]'),e=>e.dataset.modelNode),font:document.querySelector('#graph-font-size').value}));
        assert.equal(report.located.running,false);assert.equal(report.located.query,'#'+expected.node);assert.equal(report.located.focus,'0');assert.ok(report.located.nodes.includes(String(expected.node)));assert.equal(report.located.font,'32');
        await page.screenshot({path:directory+'/tensor-runtime-location-32px.png'});report.cases.push('native keyboard activates tensor consumer reference, renders actual OP and focuses selected layer');
        const fixture=await runtimeFixture(),fresh=directory+'/replacement-runtime.tflite';await writeFile(fresh,fixture.bytes,{flag:'wx'});await choose(fresh);
        await page.locator('#run-mode').click();await until(()=>!document.querySelector('#run-workspace').hidden&&document.querySelector('#run-workspace').getAttribute('aria-busy')==='false');
        assert.equal(await page.locator('.runtime-location').count(),0);assert.ok(!await page.locator('#edit-runtime-result').textContent().then(s=>s.includes('tensor #64')));
        assert.equal(runtimeWorkers.length,1);assert.equal(downloads,0);report.cases.push('source replacement removes stale tensor links; no automatic inference or IO download');
        await page.locator('#explore-mode').click();
        while(await page.locator('#model-tabs [role="tab"]').count()){await page.locator('#close-model').click();await ready();}
        const end=Date.now()+5000;while([...runtimeWorkers,...modelWorkers].some(w=>!w.closed)&&Date.now()<end)await new Promise(r=>setTimeout(r,30));
        assert.ok(runtimeWorkers.length===1&&runtimeWorkers.every(w=>w.closed));assert.ok(modelWorkers.length>=2&&modelWorkers.every(w=>w.closed));
        report.downloads=downloads;report.status='passed';check('real tensor-error diagnostics,32px keyboard OP location, source identity reset and actual Worker closure without automatic interpreter');return report;
    }catch(error){report.error=error.stack||String(error);error.operatorValidation=report;throw error;}
    finally{page.off('worker',track);page.off('download',download);}
}
