import datetime,hashlib,json,pathlib,urllib.request
from PIL import Image
q=pathlib.Path(__file__).resolve().parent
plan=json.loads((q/'plan.json').read_bytes());assert plan['commit']=='9c74b4e7f9cb7afabea9859ef85f7df885148485'
records=[]
for item in plan['files']:
    out=q/item['name'];assert not out.exists()
    url='https://raw.githubusercontent.com/'+plan['repository']+'/'+plan['commit']+'/'+item['path']
    with urllib.request.urlopen(url,timeout=30) as response:
        assert response.geturl().startswith('https://raw.githubusercontent.com/')
        data=response.read(1024**2+1)
    assert len(data)==item['bytes']<=1024**2
    digest=hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest();assert digest==item['gitBlobSHA']
    if out.suffix=='.tflite':assert data[4:8]==b'TFL3'
    with out.open('xb') as f:f.write(data)
    records.append({**item,'url':url,'sha256':hashlib.sha256(data).hexdigest()})
inputs=[]
for name in ['person','no_person']:
    with Image.open(q/(name+'.bmp')) as image:
        assert image.size==(96,96) and image.mode in ['L','P']
        data=image.tobytes();assert len(data)==96*96
    path=q/(name+'.bin');assert not path.exists()
    with path.open('xb') as f:f.write(data)
    inputs.append({'file':path.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                   'sourceBMP':name+'.bmp','conversion':'Exact upstream PIL Image.tobytes(), bytes reinterpreted as model int8; no rescale/recenter',
                   'expectedHigherClass':1 if name=='person' else 0})
manifest={'status':'official-source-blob-identities-and-input-conversion-verified',
          'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'repository':plan['repository'],'commit':plan['commit'],'files':records,'inputs':inputs}
out=q/'manifest.json';assert not out.exists();out.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':manifest['status'],'modelBytes':records[0]['bytes'],'inputs':inputs}))
