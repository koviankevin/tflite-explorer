import datetime,hashlib,json,pathlib,re,subprocess,zipfile
q=pathlib.Path(__file__).resolve().parent;repo=q.parents[2]
load=lambda path:json.loads(path.read_bytes());sha=lambda data:hashlib.sha256(data).hexdigest()
source='0537afa2a3cd8f11f0b0a61f7f40a095664fa190';build='55e5b2f7588ff74c'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
original=load(q/'report.json');actual=load(q/'negative-after-v2/report.json')
assert original['status']=='failed' and original['phase']=='CPU-original-person.bin' and not original['variants']
assert actual['status']=='diagnostic-regression-and-preservation-passed-original-CPU-still-rejected'
assert actual['source']['commit']==source and actual['release']['buildId']==build and actual['sourceUnchanged']
assert len(actual['runtime'])==6 and len(actual['variants'])==4
for r in actual['runtime']:
    assert r['status']=='failed' and r['stage']=='compile' and not r['compiled'] and not r['invoked'] and 'io' not in r
    assert '套用測試輸入之前' in r['reason'] and r['reason'].index('套用測試輸入之前')<r['reason'].index('third_party')
    assert r['failureLocations'] and all(x['kind']=='tensor' and not x['unique'] and x['candidates'] for x in r['failureLocations'])
green=load(q/'selected-tests-green.json');assert green['exit_code']==0 and 'tests 31' in green['output'] and 'fail 0' in green['output'] and 'skipped 0' in green['output']
assert load(q/'tensor-diagnostics-red.json')['exit_code']==1 and load(q/'compile-guidance-order-red.json')['exit_code']==1
browsers=[]
for channel,variant in [('msedge','v2'),('chrome','v3')]:
    r=load(q/('windows-'+channel+'-'+variant)/'report.json');s=load(q/(channel+'-browser-status-'+variant+'.json'))
    assert r['status']==r['functionalStatus']=='passed' and s['exitCode']==0 and not s['nativeRemaining'] and s['nativeIdentities']>=2
    assert r['source']['commit']==source and r['release']['buildId']==build and r['browserClosed'] and r['processCleanup']['allReaped'] and not r['errors']
    assert len(r['nativeProcessSnapshots'])>=2 and all(w['closed'] for w in r['workers'])
    flow=r['flow'];assert flow['status']=='passed' and len(flow['cases'])==3 and flow['downloads']==0
    assert len(flow['runtimeWorkers'])==1 and all(w['closed'] for w in flow['runtimeWorkers']+flow['modelWorkers'])
    assert flow['located']['font']=='32' and flow['located']['focus']=='0' and str(flow['expected']['node']) in flow['located']['nodes']
    assert flow['failureState']['text'].index('套用測試輸入之前')<flow['failureState']['text'].index('third_party')
    assert all('undefined' not in b['text'] for b in flow['failureState']['buttons'])
    log=(q/(channel+'-browser-'+variant+'.log')).read_text('utf8')
    assert 'CloudSyncedFolderChecker' not in log and 'forcefully close' not in log and 'exitCode=0' in log
    browsers.append({'channel':channel,'version':r['browserVersion'],'status':'passed','nativeIdentities':s['nativeIdentities'],
                     'workers':len(r['workers']),'runtimeWorkers':len(flow['runtimeWorkers']),'cases':flow['cases'],
                     'reportSHA256':sha((q/('windows-'+channel+'-'+variant)/'report.json').read_bytes())})
failed=load(q/'windows-chrome-v2/report.json');assert failed['status']=='failed' and "undefined !== '0'" in failed['error']
members={};records=[];omitted=[]
def add(path,name):
    assert path.is_file() and path.stat().st_size<4*1024**2
    data=path.read_bytes();assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,}|[?&](?:sig|X-Amz-Signature|Signature)=)',data),name
    assert name not in members;members[name]=data
    records.append({'path':name,'bytes':len(data),'sha256':sha(data),'modified':False})
# These explicit QA directories contain only this task's artifacts. Never walk
# the built site or shared caches; all model/image/input bytes stay local.
for folder in [q,q/'negative-after',q/'negative-after-v2',*[q/n for n in ['windows-msedge','windows-chrome','windows-msedge-v2','windows-chrome-v2','windows-chrome-v3']]]:
    for path in sorted(folder.iterdir()):
        if not path.is_file():continue
        name='qa/'+str(path.relative_to(q)).replace('\\','/')
        if path.suffix in ['.tflite','.bmp','.bin']:
            omitted.append({'path':name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'reason':'Model, image and raw input bytes remain local; fixed public source URL/blob identity or generating QA source retained.'})
        elif path.suffix in ['.json','.mjs','.py','.log','.png'] or path.name=='LICENSE':add(path,name)
for name in ['src/tflite-runtime-diagnostics.js','src/tflite-runtime-execute.js','src/model-runtime-workspace-ui.js','test/tflite-runtime-diagnostics.test.mjs','test/browser/windows-operator-validation.mjs','LICENSE']:
    add(repo/name,'source/'+name)
readme='''# Runtime tensor diagnostic candidate evidence

Candidate source0537afa / build55e5b2f7588ff74c, version1.3.1; not yet published.
Original official tflite-micro person_detect model is CPU-incompatible with the
existing LiteRT.js2.6.0: invalid quantized_dimension, before inputs/invoke. Keep
the original failing report; do not claim original numerical execution/equivalence.
The model bytes are never patched/normalized to manufacture runtime success.

Three initial diagnostic regressions failed; a further guidance-order assertion
failed after screenshot review showed native paths before the actionable message.
Final31 related tests pass, including actual positive CPU controls. Final actual
public-model checks preserve failed compile results while verifying tensor links,
zero/raw BIN pre-input semantics, identity/full-cut/composition/three-OP-prefix
reopens, every retained tensor's quantization/weights/options/connections and the
same saved pattern once. Six actual CPU negatives have no invoke/IO success.

Installed Edge v2 and Chrome v3 both pass native chooser, manual input dialog,
real CPU failure,32px, native keyboard OP navigation and focus, source replacement,
actual Worker closure and original native shutdown. Both use original flags;
neither opts out of cloud telemetry. These short cases do not fix the historical
Windows default shutdown failure after longer workloads.

Chrome v2's immediate focus snapshot failed after graph busy=false but before
the awaited navigation focus. Keep that failure. v3 waits for actual focused
result within the same35sUI bound; no app/timeout/close/security change, no Edge
repeat. Older candidate reports/screenshots stay at their original source.

All model, image and raw BIN bytes remain local, even this licensed public sample;
manifest records hashes and fixed upstream Git blobs/URLs for local reproduction.
Only bounded diagnostics, metadata, source, license, screenshots and original
process/test results are archived. No company model, credentials or private data.
No deployment/Release rewrite, safety/RSS/URL/runtime policy change or extra soak.
This archive is evidence, not automatic permission to execute browser controllers.
'''
members['README.md']=readme.encode()
manifest={'format':'model-lens-runtime-tensor-original-evidence','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'records':records,'omittedLocalData':omitted,'evidenceModified':False,'readmeSHA256':sha(members['README.md'])}
members['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'docs/results/runtime-tensor-diagnostics-evidence.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for row in records:assert sha(z.read(row['path']))==row['sha256']
receipt={'schemaVersion':1,'format':'model-lens-runtime-tensor-diagnostics-candidate','status':'candidate-targeted-checks-reviewed-not-published',
         'createdAt':manifest['createdAt'],'source':actual['source'],'release':actual['release'],'selectedTests':{'tests':31,'pass':31,'fail':0,'skipped':0},
         'actualCPUNegatives':len(actual['runtime']),'originalModelCPUStatus':'failed compile; no invoke, equivalence not verified',
         'preservationVariants':[{'label':v['label'],'operators':v['operators'],'bytes':v['bytes'],'sha256':v['sha256'],'constantTensorRanges':len(v['weights']),'patternMatches':v['patternMatches']} for v in actual['variants']],
         'windows':browsers,'initialChromeV2FocusObservationFailurePreserved':True,'nativeFlagsAndBoundsChanged':False,
         'modelWeightsOrInputsPublished':False,'archive':{'file':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'members':len(members),'originalRecords':len(records),'manifestSHA256':sha(members['manifest.json']),'crc':'passed','allRecordedSHA256':'passed'},
         'published':False,'historicalChromeNativeShutdownFixed':False,'goalComplete':False}
out=repo/'docs/results/runtime-tensor-diagnostics-candidate.json';assert not out.exists();out.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':receipt['status'],'archive':receipt['archive'],'windows':browsers}))
