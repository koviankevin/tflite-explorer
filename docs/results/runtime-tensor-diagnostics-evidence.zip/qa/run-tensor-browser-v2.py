import datetime,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2]
channel=sys.argv[1];assert channel in ['chrome','msedge'];out=q/('windows-'+channel+'-v2');status=q/(channel+'-browser-status-v2.json');log=q/(channel+'-browser-v2.log')
assert not out.exists() and not status.exists() and not log.exists()
state={'status':'create-intent','channel':channel,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'automaticRetries':False,
       'scope':'One real public-model diagnostic UI case, original canonical browser flags and10s native close; no physical/soak/deploy'}
def save():
    with status.open('w',encoding='utf8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save();node=r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
env={**os.environ,'MODEL_LENS_QA_PYTHON':sys.executable,'DEBUG':'pw:browser'}
with log.open('xb') as f:
    p=subprocess.Popen([node,str(q/'windows-tensor-diagnostics-v2.mjs'),channel,str(q/'candidate-site-v2'),str(out),'--allow-local-browser'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
    state.update(status='running',pid=p.pid);save();code=p.wait()
native=root/'test/browser/windows-process-memory.py';scope={'__name__':'owned_tensor_browser_reconciliation'}
exec(compile(native.read_text('utf8').split('observer=Observer()')[0],str(native),'exec'),scope)
report=json.loads((out/'report.json').read_bytes());groups=[report.get(k,{}) for k in ['failureNativeObservation','processCleanup']]
identities={(i['pid'],i['startTicks']):i for g in groups for i in g.get('identities',[])}
table=scope['snapshot']();remaining=[]
for identity in identities.values():
    row=table.get(identity['pid'])
    if row:
        actual=scope['inspect']({**row,'startTicks':identity['startTicks']})
        if actual:remaining.append(actual)
state.update(status='producer-exited',exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             functionalStatus=report.get('functionalStatus'),wholeStatus=report['status'],nativeIdentities=len(identities),nativeRemaining=remaining)
save();print(json.dumps(state));sys.exit(code)
