import hashlib,json,pathlib,re
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];source=root/'test/browser/windows-operator-validation.mjs'
text=source.read_text('utf8')
def replace(match):
    target=match[1]
    if target=='./operator-validation-flow.mjs':return "from '"+(q/'tensor-diagnostic-flow.mjs').as_uri()+"'"
    if target=='playwright':return "from '"+(root/'node_modules/playwright/index.mjs').as_uri()+"'"
    if target.startswith('.'):return "from '"+(source.parent/target).resolve().as_uri()+"'"
    return match[0]
overlay=re.sub(r"from '([^']+)'",replace,text).replace('operatorValidationFlow','tensorDiagnosticFlow')
overlay=overlay.replace('model-lens-windows-operator-validation','model-lens-windows-runtime-tensor-diagnostics')
overlay=overlay.replace('Public synthetic UI on authenticated original HTML fixture','Official licensed public-model diagnostic UI on authenticated original HTML fixture')
out=q/'windows-tensor-diagnostics.mjs';assert not out.exists();out.write_text(overlay,encoding='utf8')
receipt={'status':'source-bound-existing-native-driver-overlay-prepared','base':'test/browser/windows-operator-validation.mjs','baseSHA256':hashlib.sha256(text.encode()).hexdigest(),
         'overlaySHA256':hashlib.sha256(overlay.encode()).hexdigest(),'onlyChanges':['Resolve imports to recorded source','Use bounded tensor diagnostic flow and report label'],
         'originalNativeClose10sAndSecurityFlagsUnchanged':True}
(q/'browser-driver-preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
