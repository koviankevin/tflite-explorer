# Runtime tensor diagnostic candidate evidence

Candidate source0537afa / build55e5b2f7588ff74c, version1.3.1; not yet published.
Original official tflite-micro person_detect model is CPU-incompatible with the
existing LiteRT.js2.6.0: invalid quantized_dimension, before inputs/invoke. Keep
the original failing report; do not claim original numerical execution/equivalence.
The model bytes are never patched/normalized to manufacture runtime success.

Three initial diagnostic regressions failed; a further guidance-order assertion
failed after screenshot review showed native paths before the actionable message.
Final31 related tests pass, including actual positive CPU controls. Final actual
public-model checks preserve failed compile results while verifying tensor links,
zero/raw BIN pre-input semantics, identity/full-cut/composition/three-OP-prefix
reopens, every retained tensor's quantization/weights/options/connections and the
same saved pattern once. Six actual CPU negatives have no invoke/IO success.

Installed Edge v2 and Chrome v3 both pass native chooser, manual input dialog,
real CPU failure,32px, native keyboard OP navigation and focus, source replacement,
actual Worker closure and original native shutdown. Both use original flags;
neither opts out of cloud telemetry. These short cases do not fix the historical
Windows default shutdown failure after longer workloads.

Chrome v2's immediate focus snapshot failed after graph busy=false but before
the awaited navigation focus. Keep that failure. v3 waits for actual focused
result within the same35sUI bound; no app/timeout/close/security change, no Edge
repeat. Older candidate reports/screenshots stay at their original source.

All model, image and raw BIN bytes remain local, even this licensed public sample;
manifest records hashes and fixed upstream Git blobs/URLs for local reproduction.
Only bounded diagnostics, metadata, source, license, screenshots and original
process/test results are archived. No company model, credentials or private data.
No deployment/Release rewrite, safety/RSS/URL/runtime policy change or extra soak.
This archive is evidence, not automatic permission to execute browser controllers.
