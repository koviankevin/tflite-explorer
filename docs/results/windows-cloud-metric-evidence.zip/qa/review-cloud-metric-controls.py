"""Read both completed native controls and prove their single launch-variable delta."""
import datetime,hashlib,json,pathlib,re
q=pathlib.Path(__file__).resolve().parent
load=lambda n:json.loads((q/n).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=load('cloud-metric-default.json');changed=load('cloud-metric-disabled.json')
key=load('chrome-symbol-key.json');ranges=load('chrome-public-key-function-ranges.json')['rows']
details=[]
for mode,r in [('default',original),('disabled',changed)]:
    stem='cloud-metric-'+mode;state=load(stem+'-status.json');cleanup=load(stem+'-cleanup.json')
    assert state['status']=='producer-exited' and state['automaticRetries'] is False
    assert r['source']['commit']=='f592e3d9df7ed48fae2ca19e353c7215638959a3' and not r['source']['dirty']
    assert r['version']['product']=='Chrome/156.0.8078.76' and r['cloudControl']['mode']==mode
    assert r['actualCDPRootVerified'] and r['cloudControl']['diagnosticOnly'] and not r['cloudControl']['canonicalAcceptanceChanged']
    assert any(e['kind']=='idle-end' for e in r['events'])
    idle_start=next(e['elapsedMs'] for e in r['events'] if e['kind']=='idle-start')
    idle_end=next(e['elapsedMs'] for e in r['events'] if e['kind']=='idle-end')
    assert idle_end-idle_start>=25000
    assert any(e['kind']=='context-close-end' for e in r['events'])
    admitted={}
    for snap in r['snapshots']:
        for row in snap['rows']:admitted[(row['pid'],row['startTicks'])]=row
    assert len(admitted)>=2
    final=cleanup.get('remainingAfterForced',cleanup.get('afterPipeEOF'))
    assert final is not None and not final['rows']
    assert set(admitted).issubset({(r['pid'],r['startTicks']) for r in final['identities']})
    passed=r['status']=='normal-native-exit'
    if passed:
        assert state['exitCode']==0 and r['childExitObserved'] and not r['normalNativeObservation']['rows'] and r['normalCloseMs']<=10000
        assert 'forced' not in cleanup
    else:
        assert state['exitCode']==1 and r['normalCloseMs']>=10000 and r['failureNativeObservation']['rows']
    details.append({'mode':mode,'status':r['status'],'exitCode':state['exitCode'],
                    'normalCloseMs':r['normalCloseMs'],'nativeIdentities':len(admitted),
                    'allAdmittedObservedExitedAfterCleanup':True,'forcedCleanup':'forced' in cleanup,
                    'reportSHA256':sha(q/(stem+'.json')),'logSHA256':sha(q/(stem+'.log'))})
normalize=lambda args:['--user-data-dir=<owned-temp>' if a.startswith('--user-data-dir=') else a for a in args]
a=normalize(original['launch']['args']);b=normalize(changed['launch']['args'])
assert len(a)==len(b)
diffs=[(x,y) for x,y in zip(a,b) if x!=y]
assert len(diffs)==1 and diffs[0][0].startswith('--disable-features=') and diffs[0][1]==diffs[0][0]+',CloudSyncedFolderChecker'
assert original['launch']['executable']==changed['launch']['executable']
assert original['launch']['profile']!=changed['launch']['profile']
assert original['driverSHA256']==changed['driverSHA256']
assert original['launch']['baselineLogSHA256']==changed['launch']['baselineLogSHA256']
capture=q/'cloud-metric-default-native-stack.json'
stack_facts=None
if capture.exists():
    stack=load(capture.name)
    assert stack['status']=='captured-owned-native-stacks' and stack['detached']
    assert stack['failureCheckpointSHA256']==sha(q/'cloud-metric-default.json')
    assert stack['identity']['pid']==original['root']['pid'] and stack['identity']['startTicks']==original['root']['startTicks']
    text=stack['output']
    modules=text[text.index('start             end'):]
    mod=re.search(r'^([0-9a-f]{8}`[0-9a-f]{8})\s+([0-9a-f]{8}`[0-9a-f]{8})\s+chrome\s+(.*)$',modules,re.M)
    assert mod and key['binary'] in mod[3]
    base=int(mod[1].replace('`',''),16);assert int(mod[2].replace('`',''),16)-base==key['imageSize']
    headers=list(re.finditer(r'^\s*\.?\s*(\d+)\s+Id:\s*([0-9a-f]+)\.([0-9a-f]+).*$',text,re.M))
    matches=[]
    for i,m in enumerate(headers):
        end=headers[i+1].start() if i+1<len(headers) else text.index('start             end')
        block=text[m.end():end];prev=None
        for line in block.splitlines():
            f=re.match(r'^\s*[0-9a-f]{8}`[0-9a-f]{8}\s+([0-9a-f]{8}`[0-9a-f]{8})\s+(.*)$',line)
            if not f:continue
            if prev is not None and re.match(r'chrome(?:!|\+)',f[2]):
                rva=prev-base
                for proven in ranges:
                    if proven['actualFunctionStart']<=rva<proven['actualFunctionEnd']:
                        matches.append({'thread':int(m[1]),'rva':rva,'function':proven['name'],
                                        'actualPEFunctionRangeMatched':True,
                                        'windowsDirectoryQueryInSameStack':'ntdll!NtQueryDirectoryFile' in block,
                                        'windowsCloudFileQueryInSameStack':all(s in block for s in ['ntdll!ZwFsControlFile','cldapi!CfRetrieveProperties','windows_storage'])})
            prev=int(f[1].replace('`',''),16)
    stack_facts={'status':stack['status'],'stackSHA256':sha(capture),'functionMatches':matches,
                 'mainTaskTrackerShutdown':any(x['thread']==0 and any('CompleteShutdown@TaskTracker' in n for n in x['function']) for x in matches),
                 'cloudMetricInsideWindowsDirectoryQuery':any(x['windowsDirectoryQueryInSameStack'] and any('EvaluateOneDriveSyncStatus' in n for n in x['function']) for x in matches),
                 'cloudMetricInsideWindowsCloudFileQuery':any(x['windowsCloudFileQueryInSameStack'] and any('EvaluateOneDriveSyncStatus' in n for n in x['function']) for x in matches)}
    assert stack_facts['mainTaskTrackerShutdown'] and stack_facts['cloudMetricInsideWindowsCloudFileQuery']
result={'format':'model-lens-cloud-metric-paired-control-review',
        'status':'two-predeclared-controls-completed-and-reviewed',
        'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'controls':details,'onlyLaunchDelta':'append CloudSyncedFolderChecker to existing disabled-feature list, apart from independent owned temp profiles',
        'actualDefaultFailureStack':stack_facts,
        'inferenceLimit':'One controlled pair supports a local mechanism; no arbitrary-model or all-historical Chrome guarantee. Diagnostic feature opt-out is not canonical acceptance or an app fix.',
        'canonicalAcceptanceChanged':False,'rootCauseFixed':False,'goalComplete':False}
dest=q/'cloud-metric-paired-review-v2.json';assert not dest.exists();dest.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
