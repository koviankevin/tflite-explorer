import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
import {once} from 'node:events';
import {readFile,writeFile,mkdtemp} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {windowsProcessObserver} from '../../../test/browser/windows-process-memory.mjs';
import {gitSource} from '../../../scripts/lib/release-artifact.mjs';
assert.equal(process.platform,'win32');assert.ok(process.argv.includes('--allow-local-browser'));
const q=path.dirname(fileURLToPath(import.meta.url)),output=process.env.DIRECT_CLOSE_REPORT,python=process.env.MODEL_LENS_QA_PYTHON;
assert.ok(output&&python);const source=gitSource();assert.equal(source.dirty,false);assert.equal(source.commit,'f592e3d9df7ed48fae2ca19e353c7215638959a3');
const pause=ms=>new Promise(r=>setTimeout(r,ms)),started=performance.now();
const report={format:'model-lens-direct-CDP-close-diagnostic',status:'failed',source,startedAt:new Date().toISOString(),
    diagnosticOnly:true,driverSHA256:createHash('sha256').update(await readFile(fileURLToPath(import.meta.url))).digest('hex'),
    events:[],snapshots:[],errors:[],protocolCommands:[],scope:'No Playwright import/launcher, same recordedSDK1.64.1 arguments except owned temporary profile. Public empty page only,25s idle,10s normal close bound. No product acceptance, application or model.'};
const event=(kind,data={})=>report.events.push({kind,elapsedMs:Math.round(performance.now()-started),...data});
let child,observer,pending=new Map(),nextId=1,buffer=Buffer.alloc(0),pipeDisconnected=false,exitSeen=false,closing=false;
const admitted=new Map();let stderr='',stdout='';
function rejectPending(message){for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error(message));}pending.clear();}
function send(method,params={},sessionId){assert.ok(child&&!pipeDisconnected);const id=nextId++;report.protocolCommands.push({id,method});return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP command timeout: '+method));},10000);pending.set(id,{resolve,reject,timer});
    const command={id,method,params};if(sessionId)command.sessionId=sessionId;
    child.stdio[3].write(JSON.stringify(command)+'\0',error=>{if(error&&pending.has(id)){pending.delete(id);clearTimeout(timer);reject(error);}});
});}
async function snapshot(phase,remaining=false){const s=await observer[remaining?'remaining':'sample']();report.snapshots.push({phase,...s});for(const row of s.rows)admitted.set(row.pid+':'+row.startTicks,row);return s;}
try{
    const raw=await readFile(path.join(q,'sdk1641-1.log'),'utf8'),line=raw.split('\n').find(s=>s.includes('<launching>'));
    const exe='C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',prefix='<launching> '+exe+' ';
    assert.ok(line.includes(prefix));const baselineArgs=line.slice(line.indexOf(prefix)+prefix.length).trim().split(' ');
    assert.equal(baselineArgs.filter(a=>a.startsWith('--user-data-dir=')).length,1);
    assert.ok(baselineArgs.includes('--remote-debugging-pipe')&&baselineArgs.includes('--no-startup-window'));
    assert.ok(baselineArgs.every(a=>a.startsWith('--')));
    const profile=await mkdtemp(path.join(os.tmpdir(),'model-lens-direct-close-'));
    const args=baselineArgs.map(a=>a.startsWith('--user-data-dir=')?'--user-data-dir='+profile:a);
    report.launch={executable:exe,args,profile,baselineLogSHA256:createHash('sha256').update(raw).digest('hex'),onlyArgumentReplacement:'--user-data-dir'};
    child=spawn(exe,args,{windowsHide:true,detached:false,stdio:['ignore','pipe','pipe','pipe','pipe']});
    await once(child,'spawn');event('spawned',{pid:child.pid});
    child.once('exit',(code,signal)=>{exitSeen=true;event('native-child-exit',{code,signal});});
    child.stdout.on('data',b=>{stdout=(stdout+b.toString()).slice(-65536);});child.stderr.on('data',b=>{stderr=(stderr+b.toString()).slice(-65536);});
    child.stdio[3].on('error',error=>event('cdp-write-error',{code:error.code}));
    child.stdio[4].on('error',error=>event('cdp-read-error',{code:error.code}));
    child.stdio[4].on('end',()=>{pipeDisconnected=true;event('cdp-disconnected');rejectPending('CDP disconnected');});
    child.stdio[4].on('data',chunk=>{
        buffer=Buffer.concat([buffer,chunk]);assert.ok(buffer.length<4*1024**2);
        for(let i;(i=buffer.indexOf(0))!==-1;){const bytes=buffer.subarray(0,i);buffer=buffer.subarray(i+1);if(!bytes.length)continue;
            const message=JSON.parse(bytes.toString());const item=pending.get(message.id);if(!item)continue;pending.delete(message.id);clearTimeout(item.timer);
            if(message.error)item.reject(Error(JSON.stringify(message.error)));else item.resolve(message.result);
        }
    });
    // Native helper proves direct child ownership before the protocol session;
    // actual SystemInfo is cross-checked below, not substituted for successful CDP.
    observer=await windowsProcessObserver({python,cdp:{send:async()=>({processInfo:[{type:'browser',id:child.pid}]})},channel:'chrome'});
    report.root={...observer.root,parent:process.pid,name:'chrome.exe'};admitted.set(report.root.pid+':'+report.root.startTicks,report.root);
    const actual=await send('SystemInfo.getProcessInfo');assert.equal(actual.processInfo.find(p=>p.type==='browser').id,child.pid);
    report.actualCDPRootVerified=true;report.version=await send('Browser.getVersion');
    const {browserContextId}=await send('Target.createBrowserContext',{disposeOnDetach:false});
    const {targetId}=await send('Target.createTarget',{url:'about:blank',browserContextId});
    const {sessionId}=await send('Target.attachToTarget',{targetId,flatten:true});
    const pageSend=(method,params)=>send(method,params,sessionId);
    await pageSend('Page.enable');const {frameTree}=await pageSend('Page.getFrameTree');
    await pageSend('Page.setDocumentContent',{frameId:frameTree.frame.id,html:'<!doctype html><meta charset="utf-8"><title>Public empty close diagnostic</title><p>Public synthetic empty page</p>'});
    await pageSend('Performance.enable');const title=await pageSend('Runtime.evaluate',{expression:'document.title',returnByValue:true});assert.equal(title.result.value,'Public empty close diagnostic');
    await pageSend('Runtime.getHeapUsage');await pageSend('Memory.getDOMCounters');
    await snapshot('before-idle');event('idle-start');await pause(25000);event('idle-end');
    const before=await snapshot('before-close');assert.ok(before.rows.some(r=>r.pid!==child.pid));
    event('context-close-start');await send('Target.disposeBrowserContext',{browserContextId});event('context-close-end');
    closing=true;event('browser-close-start');const closeAt=performance.now();
    const closePromise=send('Browser.close');closePromise.then(()=>event('browser-close-response'),e=>event('browser-close-response-error',{message:e.message}));
    let remaining;do{remaining=await observer.remaining();if(exitSeen&&!remaining.rows.length)break;await pause(50);}while(performance.now()-closeAt<10000);
    report.normalCloseMs=performance.now()-closeAt;report.normalNativeObservation=remaining;report.childExitObserved=exitSeen;
    assert.ok(exitSeen&&remaining.rows.length===0&&report.normalCloseMs<=10000,'direct Browser.close native exit exceeded10s');
    event('normal-close-end');assert.deepEqual(gitSource(),source);report.status='normal-native-exit';
}catch(error){report.error=error.stack||String(error);event('failed',{message:error.message});if(observer)report.failureNativeObservation=await snapshot('failure',true).catch(e=>({error:e.message}));}
finally{
    report.stdout=stdout;report.stderr=stderr;report.finishedAt=new Date().toISOString();
    await writeFile(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
    const cleanup={phase:'after-original-result-persisted',originalStatus:report.status,normalCloseAcceptance:report.status==='normal-native-exit',events:[]};
    if(child){
        // Closing the control transport is a secondary observation, never a pass.
        child.stdio[3].end();child.stdio[4].destroy();rejectPending('Post-result pipe closure');
        if(observer){
            const until=Date.now()+10000;let remaining=await observer.remaining();
            while(remaining.rows.length&&Date.now()<until){await pause(100);remaining=await observer.remaining();}
            cleanup.afterPipeEOF={...remaining,childExitObserved:exitSeen};
            if(remaining.rows.length){
                cleanup.forced=JSON.parse(execFileSync(python,[path.join(q,'cleanup-direct-owned.py')],{input:JSON.stringify({root:report.root,parentPid:process.pid,rows:remaining.rows,admitted:[...admitted.values()]}),encoding:'utf8',windowsHide:true,timeout:15000,maxBuffer:65536}));
                cleanup.remainingAfterForced=await observer.remaining();assert.equal(cleanup.remainingAfterForced.rows.length,0);
            }
            cleanup.observerClose=await observer.close();
        }
        child.stdout.destroy();child.stderr.destroy();
    }
    cleanup.finishedAt=new Date().toISOString();await writeFile(output.replace(/\.json$/,'-cleanup.json'),JSON.stringify(cleanup,null,2)+'\n',{flag:'wx'});
    console.log(JSON.stringify({status:report.status,error:report.error,normalCloseMs:report.normalCloseMs,remaining:report.failureNativeObservation?.rows,afterPipeEOF:cleanup.afterPipeEOF?.rows,forced:cleanup.forced?.results}));
    process.exit(report.status==='normal-native-exit'?0:1);
}
