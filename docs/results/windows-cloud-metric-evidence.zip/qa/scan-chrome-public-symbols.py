"""Bounded offline CodeView public-record scan; not a debugger or symbol server."""
import bisect, collections, ctypes as c, datetime, hashlib, json, pathlib, re, struct, time, uuid
q = pathlib.Path(__file__).resolve().parent
load = lambda n: json.loads((q/n).read_bytes())
key = load('chrome-symbol-key.json')
receipt = load('chrome-symbols-156.0.8078.76/pdb-identity-verification.json')
summary = load('chrome-physical-stack-1-stack-summary.json')
assert summary['rawSHA256'] == key['stackSHA256']
started = time.monotonic(); deadline = started + 90
out = q/'chrome-public-symbols.json'; assert not out.exists()
result = {'status': 'failed', 'scope': 'Independent bounded public-record interpretation only; no normal-debugger exact-match claim or live process.',
          'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'PDBSHA256PreviouslyVerified': receipt['rawSHA256'], 'stackSHA256': key['stackSHA256'],
          'normalDebuggerExactMatchProven': False, 'rootCauseFixed': False}
class MSF:
    def __init__(self, path):
        self.file = path.open('rb'); self.reads = 0
        self.file.seek(0); h = self.file.read(56)
        assert h[:32] == b'Microsoft C/C++ MSF 7.00\r\n\x1aDS\0\0\0'
        self.block,free,self.blocks,sz,res,mp = struct.unpack_from('<6I', h, 32)
        assert self.block == 8192 and self.blocks*self.block == path.stat().st_size == receipt['rawBytes']
        assert 0 < sz < 16*1024**2
        n = (sz+self.block-1)//self.block
        assert n*4 <= self.block and mp < self.blocks
        self.file.seek(mp*self.block); ids = struct.unpack('<'+'I'*n, self.file.read(4*n))
        parts=[]
        for index in ids:
            assert index < self.blocks
            self.file.seek(index*self.block); parts.append(self.file.read(self.block))
        self.directory = b''.join(parts)[:sz]; self.reads += n*self.block+4*n+56
        count = struct.unpack_from('<I', self.directory)[0]
        assert count == receipt['streamCount']
        self.sizes = struct.unpack_from('<'+'I'*count, self.directory, 4)
        self.offsets=[]; cursor=4+4*count
        for size in self.sizes:
            self.offsets.append(cursor)
            cursor += 0 if size == 0xffffffff else 4*((size+self.block-1)//self.block)
        assert cursor == len(self.directory)
    def read(self, stream, off, count):
        assert time.monotonic() < deadline, '90-second offline scan bound'
        assert 0 <= count <= 1024**2 and 0 <= off <= self.sizes[stream]-count
        parts=[]
        while count:
            page, within = divmod(off, self.block); take=min(count, self.block-within)
            number=struct.unpack_from('<I', self.directory, self.offsets[stream]+page*4)[0]
            assert number < self.blocks
            self.file.seek(number*self.block+within); part=self.file.read(take); assert len(part)==take
            parts.append(part); off+=take; count-=take; self.reads+=take
            assert self.reads <= 800*1024**2
        return b''.join(parts)
try:
    pdb=MSF(q/'chrome-symbols-156.0.8078.76/chrome.dll.pdb')
    info=pdb.read(1,0,28); dbi=pdb.read(3,0,64)
    guid=str(uuid.UUID(bytes_le=info[12:28])); age=struct.unpack_from('<I',dbi,8)[0]
    assert guid==key['guid']==receipt['PDBGuid'] and age==key['age']==receipt['DBIAge']
    assert struct.unpack_from('<I',info,8)[0]==receipt['PDBInfoAge']
    symbol_stream=struct.unpack_from('<H',dbi,20)[0]
    dbi_sizes=struct.unpack_from('<5i',dbi,24); optional,ec=struct.unpack_from('<ii',dbi,48)
    assert all(v>=0 for v in dbi_sizes) and optional==22 and ec>=0
    indexes=struct.unpack('<11H',pdb.read(3,64+sum(dbi_sizes)+ec,optional))
    assert indexes[3]==indexes[4]==0xffff, 'OMAP requires a different mapping; do not guess'
    sections_pdb=pdb.read(indexes[5],0,pdb.sizes[indexes[5]])
    binary=pathlib.Path(key['binary'])
    with binary.open('rb') as pe:
        sha=hashlib.sha256()
        for chunk in iter(lambda:pe.read(1024**2),b''): sha.update(chunk)
        assert sha.hexdigest()==key['binarySHA256']
        pe.seek(0x3c); position=struct.unpack('<I',pe.read(4))[0]
        pe.seek(position); header=pe.read(24); assert header[:4]==b'PE\0\0'
        nsections=struct.unpack_from('<H',header,6)[0]; osize=struct.unpack_from('<H',header,20)[0]
        optional_header=pe.read(osize); assert struct.unpack_from('<I',optional_header,56)[0]==key['imageSize']
        sections=pe.read(nsections*40); assert sections==sections_pdb
        layout=[struct.unpack_from('<4I',sections,i*40+8) for i in range(nsections)]
        def read_rva(rva,count):
            for vs,va,rawsz,rawptr in layout:
                if va<=rva and rva+count<=va+rawsz:
                    pe.seek(rawptr+rva-va); data=pe.read(count); assert len(data)==count; return data
            raise AssertionError('RVA not in raw section')
        exp_rva,exp_bytes=struct.unpack_from('<II',optional_header,112)
        eh=read_rva(exp_rva,40); nf,nn,ft,nt,ot=struct.unpack_from('<5I',eh,20)
        assert 1<=nn<=4096 and nn<=nf<=4096
        functions=struct.unpack('<'+'I'*nf,read_rva(ft,nf*4)); names=struct.unpack('<'+'I'*nn,read_rva(nt,nn*4)); ordinals=struct.unpack('<'+'H'*nn,read_rva(ot,nn*2))
        exports={}
        for nr,ordinal in zip(names,ordinals):
            name=read_rva(nr,256).split(b'\0')[0].decode('ascii'); assert ordinal<nf
            exports[name]=functions[ordinal]
    base=int(key['loadedModule']['start'].replace('`',''),16)
    frames=[]
    for thread in summary['threads']:
        prev=None
        for idx,line in enumerate(thread['frames']):
            m=re.match(r'^[0-9a-f]{8}`[0-9a-f]{8}\s+([0-9a-f]{8}`[0-9a-f]{8})\s+(.*)$',line); assert m
            if prev is not None and re.match(r'chrome(?:!|\+)',m[2]):
                assert base<=prev<base+key['imageSize']
                frames.append({'thread':thread['index'],'threadName':thread['name'],'frame':idx,'address':hex(prev),'rva':prev-base})
            prev=int(m[1].replace('`',''),16)
    targets=sorted(set(r['rva'] for r in frames)); best=[-1]*len(targets); aliases=[[] for _ in targets]
    anchored={}; types=collections.Counter(); scanned=0; pending=b''; record_count=0
    print(json.dumps({'phase':'scan-start','symbolStreamBytes':pdb.sizes[symbol_stream],'targetAddresses':len(targets)}),flush=True)
    while scanned<pdb.sizes[symbol_stream]:
        size=min(1024**2,pdb.sizes[symbol_stream]-scanned)
        data=pending+pdb.read(symbol_stream,scanned,size); scanned+=size; cursor=0
        while cursor+4<=len(data):
            length,kind=struct.unpack_from('<HH',data,cursor); assert length>=2
            end=cursor+length+2
            if end>len(data): break
            types[kind]+=1; record_count+=1
            if kind==0x110e:
                assert length>=13
                flags,offset,segment=struct.unpack_from('<IIH',data,cursor+4)
                assert 1<=segment<=nsections
                vs,va,rawsz,rawptr=layout[segment-1]; assert offset<max(vs,rawsz)
                rva=va+offset
                namebytes=data[cursor+14:end].split(b'\0')[0]
                name=namebytes.decode('utf8')
                if name in exports:
                    assert exports[name]==rva, (name,exports[name],rva)
                    anchored[name]=rva
                if flags&3:
                    index=bisect.bisect_left(targets,rva)
                    while index<len(targets) and best[index]<=rva:
                        if best[index]<rva: best[index]=rva; aliases[index]=[]
                        if len(aliases[index])<20 and name not in aliases[index]: aliases[index].append(name)
                        index+=1
            cursor=end
        pending=data[cursor:]; assert len(pending)<65538
    assert not pending and 'ChromeMain' in anchored and len(anchored)>=3
    for row in frames:
        idx=bisect.bisect_left(targets,row['rva']); assert best[idx]>=0
        row.update(symbolRVA=best[idx],displacement=row['rva']-best[idx],publicAliases=aliases[idx])
    result.update(status='bounded-public-records-mapped-with-PE-export-anchors',
                  PDBGuid=guid,DBIAge=age,PDBInfoAge=receipt['PDBInfoAge'],
                  PESectionsEqual=True,OMAPAbsent=True,PEExportAnchors=anchored,
                  recordCount=record_count,recordKinds={hex(k):v for k,v in types.items()},
                  PDBBytesRead=pdb.reads,frames=frames,
                  limitation='Nearest public record, no function extent/inline chain; aliases retained. Independent interpretation, not normal-debugger acceptance.')
except Exception as error:
    result['error']=str(error); result['errorType']=type(error).__name__
finally:
    if 'pdb' in locals(): pdb.file.close()
    result['elapsedSeconds']=time.monotonic()-started
    result['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with out.open('x',encoding='utf8') as f: f.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='frames'}),flush=True)
    if 'frames' in result: print(json.dumps({'mainThread':[r for r in result['frames'] if r['thread']==0]}),flush=True)
if result['status']=='failed': raise SystemExit(1)
