import datetime,hashlib,json,pathlib,re,subprocess,zipfile
q=pathlib.Path(__file__).resolve().parent
repo=q.parents[2].parent/'tflite-explorer-native-validation'
load=lambda n:json.loads((q/n).read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='ecddde7b04ac43341712efbc51c733d3f3902fea'
pair=load('cloud-metric-paired-review-v2.json');scan=load('chrome-public-symbols.json');analysis=load('cloud-metric-source-analysis.json')
assert pair['status']=='two-predeclared-controls-completed-and-reviewed'
assert pair['controls'][0]['status']=='failed' and pair['controls'][1]['status']=='normal-native-exit'
assert pair['actualDefaultFailureStack']['mainTaskTrackerShutdown'] and pair['actualDefaultFailureStack']['cloudMetricInsideWindowsCloudFileQuery']
assert scan['PESectionsEqual'] and scan['OMAPAbsent'] and len(scan['PEExportAnchors'])==5
members={};records=[];seen={}
def add(p,name):
    assert p.is_file() and p.stat().st_size<2*1024**2
    b=p.read_bytes();digest=sha(b)
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,}|[?&](?:sig|X-Amz-Signature|Signature)=)',b),name
    target=seen.get(digest)
    if target is None:assert name not in members;members[name]=b;seen[digest]=target=name
    records.append({'original':name,'archivedAs':target,'bytes':len(b),'sha256':digest,'modified':False})
for name in ['public-symbol-scan-plan.json','scan-chrome-public-symbols.py','chrome-public-symbols.json',
             'chrome-public-key-function-ranges.json','verify-key-function-ranges.py',
             'chrome-symbol-key.json','cloud-metric-source-analysis.json','cloud-metric-control-plan.json',
             'prepare-cloud-metric-controls.py','cloud-metric-control-preparation.json',
             'direct-cloud-metric-control.mjs','run-cloud-metric-control.py','direct-cdp-close.mjs',
             'cleanup-direct-owned.py','owned-native-stack.py','review-cloud-metric-controls.py',
             'cloud-metric-paired-review.json','cloud-metric-paired-review-v2.json',
             'archive-cloud-metric-evidence.py']:
    add(q/name,'qa/'+name)
for name in ['task_tracker.cc','cloud_synced_folder_checker.cc','chrome_browser_main_extra_parts_metrics.cc','cloud_synced_folder_checker.h','LICENSE']:
    add(q/('chromium-156-'+name+'.json'),'upstream/chromium-156-'+name+'.json')
for mode in ['default','disabled']:
    for suffix in ['.json','.log','-status.json','-cleanup.json']:
        name='cloud-metric-'+mode+suffix;add(q/name,'qa/'+name)
add(q/'cloud-metric-default-native-stack.json','qa/cloud-metric-default-native-stack.json')
for name in ['chrome-physical-stack-1-native-stack.json','chrome-physical-stack-1-stack-summary.json','chrome-physical-stack-1-review.json']:
    add(q/name,'previous-physical/'+name)
add(q/'chrome-symbols-156.0.8078.76/pdb-identity-verification.json','symbol-metadata/pdb-identity-verification.json')
for name in ['authenticode.json','extracted-manifest.json','interfaces.json']:
    add(q/'dbgeng-20260319'/name,'debugger-metadata/'+name)
original=q.parents[2]
for name in ['LICENSE','test/browser/windows-process-memory.mjs','test/browser/windows-process-memory.py','scripts/lib/release-artifact.mjs']:
    add(original/name,'driver-source/'+name)
readme='''# Chrome startup cloud-folder metric shutdown evidence

Public application remains v1.3.0 / build44782d0412ebc0b8; no app, deployment,
canonical browser flag, acceptance threshold or fixed Release was changed.

An independent bounded public-symbol scan read715MB of the already-verified local
Chrome PDB in43.47s. DBI age / GUID, exact stock-PE section bytes, absent OMAP and
five real exported function RVAs bind its interpretation. Four key function names
were additionally checked against the stock DLL runtime-function table: their
public starts equal function starts and saved return addresses lie inside extents.
Nearest public names elsewhere can be wrong, especially large offsets / private
or folded functions. No normal DbgHelp exact-match acceptance is claimed.

The physical failure main is in TaskTracker::CompleteShutdown / WaitableEvent;
a running COM STA worker is in EvaluateOneDriveSyncStatus / Windows directory IO.
Pinned156.0.8078.76 startup metrics source explains the call and why an already
running SKIP_ON_SHUTDOWN task can block shutdown. The feature gates telemetry,
not a model interpreter, model worker or security policy.

Exactly one additional empty-page pair was predeclared and run sequentially.
Default: failed original10sclose, captured same main and EvaluateOneDriveSyncStatus
function ranges, this time inside Windows Cloud Files CfRetrieveProperties /
ZwFsControlFile. Only-after-failure forced cleanup is not normal exit.
Diagnostic feature opt-out: normal exit191ms, eight admitted identities exited,
no forced cleanup. Existing disabled features and security settings were retained.
Both cases preserve original25sidle and10sclose. These are diagnostic controls,
never a replacement full-model gate or proof every historical failure is identical.
The precise Windows/provider defect remains outside the website and unproven.
One pair supports this local mechanism, not a permanent cure or universal guarantee.

No OneDrive settings, user profiles, browser globals, sandbox or antivirus changes.
No company models or personal contents. Only public synthetic blank pages; raw
stack/module names, plans, parser/controller/readers and source metadata are saved.
Original physical report/diagnostic controls and already-published failures remain.
The large PDB, compressed downloads and debugger binaries stay local. Upstream
source metadata retains its license. Do not automatically execute archived drivers.

manifest.json binds every unchanged original and deduplicated member.
'''
members['README.md']=readme.encode()
manifest={'format':'model-lens-cloud-metric-original-evidence','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'records':records,'evidenceModified':False,'readmeSHA256':sha(members['README.md']),
          'omittedLocalOnly':['PDB and compressed/partial downloads','debugger binaries','large physical models and exports']}
members['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'docs/results/windows-cloud-metric-evidence.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(members.items()):z.writestr(n,b)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for row in records:assert sha(z.read(row['archivedAs']))==row['sha256']
receipt={'schemaVersion':1,'format':'model-lens-cloud-metric-mechanism-delivery',
         'status':'local-Chrome-cloud-folder-telemetry-shutdown-mechanism-identified',
         'createdAt':manifest['createdAt'],'pair':pair,'sourceAnalysis':analysis,
         'symbolInterpretation':{'method':'bounded CodeView public scan plus exact stock-PE section/export/function-range checks',
                                 'PDBBytesRead':scan['PDBBytesRead'],'elapsedSeconds':scan['elapsedSeconds'],
                                 'normalDebuggerExactMatchProven':False,'PEExportAnchors':scan['PEExportAnchors']},
         'archive':{'file':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),
                    'members':len(members),'originalRecords':len(records),'manifestSHA256':sha(members['manifest.json']),
                    'crc':'passed','allRecordedSHA256':'passed','evidenceModified':False},
         'rootCauseFixed':False,'canonicalWindowsChromeAcceptance':'still failed under original default settings',
         'applicationChanged':False,'canonicalAcceptanceChanged':False,'redeployed':False,'goalComplete':False}
output=repo/'docs/results/windows-cloud-metric.json';assert not output.exists()
output.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':receipt['status'],'archive':receipt['archive']}))
