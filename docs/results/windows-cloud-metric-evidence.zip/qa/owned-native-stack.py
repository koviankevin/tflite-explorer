"""Task-only, bounded noninvasive stack names for an owned synthetic process.

No dumps, raw memory/stack bytes, command execution, global settings or privilege
changes. Noninvasive attach briefly suspends target threads; always detach before
returning. Browser use is permitted only AFTER original failure is persisted.
"""
import ctypes as c, datetime, hashlib, json, os, pathlib, re, struct, subprocess, sys, tempfile, time
from ctypes import wintypes as w
q=pathlib.Path(__file__).resolve().parent;d=q/'dbgeng-20260319'
native=q.parents[2]/'test/browser/windows-process-memory.py'
scope={'__name__':'owned_stack'}
exec(compile(native.read_text('utf8').split('observer=Observer()')[0],str(native),'exec'),scope)
k,BASIC,query=scope['k'],scope['BASIC'],scope['native']
sha=lambda b:hashlib.sha256(b).hexdigest()

def capture(row,parent,kind):
    assert c.sizeof(c.c_void_p)==8 and row['parent']==parent and kind in ['self-test','failed-synthetic-browser']
    if kind=='failed-synthetic-browser':assert parent==os.getppid() and row['name']=='chrome.exe'
    else:assert parent==os.getpid() and row['name']==pathlib.Path(sys.executable).name.lower()
    signatures=json.loads((d/'authenticode.json').read_text(encoding='utf-8-sig'))
    assert len(signatures)==5 and all(r['status']=='Valid' and 'O=Microsoft Corporation' in r['subject'] for r in signatures)
    manifest=json.loads((d/'extracted-manifest.json').read_bytes())
    for f in manifest['files']:
        assert sha((d/'extracted'/f['path']).read_bytes())==f['sha256']
    interfaces=json.loads((d/'interfaces.json').read_bytes())
    expected={'IDebugClient':{'AttachProcess':12,'DetachProcesses':25,'EndSession':26,'SetOutputCallbacks':34,'SetOutputMask':36},
              'IDebugControl':{'SetEngineOptions':56,'Execute':66,'WaitForEvent':93},
              'IDebugSymbols':{'SetSymbolOptions':6,'SetSymbolPath':41},'IDebugOutputCallbacks':{'Output':3}}
    for name,methods in expected.items():assert interfaces[name]['vtable']==methods
    handle=k.OpenProcess(0x1000|0x100000,False,row['pid'])
    if not handle:raise c.WinError(c.get_last_error())
    client=c.c_void_p();control=c.c_void_p();symbols=c.c_void_p();attached=False
    outputs=[];output_bytes=0;overflow=False;events=[];dir_handle=None
    private_session=pathlib.Path(tempfile.mkdtemp(prefix='dbgeng-session-',dir=q))
    for key in ['LOCALAPPDATA','APPDATA']:
        target=private_session/key;target.mkdir();os.environ[key]=str(target)
    os.environ['_NT_SYMBOL_PATH']='';os.environ['_NT_ALTERNATE_SYMBOL_PATH']=''
    os.environ['_NT_DEBUGGER_EXTENSION_PATH']=str(private_session)
    os.environ['DBGENG_NO_DEBUG_PRIVILEGE']='1'
    result={'format':'model-lens-owned-native-stack','status':'failed','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'identity':row,'kind':kind,'packageSHA256':manifest['packageSHA256'],'events':events,'isolatedDebuggerSession':str(private_session),
            'scope':'Bounded noninvasive thread stack/module names only; no raw bytes, dump, personal profile, model, shell/execution commands or symbol network.'}
    def event(name,**extra):
        events.append({'kind':name,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra})
        print('[DEBUG-owned-stack] '+name,flush=True)
    def verify_handle():
        assert k.WaitForSingleObject(handle,0)==258,'Owned target exited before observation'
        basic=BASIC();length=w.ULONG();assert query(handle,0,c.byref(basic),c.sizeof(basic),c.byref(length))>=0 and length.value==c.sizeof(basic)
        assert basic.pid==row['pid'] and basic.parent==parent
        times=[w.FILETIME() for _ in range(4)];assert k.GetProcessTimes(handle,*[c.byref(t) for t in times])
        assert str((times[0].dwHighDateTime<<32)|times[0].dwLowDateTime)==row['startTicks']
    HRESULT=c.c_long;ULONG=w.ULONG;VOID=c.c_void_p
    class GUID(c.Structure):_fields_=[('raw',c.c_ubyte*16)]
    def guid(name):
        nums=[int(x,16) for x in re.findall(r'0x[0-9a-fA-F]+',interfaces[name]['IID'])]
        assert len(nums)==11
        return GUID.from_buffer_copy(struct.pack('<IHH8B',*nums))
    def method(ptr,index,restype,*types):
        table=c.cast(ptr,c.POINTER(c.POINTER(VOID))).contents
        return c.WINFUNCTYPE(restype,VOID,*types)(table[index])
    def call(ptr,name,method_name,*typed):
        types,args=typed[::2],typed[1::2]
        hr=method(ptr,expected[name][method_name],HRESULT,*types)(ptr,*args)
        if hr!=0:raise RuntimeError(method_name+' HRESULT '+hex(hr&0xffffffff))
    def qi(ptr,name):
        target=c.c_void_p();iid=guid(name)
        hr=method(ptr,0,HRESULT,c.POINTER(GUID),c.POINTER(VOID))(ptr,c.byref(iid),c.byref(target))
        if hr!=0:raise RuntimeError('QueryInterface '+name+' '+hex(hr&0xffffffff))
        return target
    QueryCB=c.WINFUNCTYPE(HRESULT,VOID,c.POINTER(GUID),c.POINTER(VOID))
    RefCB=c.WINFUNCTYPE(ULONG,VOID)
    OutputCB=c.WINFUNCTYPE(HRESULT,VOID,ULONG,c.c_char_p)
    class Callback(c.Structure):_fields_=[('vt',c.POINTER(VOID))]
    output_guid=bytes(guid('IDebugOutputCallbacks').raw);iunknown=bytes.fromhex('0000000000000000c000000000000046')
    @QueryCB
    def query_callback(this,iid,dest):
        if bytes(iid.contents.raw) in [output_guid,iunknown]:dest[0]=this;return 0
        dest[0]=None;return -2147467262
    @RefCB
    def add_ref(this):return 2
    @RefCB
    def release(this):return 1
    @OutputCB
    def output(this,mask,text):
        nonlocal output_bytes,overflow
        data=text or b'';output_bytes+=len(data)
        if output_bytes>1024**2:overflow=True;return -2147024882
        outputs.append(data.decode('utf8',errors='replace'));return 0
    vt=(VOID*4)(*[c.cast(fn,VOID).value for fn in [query_callback,add_ref,release,output]])
    callback=Callback(c.cast(vt,c.POINTER(VOID)))
    try:
        verify_handle();event('native-identity-verified')
        directory=d/'extracted/content/amd64';dir_handle=os.add_dll_directory(str(directory))
        dll=c.WinDLL(str(directory/'dbgeng.dll'),winmode=0x100|0x1000)
        dll.DebugCreate.argtypes=[c.POINTER(GUID),c.POINTER(VOID)];dll.DebugCreate.restype=HRESULT
        iid=guid('IDebugClient');hr=dll.DebugCreate(c.byref(iid),c.byref(client))
        if hr!=0:raise RuntimeError('DebugCreate '+hex(hr&0xffffffff))
        control=qi(client,'IDebugControl');symbols=qi(client,'IDebugSymbols')
        call(client,'IDebugClient','SetOutputCallbacks',VOID,c.cast(c.byref(callback),VOID))
        call(client,'IDebugClient','SetOutputMask',ULONG,0x207)
        call(control,'IDebugControl','SetEngineOptions',ULONG,0x8|0x1000|0x10000|0x80000)
        call(symbols,'IDebugSymbols','SetSymbolOptions',ULONG,0x4|0x200|0x1000|0x80000|0x2000000)
        call(symbols,'IDebugSymbols','SetSymbolPath',c.c_char_p,b'')
        verify_handle();event('noninvasive-attach-start')
        call(client,'IDebugClient','AttachProcess',c.c_ulonglong,0,ULONG,row['pid'],ULONG,1);attached=True
        call(control,'IDebugControl','WaitForEvent',ULONG,0,ULONG,5000)
        verify_handle();event('noninvasive-ready')
        # Fixed literal whitelist: no user commands, extensions, shell or resume.
        commands=b'~* k 16; lm'
        call(control,'IDebugControl','Execute',ULONG,0,c.c_char_p,commands,ULONG,4)
        assert not overflow
        result['commands']=commands.decode();result['output']=''.join(outputs)
        assert re.search(r'\b(?:ntdll|KERNELBASE|kernel32|python3\d*)[!+]',result['output'],re.I),'No real native stack frames captured'
        event('bounded-stack-captured',bytes=output_bytes);result['status']='captured-owned-native-stacks'
    except Exception as e:result['error']=str(e)
    finally:
        if attached:
            try:call(client,'IDebugClient','DetachProcesses');event('detached');result['detached']=True
            except Exception as e:result['detachError']=str(e);result['status']='failed'
        if client.value:
            try:call(client,'IDebugClient','SetOutputCallbacks',VOID,None)
            except Exception as e:result['callbackCleanupError']=str(e);result['status']='failed'
        for ptr in [symbols,control,client]:
            if ptr.value:method(ptr,2,ULONG)(ptr)
        if dir_handle:dir_handle.close()
        k.CloseHandle(handle)
        result['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    return result

if __name__=='__main__':
    assert sys.platform=='win32' and len(sys.argv)==3 and sys.argv[1] in ['--self-test','--failed-browser','--validate-request']
    out=pathlib.Path(sys.argv[2]);assert not out.exists()
    if sys.argv[1]=='--self-test':
        p=subprocess.Popen([sys.executable,'-u','-c','import sys; print("ready",flush=True); input(); print("resumed",flush=True)'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        assert p.stdout.readline().strip()=='ready'
        row=scope['inspect'](scope['snapshot']()[p.pid]);result=capture(row,os.getpid(),'self-test')
        try:
            stdout,stderr=p.communicate('ping\n',timeout=8)
            result.update(targetResumed=stdout.strip()=='resumed',targetExitCode=p.returncode,targetStderr=stderr)
            assert result['targetResumed'] and p.returncode==0
        except Exception as e:
            result['selfTestError']=str(e);result['status']='failed'
            if p.poll() is None:p.terminate();p.wait(timeout=5);result['forcedSelfTestCleanup']=True
    else:
        raw=sys.stdin.buffer.read(65537);assert len(raw)<=65536
        request=json.loads(raw.decode('utf8'))
        checkpoint=pathlib.Path(request['failureCheckpoint']);saved=json.loads(checkpoint.read_bytes())
        assert saved['status']=='failed' and request['row'] in saved['failureNativeObservation']['rows']
        if sys.argv[1]=='--validate-request':
            result={'status':'UTF8-stack-request-validated-no-attach','failureCheckpoint':str(checkpoint),'row':request['row'],'noAttach':True}
        else:result=capture(request['row'],os.getppid(),'failed-synthetic-browser')
        result['failureCheckpointSHA256']=sha(checkpoint.read_bytes())
    with out.open('x',encoding='utf8') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['output','identity','events']}))
    sys.exit(0 if result['status'] in ['captured-owned-native-stacks','UTF8-stack-request-validated-no-attach'] else 1)
