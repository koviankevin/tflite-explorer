import hashlib,json,pathlib
q=pathlib.Path(__file__).resolve().parent
base=(q/'direct-cdp-close.mjs').read_text('utf8')
old="    report.launch={executable:exe,args,profile,baselineLogSHA256:createHash('sha256').update(raw).digest('hex'),onlyArgumentReplacement:'--user-data-dir'};"
new="""    const mode=process.env.MODEL_LENS_CLOUD_CONTROL;assert.ok(['default','disabled'].includes(mode));
    const featureArgs=args.filter(a=>a.startsWith('--disable-features='));assert.equal(featureArgs.length,1);
    assert.ok(!featureArgs[0].includes('CloudSyncedFolderChecker'));
    if(mode==='disabled')args[args.indexOf(featureArgs[0])]=featureArgs[0]+',CloudSyncedFolderChecker';
    report.cloudControl={mode,diagnosticOnly:true,canonicalAcceptanceChanged:false};
    report.launch={executable:exe,args,profile,baselineLogSHA256:createHash('sha256').update(raw).digest('hex'),onlyArgumentReplacement:mode==='default'?'--user-data-dir':'--user-data-dir and append cloud-folder telemetry feature to existing disable list'};"""
assert base.count(old)==1
overlay=base.replace(old,new)
marker="    const cleanup={phase:'after-original-result-persisted'"
hook="""    if(report.status==='failed'&&report.failureNativeObservation?.rows?.length){
        const row=report.failureNativeObservation.rows.find(r=>r.pid===report.root.pid&&r.startTicks===report.root.startTicks);
        if(row){try{
            const stackOut=output.replace(/\\.json$/,'-native-stack.json');
            const stack=execFileSync(python,[path.join(q,'owned-native-stack.py'),'--failed-browser',stackOut],{input:Buffer.from(JSON.stringify({failureCheckpoint:output,row}), 'utf8'),encoding:'utf8',windowsHide:true,timeout:15000,maxBuffer:131072});
            console.log('[DEBUG-cloud-control] '+stack);
        }catch(error){console.log('[DEBUG-cloud-control] post-failure stack failed: '+error.message);}}
    }
"""
assert overlay.count(marker)==1
overlay=overlay.replace(marker,hook+marker)
dest=q/'direct-cloud-metric-control.mjs';assert not dest.exists();dest.write_text(overlay,encoding='utf8')
original=(q/'run-direct-pipe-1.py').read_text('utf8')
controller=original.replace("out=q/'direct-pipe-1.json';log=q/'direct-pipe-1.log';status=q/'direct-pipe-1-status.json'", "mode=sys.argv[1];assert mode in ['default','disabled'];stem='cloud-metric-'+mode\nout=q/(stem+'.json');log=q/(stem+'.log');status=q/(stem+'-status.json')")
controller=controller.replace("q/'direct-pipe-1-cleanup.json'", "q/(stem+'-cleanup.json')")
controller=controller.replace("'DIRECT_CLOSE_REPORT':str(out)","'DIRECT_CLOSE_REPORT':str(out),'MODEL_LENS_CLOUD_CONTROL':mode")
controller=controller.replace("str(q/'direct-cdp-close.mjs')","str(q/'direct-cloud-metric-control.mjs')")
controller=controller.replace("'sdk1641-2.json']", "'sdk1641-2.json','chrome-physical-stack-1.json']")
assert controller!=original and 'mode=sys.argv[1]' in controller
dest=q/'run-cloud-metric-control.py';assert not dest.exists();dest.write_text(controller,encoding='utf8')
receipt={'status':'paired-control-overlay-prepared','baseSHA256':hashlib.sha256(base.encode()).hexdigest(),
         'overlaySHA256':hashlib.sha256(overlay.encode()).hexdigest(),
         'changes':['Diagnostic mode and one non-security telemetry feature only','Existing post-failure collector after original report; original close verdict unchanged'],
         'canonicalAcceptanceChanged':False}
(q/'cloud-metric-control-preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
