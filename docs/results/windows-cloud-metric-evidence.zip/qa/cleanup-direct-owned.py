"""Isolated diagnostic cleanup only, after result persistence. Never an exit gate."""
import ctypes as c, json, os, pathlib, sys
q=pathlib.Path(__file__).resolve().parent
native=q.parents[2]/'test/browser/windows-process-memory.py'
scope={'__name__':'owned_cleanup'}
exec(compile(native.read_text('utf8').split('observer=Observer()')[0],str(native),'exec'),scope)
k,w,BASIC=scope['k'],scope['w'],scope['BASIC']
query=scope['native'];snapshot=scope['snapshot'];inspect=scope['inspect']
request=json.load(sys.stdin);root=request['root'];rows=request['rows'];admitted=request['admitted']
assert request['parentPid']==os.getppid() and root['parent']==os.getppid() and root['name']=='chrome.exe'
assert len(rows)<=1024 and len(admitted)<=1024
known={(r['pid'],r['startTicks']):r for r in admitted}
assert (root['pid'],root['startTicks']) in known
table=snapshot();current=table.get(root['pid']);rootLive=inspect({**current,'startTicks':root['startTicks']}) if current else None
if rootLive:assert rootLive['parent']==os.getppid() and rootLive['name']=='chrome.exe'
def owned(row):
    seen=set();current=row
    while current['pid']!=root['pid']:
        assert current['pid'] not in seen;seen.add(current['pid'])
        candidates=[p for p in admitted if p['pid']==current['parent'] and int(p['startTicks'])<=int(current['startTicks'])]
        assert len(candidates)==1
        current=candidates[0]
    assert current['startTicks']==root['startTicks']
k.TerminateProcess.argtypes=[w.HANDLE,w.UINT];k.TerminateProcess.restype=w.BOOL
results=[]
for row in sorted(rows,key=lambda r:r['pid']==root['pid']):
    assert (row['pid'],row['startTicks']) in known and row['name']=='chrome.exe';owned(row)
    handle=k.OpenProcess(0x1000|0x100000|0x1,False,row['pid'])
    if not handle:
        if c.get_last_error() in [87,1168]:results.append({'pid':row['pid'],'status':'already-gone'});continue
        raise c.WinError(c.get_last_error())
    try:
        if k.WaitForSingleObject(handle,0)==0:results.append({'pid':row['pid'],'status':'already-exited'});continue
        basic=BASIC();length=w.ULONG()
        assert query(handle,0,c.byref(basic),c.sizeof(basic),c.byref(length))>=0 and length.value==c.sizeof(basic)
        assert basic.pid==row['pid'] and basic.parent==row['parent']
        times=[w.FILETIME() for _ in range(4)]
        assert k.GetProcessTimes(handle,*[c.byref(t) for t in times])
        assert str((times[0].dwHighDateTime<<32)|times[0].dwLowDateTime)==row['startTicks']
        # Identity checks and termination share this handle, preventing PID reuse.
        if not k.TerminateProcess(handle,1):raise c.WinError(c.get_last_error())
        assert k.WaitForSingleObject(handle,5000)==0
        results.append({'pid':row['pid'],'startTicks':row['startTicks'],'status':'forced-owned-cleanup'})
    finally:k.CloseHandle(handle)
print(json.dumps({'scope':'post-result forced cleanup only; never normal native exit','results':results}))
