import bisect,hashlib,json,pathlib,struct
q=pathlib.Path(__file__).resolve().parent
load=lambda n:json.loads((q/n).read_bytes())
key=load('chrome-symbol-key.json');symbols=load('chrome-public-symbols.json')
assert symbols['status']=='bounded-public-records-mapped-with-PE-export-anchors'
targets=[r for r in symbols['frames'] if r['thread']==0 and r['frame'] in [2,3,4] or r['thread']==26 and r['frame']==15]
assert len(targets)==4
with pathlib.Path(key['binary']).open('rb') as f:
    h=hashlib.sha256()
    for chunk in iter(lambda:f.read(1024**2),b''):h.update(chunk)
    assert h.hexdigest()==key['binarySHA256']
    f.seek(0x3c);pe=struct.unpack('<I',f.read(4))[0];f.seek(pe);head=f.read(24)
    n=struct.unpack_from('<H',head,6)[0];osize=struct.unpack_from('<H',head,20)[0]
    optional=f.read(osize);sections=f.read(n*40)
    rva,length=struct.unpack_from('<II',optional,112+3*8)
    assert length%12==0 and length<16*1024**2
    for index in range(n):
        vs,va,rs,rp=struct.unpack_from('<4I',sections,index*40+8)
        if va<=rva and rva+length<=va+rs:
            f.seek(rp+rva-va);data=f.read(length);assert len(data)==length;break
    else:raise AssertionError('Missing PE runtime function table')
functions=list(struct.iter_unpack('<III',data));starts=[v[0] for v in functions]
assert starts==sorted(starts)
rows=[]
for r in targets:
    index=bisect.bisect_right(starts,r['rva'])-1
    start,end,unwind=functions[index]
    assert start<=r['rva']<end and start==r['symbolRVA']
    rows.append({'thread':r['thread'],'frame':r['frame'],'name':r['publicAliases'],
                 'publicRVA':r['symbolRVA'],'actualFunctionStart':start,'actualFunctionEnd':end,
                 'publicStartEqualsRuntimeFunctionStart':True,'insideFunction':True})
expected={'status':'stock-PE-exception-ranges-reviewed','rows':rows,'PEIdentity':key['binarySHA256']}
assert expected==load('chrome-public-key-function-ranges.json')
print(json.dumps({'status':'four-key-public-names-and-stock-PE-function-extents-verified',
                  'normalDebuggerMatchClaimed':False,'browserLaunched':False}))
