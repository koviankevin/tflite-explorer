# Chrome startup cloud-folder metric shutdown evidence

Public application remains v1.3.0 / build44782d0412ebc0b8; no app, deployment,
canonical browser flag, acceptance threshold or fixed Release was changed.

An independent bounded public-symbol scan read715MB of the already-verified local
Chrome PDB in43.47s. DBI age / GUID, exact stock-PE section bytes, absent OMAP and
five real exported function RVAs bind its interpretation. Four key function names
were additionally checked against the stock DLL runtime-function table: their
public starts equal function starts and saved return addresses lie inside extents.
Nearest public names elsewhere can be wrong, especially large offsets / private
or folded functions. No normal DbgHelp exact-match acceptance is claimed.

The physical failure main is in TaskTracker::CompleteShutdown / WaitableEvent;
a running COM STA worker is in EvaluateOneDriveSyncStatus / Windows directory IO.
Pinned156.0.8078.76 startup metrics source explains the call and why an already
running SKIP_ON_SHUTDOWN task can block shutdown. The feature gates telemetry,
not a model interpreter, model worker or security policy.

Exactly one additional empty-page pair was predeclared and run sequentially.
Default: failed original10sclose, captured same main and EvaluateOneDriveSyncStatus
function ranges, this time inside Windows Cloud Files CfRetrieveProperties /
ZwFsControlFile. Only-after-failure forced cleanup is not normal exit.
Diagnostic feature opt-out: normal exit191ms, eight admitted identities exited,
no forced cleanup. Existing disabled features and security settings were retained.
Both cases preserve original25sidle and10sclose. These are diagnostic controls,
never a replacement full-model gate or proof every historical failure is identical.
The precise Windows/provider defect remains outside the website and unproven.
One pair supports this local mechanism, not a permanent cure or universal guarantee.

No OneDrive settings, user profiles, browser globals, sandbox or antivirus changes.
No company models or personal contents. Only public synthetic blank pages; raw
stack/module names, plans, parser/controller/readers and source metadata are saved.
Original physical report/diagnostic controls and already-published failures remain.
The large PDB, compressed downloads and debugger binaries stay local. Upstream
source metadata retains its license. Do not automatically execute archived drivers.

manifest.json binds every unchanged original and deduplicated member.
