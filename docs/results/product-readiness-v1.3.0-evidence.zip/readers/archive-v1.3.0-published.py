import datetime,hashlib,json,os,pathlib,subprocess,zipfile
q=pathlib.Path(__file__).resolve().parent;repo=q.parents[2].with_name('tflite-explorer-transpose');dest=repo/'docs/results'
load=lambda n:json.loads((q/n).read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
verified=load('v1.3.0-published-review.json');assert verified['status']=='passed' and verified['goalComplete']==False
assert verified['source']=='7debc69df1a1c91e8ed3928a8a4932a493324180' and verified['checks']==35 and verified['siteFiles']==1465
http=load('v1.3.0-current-http-review.json');assert http['status']=='current-public-identity-matched';roots=[r for r in http['checks'] if r['path']=='index.html'];assert len(roots)==1 and roots[0]['sha256']==verified['rootEntrySHA256'];root=roots[0]
archive=dest/'product-readiness-v1.3.0-evidence.zip';receipt=dest/'product-readiness-v1.3.0-published.json';assert not archive.exists() and not receipt.exists()
files={}
def add(name,p):
 b=p.read_bytes();assert 0<len(b)<=8*1024**2 and name not in files;files[name]=b
for name in ['v1.3.0-published-review.json','v1.3.0-prepared-review.json','v1.3.0-prepare-run.json','v1.3.0-prepare-jobs.json','v1.3.0-prepare-artifacts.json','v1.3.0-prepared-output.json','v1.3.0-publish-run.json','v1.3.0-publish-jobs.json','v1.3.0-publish-artifacts.json','v1.3.0-release.json','v1.3.0-latest-release.json','v1.3.0-tag.json','v1.3.0-deployment-map.json','v1.3.0-release-assets-review.json','v1.3.0-current-http-review.json','v1.3.0-formal-checks-review.json','v1.3.0-live-index.json']:
 add('metadata/'+name,q/name)
for name in ['live-release-verification.zip','published-release-verification.zip','pages-live-report.json','production-smoke.json','production-smoke.png','pages-release-report.json']:
 add('original-live-reports/'+name,q/'v1.3.0-published-artifacts'/name)
for name in ['release-manifest.json','release-gates.json','model-lens-public-1.3.0-44782d0412ebc0b8.zip.sha256']:
 add('actual-release-downloads/'+name,q/'v1.3.0-release-downloads'/name)
for name in ['review-v1.3.0-published.mjs','review-v1.3.0-prepared-corrected.mjs','extract-v1.3.0-prepared-corrected.py','archive-v1.3.0-published.py','download-v1.3.0-published.py','download-v1.3.0-release-assets.py','read-v1.3.0-deployment.py','check-v1.3.0-current-http.py']:
 add('readers/'+name,q/name)
for name in ['LICENSE','vendor/netron/LICENSE','scripts/lib/live-site.mjs','scripts/lib/deployment-history.mjs','scripts/lib/pages-release.mjs','test/browser/runtime-lifecycle-policy.mjs','src/tflite-constant-checks.js','src/tflite-semantic-checks.js','test/tflite-transpose-runtime.test.mjs','src/tflite-operand-checks.js','src/tflite-runtime-report.js','src/export-report-ui.js','test/tflite-operand-validation.test.mjs','test/tflite-operand-runtime.test.mjs','test/browser/operator-validation-flow.mjs']:
 b=subprocess.check_output(['git','show',verified['source']+':'+name],cwd=repo);files['published-source/'+name]=b
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,b in sorted(files.items()):z.writestr(name,b)
members=[]
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for name,b in sorted(files.items()):assert z.read(name)==b;members.append(dict(path=name,bytes=len(b),sha256=sha(b)))
raw=archive.read_bytes()
result=dict(format='model-lens-product-readiness-v1.3.0-delivery',version=1,status='published-verified',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),published=verified,independentCurrentRoot=root,
 archive=dict(path=archive.name,bytes=len(raw),sha256=sha(raw),members=members),
 fullZIP=dict(retainedOnReleaseAndLocally=True,sourceURL='https://github.com/koviankevin/tflite-explorer/releases/download/v1.3.0/model-lens-public-1.3.0-44782d0412ebc0b8.zip',bytes=41280015,sha256='422c245dfd6736a37af9e4b30d9ee871a7265ac4a50f93d176fbf18fc9b31a60',notDuplicatedInEvidenceArchive=True),
 previousEvidence=['operator-validation-candidate.json','operator-report-prefix.json','operator-dtype-validation.json','operator-validation-main.json','transpose-permutation.json','transpose-main-verification.json','windows-v1.2-native.json','product-readiness-v1.2-published.json'],
 remaining=['The publishedv1.2.0 nativeChrome/Edgefull8cyclespassed;later candidate/emptyChromeoriginal10sclosefailures remain unresolved. No rootcausefixclaimed orreplacementofWindowsbyLinux.','Unknown custom references stay conservative; arbitrary kernel/dialect/packing semantics and external MLIR resource selection remain outside verified support.','Historical startup timeout root cause is not proved fixed; full human/OS power-loss/arbitrary migration coverage is not claimed.'],
 scope='Incremental public release; full product goal active. No Sites/GHStudio sync, mobile,Firefox/WebKit,company data or new two-hour soak. No successful deployment rerun, GC/RSS subtraction/timer/security changes.')
with receipt.open('x',encoding='utf8') as f:f.write(json.dumps(result,indent=2)+'\n');f.flush();os.fsync(f.fileno())
review=dict(status='published-evidence-archive-verified',archive=archive.name,bytes=len(raw),members=len(members),sha256=sha(raw),receiptSHA256=sha(receipt.read_bytes()),source=verified['source'])
with (q/'v1.3.0-published-archive-review.json').open('x',encoding='utf8') as f:f.write(json.dumps(review,indent=2)+'\n');f.flush();os.fsync(f.fileno())
print(json.dumps(review),flush=True)
