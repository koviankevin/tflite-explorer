import datetime,hashlib,json,os,pathlib,sys,urllib.error,urllib.parse,urllib.request
q=pathlib.Path(__file__).resolve().parent;prepared=json.loads((q/'v1.3.0-prepared-review.json').read_bytes());release=json.loads((q/'v1.3.0-release.json').read_bytes());run=json.loads((q/'v1.3.0-publish-run.json').read_bytes())
assert run['status']=='completed' and run['conclusion']=='success' and run['id']==41216245433
assert isinstance(release['id'],int) and release['id']>0 and release['tag_name']=='v1.3.0' and release['target_commitish']==prepared['source'] and not release['draft'] and not release['prerelease']
expected={a['name']:a for a in prepared['assets']};assert len(expected)==len(release['assets'])==4 and set(expected)=={a['name'] for a in release['assets']}
out=q/'v1.3.0-release-downloads';out.mkdir(exist_ok=True);assert out.resolve()==out.absolute() and not out.is_symlink()
events=q/'v1.3.0-release-asset-events.jsonl';results=[]
def event(data):
    with events.open('a',encoding='utf-8') as f:json.dump({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),**data},f);f.write('\n');f.flush();os.fsync(f.fileno())
def file_sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for remote in release['assets']:
    name=remote['name'];e=expected[name];assert remote['state']=='uploaded' and remote['size']==e['bytes'] and remote['digest']=='sha256:'+e['sha256'] and remote['uploader']['login']=='github-actions[bot]'
    assert pathlib.PurePosixPath(name).name==name and '\\' not in name and ':' not in name
    url=remote['browser_download_url'];parsed=urllib.parse.urlparse(url);assert parsed.scheme=='https' and parsed.hostname=='github.com' and urllib.parse.unquote(parsed.path)=='/koviankevin/tflite-explorer/releases/download/v1.3.0/'+name
    p=out/name;partial=out/(name+'.part');assert p.resolve().parent==out.resolve() and partial.resolve().parent==out.resolve()
    if p.exists():
        assert p.stat().st_size==e['bytes'] and file_sha(p)==e['sha256'],'Existing actual download differs;preserve for review'
        results.append({**e,'state':'retained-verified-actual-download'});continue
    assert not partial.exists(),'Partial exists;inspect before retry'
    event({'operation':'download-intent','asset':remote['id'],'name':name,'path':str(p),'partial':str(partial),'expectedBytes':e['bytes'],'expectedSHA256':e['sha256'],'cleanup':'Retain allactualbytes/proof;no deletion authorised'})
    digest=hashlib.sha256();count=0
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ModelLens-Actual-Fixed-Release-Review'}),timeout=30) as response,partial.open('xb') as f:
            assert response.status==200
            while True:
                chunk=response.read(1024**2)
                if not chunk:break
                count+=len(chunk);assert count<=e['bytes'];digest.update(chunk);f.write(chunk)
            f.flush();os.fsync(f.fileno())
        assert count==e['bytes'] and digest.hexdigest()==e['sha256']
        assert not p.exists();os.replace(partial,p)
        event({'operation':'download-verified','asset':remote['id'],'name':name,'bytes':count,'sha256':digest.hexdigest()});results.append({**e,'state':'actual-public-download-verified'})
    except Exception as error:
        event({'operation':'failed-preserve-partial','asset':remote['id'],'name':name,'errorType':type(error).__name__,'bytesReceived':count})
        print(json.dumps({'status':'failed-inspect-retained-partial','name':name,'errorType':type(error).__name__}));sys.exit(1)
result={'status':'four-actual-fixed-release-downloads-match-prepared','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'release':release['id'],'source':prepared['source'],'assets':results,'scope':'ActualpublicGET downloads,notcopiesfromprepared orworkflowdelivery. validateDelivery/ZIP/manifest consistency is independently required.'}
p=q/'v1.3.0-release-assets-review.json'
if not p.exists():
    with p.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(result))
