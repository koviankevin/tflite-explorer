import datetime,json,os,pathlib,subprocess,urllib.request
q=pathlib.Path(__file__).resolve().parent;output=q/'v1.3.0-deployment-map.json';assert not output.exists()
run=json.loads((q/'v1.3.0-publish-run.json').read_bytes());assert run['id']==41216245433 and run['status']=='completed' and run['conclusion']=='success'
auth=subprocess.run([r'H:\mc2llvm\.work\gh\bin\gh.exe','auth','token','--hostname','github.com'],capture_output=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW);assert auth.returncode==0 and auth.stdout.strip(),'Existing credential unavailable'
token=auth.stdout.decode('utf-8').strip();del auth
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):raise RuntimeError('Authenticated redirect refused')
opener=urllib.request.build_opener(NoRedirect());data={};prefix='repos/koviankevin/tflite-explorer/'
def get(route):
    assert route.startswith(prefix)
    request=urllib.request.Request('https://api.github.com/'+route,headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'ModelLens-ReadOnly-Deployment-Review'})
    with opener.open(request,timeout=30) as response:raw=response.read(8*1024**2+1)
    assert len(raw)<=8*1024**2;value=json.loads(raw);data[route]=value;return value
deployments=get(prefix+'deployments?environment=github-pages&per_page=1');assert len(deployments)==1;deployment=deployments[0]
assert deployment['sha']==run['head_sha']=='7debc69df1a1c91e8ed3928a8a4932a493324180' and deployment['environment']=='github-pages'
statuses=get(prefix+'deployments/'+str(deployment['id'])+'/statuses?per_page=100');assert statuses[0]['state']=='success'
import re
match=re.fullmatch(r'https://github.com/koviankevin/tflite-explorer/actions/runs/(\d+)/job/(\d+)',statuses[0]['log_url']);assert match and int(match[1])==run['id']
job=get(prefix+'actions/jobs/'+match[2]);assert job['conclusion']=='success' and job['head_sha']==run['head_sha']
actual=get(prefix+'actions/runs/'+match[1]+'/attempts/'+str(job['run_attempt']));assert actual['status']=='completed' and actual['conclusion']=='success' and actual['id']==run['id']
del token
with output.open('x',encoding='utf-8') as f:json.dump(data,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'status':'read-authoritative-deployment-map','deployment':deployment['id'],'run':run['id'],'job':job['id'],'source':run['head_sha'],'readonly':True}))
