import datetime,hashlib,json,os,pathlib,urllib.parse,urllib.request
q=pathlib.Path(__file__).resolve().parent;prepared=json.loads((q/'v1.2.1-prepared-review.json').read_bytes());snapshot=q/'v1.2.1-prepared-artifacts/snapshot'
site_raw=(snapshot/'site-manifest.json').read_bytes();site=json.loads(site_raw);files={v['path']:v for v in site['files']};base='https://koviankevin.github.io/tflite-explorer/'
assert prepared['status']=='passed-prepared-artifact-review' and site['siteId']==prepared['siteId']
output=q/'v1.2.1-current-http-review.json';index=q/'v1.2.1-live-index.json';assert not output.exists() and not index.exists()
checks=[];live_index=None
for name in ['index.html','site-manifest.json','versions/'+prepared['buildId']+'/release.json']:
    expected=hashlib.sha256(site_raw).hexdigest() if name=='site-manifest.json' else files[name]['sha256']
    expected_bytes=len(site_raw) if name=='site-manifest.json' else files[name]['bytes']
    assert 0<expected_bytes<4*1024**2
    url=base+('' if name=='index.html' else name)
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ModelLens-Public-Identity-Review'}),timeout=30) as response:
        assert response.status==200 and urllib.parse.urlparse(response.geturl()).hostname=='koviankevin.github.io'
        raw=response.read(4*1024**2+1);mime=response.headers.get('Content-Type','')
    digest=hashlib.sha256(raw).hexdigest();assert len(raw)==expected_bytes and digest==expected,(name,len(raw),digest)
    if name.endswith('.json'):assert mime.lower().split(';')[0].strip()=='application/json'
    else:assert mime.lower().split(';')[0].strip()=='text/html'
    if name=='site-manifest.json':
        current=json.loads(raw);assert current==site and current['current']['release']['source']['commit']==prepared['source'];live_index=raw
    checks.append({'path':name,'url':url,'bytes':len(raw),'sha256':digest,'contentType':mime})
assert live_index is not None
with index.open('xb') as f:f.write(live_index);f.flush();os.fsync(f.fileno())
result={'status':'current-public-identity-matched','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':prepared['source'],'build':prepared['buildId'],'siteId':prepared['siteId'],'checks':checks,'scope':'Three fresh public GETs without query;full1457file HTTPS/MIME andbrowser report are independently required from actual official workflow. Not fullrelease ornativecloseproof.'}
with output.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(result))
