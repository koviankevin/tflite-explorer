import base64,datetime,hashlib,io,json,os,pathlib,stat,sys,urllib.request,zipfile
q=pathlib.Path(__file__).resolve().parent;name=sys.argv[1];allowed={'live-release-verification':['pages-live-report.json','production-smoke.json','production-smoke.png'],'published-release-verification':['pages-release-report.json']};assert name in allowed
run=json.loads((q/'v1.2.1-publish-run.json').read_bytes());jobs=json.loads((q/'v1.2.1-publish-jobs.json').read_bytes());meta=json.loads((q/'v1.2.1-publish-artifacts.json').read_bytes())
assert run['id']==41204168493 and run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1
assert run['head_sha']=='2160757222460436129e06d27ba57b7adf9c3ac8' and len(jobs['jobs'])==4 and all(j['conclusion']=='success' and j['status']=='completed' for j in jobs['jobs'])
items=[a for a in meta['artifacts'] if a['name']==name];assert len(items)==1;a=items[0]
assert not a['expired'] and a['workflow_run']['id']==run['id'] and a['workflow_run']['head_sha']==run['head_sha'] and 0<a['size_in_bytes']<=8*1024**2
out=q/'v1.2.1-published-artifacts';out.mkdir(exist_ok=True);assert out.resolve()==out.absolute() and not out.is_symlink()
paths=[out/(name+'.zip')]+[out/p for p in allowed[name]];assert all(not p.exists() for p in paths)
state={'status':'create-intent','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifact':a['id'],'expectedDigest':a['digest'],'outputs':list(map(str,paths)),'credentials':'Transient connector reference not printed/saved','cleanup':'Retain actual providerZIP/reports;no deletion authorised'}
with (q/('v1.2.1-'+name+'-intent.json')).open('x',encoding='utf-8') as f:json.dump(state,f,indent=2);f.flush();os.fsync(f.fileno())
url=base64.b64decode(sys.argv[2]).decode('utf-8');assert url.startswith('https://')
with urllib.request.urlopen(url,timeout=30) as response:raw=response.read(8*1024**2+1)
del url
assert len(raw)==a['size_in_bytes'] and 'sha256:'+hashlib.sha256(raw).hexdigest()==a['digest']
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert sorted(z.namelist())==sorted(allowed[name]) and z.testzip() is None
    for item in z.infolist():assert not item.is_dir() and stat.S_IFMT(item.external_attr>>16) in [0,stat.S_IFREG] and item.file_size<=4*1024**2
    outputs=[(paths[0],raw)]+[(out/p,z.read(p)) for p in allowed[name]]
for p,data in outputs:
    with p.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
print(json.dumps({'status':'verified-provider-digest-crc-paths','artifact':a['id'],'name':name,'bytes':len(raw),'digest':a['digest'],'files':allowed[name]}))
