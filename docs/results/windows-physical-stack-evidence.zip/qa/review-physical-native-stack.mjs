import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {evaluateLifecycle,MODEL_COMPOSITION_LIFECYCLE_POLICY} from 'file:///D:/Users/kovia/OneDrive/%E6%96%87%E4%BB%B6/ChatGPT/Tflite/tflite-explorer-transpose/test/browser/lifecycle-policy.mjs';
import {PHYSICAL_SOURCE_BYTES,PHYSICAL_SOURCE_SHA256,PHYSICAL_WEIGHT_SHA256} from 'file:///D:/Users/kovia/OneDrive/%E6%96%87%E4%BB%B6/ChatGPT/Tflite/tflite-explorer-transpose/test/physical-tflite-fixture.mjs';
const q=path.dirname(fileURLToPath(import.meta.url)),load=async n=>JSON.parse(await readFile(path.join(q,n),'utf8')),sha=b=>createHash('sha256').update(b).digest('hex');
const state=await load('physical-native-stack-status.json'),plan=await load('physical-native-stack-plan.json'),prepared=await load('physical-native-stack-preparation.json');
assert.equal(state.status,'producer-exited');assert.ok([0,1].includes(state.exitCode));assert.equal(state.nativeIdentitiesReconciledExited,true);assert.equal(state.caseCount,1);
assert.equal(sha(await readFile(path.join(q,'model-lifecycle-sdk1641-v2.mjs'))),plan.driver.baseSHA256);
assert.equal(sha(await readFile(path.join(q,'model-lifecycle-native-stack.mjs'))),prepared.overlaySHA256);
assert.equal(sha(await readFile(path.join(q,'owned-native-stack.py'))),plan.collector.SHA256);
assert.equal(prepared.existingDriverBodyOtherwiseIdentical,true);
const raw=await readFile(state.report),r=JSON.parse(raw),log=await readFile(state.log,'utf8');
assert.equal(r.environment.sourceCommit,plan.driver.commit);assert.equal(r.environment.sourceTree,plan.driver.tree);assert.equal(r.environment.sourceDirty,false);assert.equal(r.sourceUnchanged,true);assert.equal(r.environment.platform,'win32');assert.equal(r.environment.playwright,'1.64.1');
assert.equal(r.build.buildId,plan.application.build);assert.equal(r.build.version,'1.3.0');assert.equal(r.build.source.commit,plan.application.commit);assert.equal(r.build.source.tree,plan.application.tree);assert.equal(r.build.source.dirty,false);assert.equal(r.artifactAdmission.executableInputsIdentical,true);
assert.equal(r.fixture.bytes,PHYSICAL_SOURCE_BYTES);assert.equal(r.fixture.sha256,PHYSICAL_SOURCE_SHA256);assert.equal(r.fixture.weightSHA256,PHYSICAL_WEIGHT_SHA256);assert.ok(r.fixture.allocatedBytes>=r.fixture.bytes*.99);assert.equal(r.documentFixture.httpDocumentTransportVerified,false);
assert.deepEqual(r.policy,MODEL_COMPOSITION_LIFECYCLE_POLICY);assert.equal(r.watchdogMinutes,30);assert.equal(r.cycles.length,8);assert.ok(r.samples.length>0);
const evaluated=evaluateLifecycle(r);assert.deepEqual(evaluated,r.evaluation);
const models=r.audit.workers.filter(w=>/\/model-worker\.js(?:\?|$)/.test(w.url)),recovery=r.audit.workers.filter(w=>w.recoveryAudit);
assert.equal(models.length,40);assert.equal(recovery.length,16);assert.ok([...models,...recovery].every(w=>w.terminated));
assert.ok(r.workerClosures.length>=56&&r.workerClosures.every(w=>w.closed));assert.equal(r.windowsObserverClose.exitCode,0);
const forced=/<will force kill>|<forcefully close>|\[pid=\d+\] <kill>/.test(log);
const normalNative=r.browserClosed===true&&r.processCleanup.allReaped===true&&r.processCleanup.remaining.length===0&&!forced;
let diagnosis={status:'not-triggered'};
if(r.status==='passed'){
 assert.equal(state.exitCode,0);assert.equal(evaluated.status,'passed');assert.equal(normalNative,true);assert.deepEqual(r.errors,[]);
 let exists=false;try{await readFile(path.join(q,'chrome-physical-stack-1-native-stack.json'));exists=true;}catch(e){if(e.code!=='ENOENT')throw e;}assert.equal(exists,false,'Post-failure hook must not run on passed attempt');
}else{
 assert.equal(r.status,'failed');assert.equal(state.exitCode,1);
 if(r.errors.includes('Cleanup: Browser close/reap timed out.')){
  const checkpointRaw=await readFile(path.join(q,'chrome-physical-stack-1-failure-checkpoint.json')),checkpoint=JSON.parse(checkpointRaw);
  assert.equal(checkpoint.status,'failed');assert.ok(checkpoint.errors.includes('Cleanup: Browser close/reap timed out.'));
  assert.equal(checkpoint.diagnosticAfterOriginalFailure.originalCloseDeadlineMs,10000);
  assert.ok(checkpoint.failureNativeObservation.rows.length>0);
  try{
   const stackRaw=await readFile(path.join(q,'chrome-physical-stack-1-native-stack.json')),stack=JSON.parse(stackRaw);
   assert.equal(stack.failureCheckpointSHA256,sha(checkpointRaw));assert.ok(Date.parse(stack.startedAt)>=Date.parse(checkpoint.diagnosticAfterOriginalFailure.at));
   assert.equal(stack.identity.pid,r.processOwnership.root.pid);assert.equal(stack.identity.startTicks,r.processOwnership.root.startTicks);
   assert.ok(checkpoint.failureNativeObservation.rows.some(p=>p.pid===stack.identity.pid&&p.startTicks===stack.identity.startTicks));
   if(stack.status==='captured-owned-native-stacks'){assert.equal(stack.detached,true);assert.ok(Buffer.byteLength(stack.output)<1024**2);}
   diagnosis={status:stack.status,detached:stack.detached??false,stackSHA256:sha(stackRaw),checkpointSHA256:sha(checkpointRaw),error:stack.error??null};
  }catch(e){if(e.code!=='ENOENT')throw e;const err=await load('chrome-physical-stack-1-stack-error.json');diagnosis={status:'collector-failed',checkpointSHA256:sha(checkpointRaw),error:err.message};}
 }
}
const result={format:'model-lens-physical-native-stack-review',status:r.status==='passed'?'reviewed-physical-Windows-acceptance-passed':'reviewed-physical-Windows-acceptance-failed',at:new Date().toISOString(),producerExitCode:state.exitCode,originalWholeStatus:r.status,appRelease:r.build,driverSource:r.environment.sourceCommit,driverTree:r.environment.sourceTree,SDK:r.environment.playwright,browser:r.environment.chromium,cycles:r.cycles.length,samples:r.samples.length,fixture:r.fixture.bytes,originalMemoryEvaluation:evaluated,normalNativeExitWithinOriginalBounds:normalNative,subsequentSDKForcedCleanup:forced,nativeIdentities:r.windowsObservedIdentities.length,errors:r.errors,diagnosis,reportSHA256:sha(raw),logSHA256:sha(Buffer.from(log)),overlaySHA256:prepared.overlaySHA256,collectorSHA256:plan.collector.SHA256,modelWorkers:40,recoveryWorkers:16,workerCloseEvents:r.workerClosures.length,historicalRootCauseFixed:false,goalComplete:false,scope:'One still-failed original WindowsChrome physical case with only a post-failure checkpoint/stack hook. Any subsequent debug suspension/cleanup cannot repair original10s verdict. Not an app deployment or replacement GitHub release gate.'};
await writeFile(path.join(q,'chrome-physical-stack-1-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
