import difflib,hashlib,json,pathlib,subprocess
q=pathlib.Path(__file__).resolve().parent;repo=q.parents[2].parent/'tflite-explorer-transpose'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((q/'physical-native-stack-plan.json').read_bytes())
assert sha(q/plan['driver']['base'])==plan['driver']['baseSHA256']
assert sha(q/plan['collector']['file'])==plan['collector']['SHA256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==plan['driver']['commit']
assert subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()==''
source=(q/plan['driver']['base']).read_text(encoding='utf8')
needle="}catch(error){report.status='failed';errors.push(`Cleanup: ${error.message}`);report.forcedCleanup=[];"
assert source.count(needle)==1
hook="""
        // [DEBUG-owned-stack] Post-verdict only: no changed policy or success path.
        // Persist the unchanged10s failure BEFORE suspending/unwinding the owned root.
        if(windows&&windowsObserver&&error.message==='Browser close/reap timed out.'){
            const checkpoint=reportPath.replace(/\\.json$/,'-failure-checkpoint.json');
            try{
                const native=await windowsObserver.remaining();
                const row=native.rows.find(p=>p.pid===windowsObserver.root.pid&&p.startTicks===windowsObserver.root.startTicks);
                await writeFile(checkpoint,JSON.stringify({...report,errors:[...errors],failureNativeObservation:native,diagnosticAfterOriginalFailure:{at:new Date().toISOString(),stage:'before existing post-error native observation',originalCloseDeadlineMs:10000}},null,2)+'\\n',{flag:'wx'});
                if(row){
                    const output=execFileSync(python,[fileURLToPath(new URL('./owned-native-stack.py',import.meta.url)),'--failed-browser',reportPath.replace(/\\.json$/,'-native-stack.json')],{input:JSON.stringify({row,failureCheckpoint:checkpoint}),encoding:'utf8',windowsHide:true,timeout:15000,maxBuffer:1024**2});
                    await writeFile(reportPath.replace(/\\.json$/,'-stack-driver.log'),output,{flag:'wx'});
                }
            }catch(e){await writeFile(reportPath.replace(/\\.json$/,'-stack-error.json'),JSON.stringify({status:'diagnostic-failed',originalAcceptance:'failed',message:e.message},null,2)+'\\n',{flag:'wx'});}
        }
"""
overlay=source.replace(needle,needle+hook);target=q/'model-lifecycle-native-stack.mjs';assert not target.exists()
target.write_text(overlay,encoding='utf8')
(q/'physical-native-stack-overlay.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True),overlay.splitlines(True),fromfile='validated/model-lifecycle-sdk1641-v2.mjs',tofile='ignored-QA/model-lifecycle-native-stack.mjs')),encoding='utf8')
receipt={'status':'post-failure-only-overlay-prepared','baseSHA256':sha(q/plan['driver']['base']),'overlaySHA256':sha(target),'collectorSHA256':sha(q/'owned-native-stack.py'),'injectionCount':1,'existingDriverBodyOtherwiseIdentical':overlay.replace(hook,'')==source,'original30minWatchdogAnd10sCloseUnchanged':True}
assert receipt['existingDriverBodyOtherwiseIdentical']
(q/'physical-native-stack-preparation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(json.dumps(receipt))
