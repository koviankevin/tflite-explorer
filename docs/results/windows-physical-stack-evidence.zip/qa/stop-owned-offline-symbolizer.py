"""Bound the separate local diagnostic; never terminate a browser or model worker."""
import ctypes as c, datetime, json, os, pathlib
from ctypes import wintypes as w
q = pathlib.Path(__file__).resolve().parent
out = q / 'offline-symbol-bounded-observation.json'
assert not out.exists()
record = {'format': 'model-lens-bounded-offline-symbol-observation',
          'status': 'stop-intent-after-six-minute-local-attempt',
          'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'pid': 182292, 'expectedParent': 185980,
          'expectedCreationFileTime': '134379486941779096',
          'scope': 'Only the owned offline symbolizer previously identified by exact script command line. No browser, model worker, debugger settings or application changes.',
          'limit': 'Six-minute diagnostic bound chosen after observing no completed result; not an original browser acceptance policy.',
          'resolvedFunctionsAvailable': False, 'exactDebuggerSymbolAcceptanceProven': False}
with out.open('x', encoding='utf8') as f:
    f.write(json.dumps(record, indent=2) + '\n'); f.flush(); os.fsync(f.fileno())
kernel = c.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]; kernel.OpenProcess.restype = w.HANDLE
kernel.CloseHandle.argtypes = [w.HANDLE]; kernel.CloseHandle.restype = w.BOOL
kernel.GetProcessTimes.argtypes = [w.HANDLE] + [c.POINTER(w.FILETIME)] * 4; kernel.GetProcessTimes.restype = w.BOOL
kernel.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, c.POINTER(w.DWORD)]; kernel.QueryFullProcessImageNameW.restype = w.BOOL
kernel.TerminateProcess.argtypes = [w.HANDLE, w.UINT]; kernel.TerminateProcess.restype = w.BOOL
kernel.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]; kernel.WaitForSingleObject.restype = w.DWORD
class BASIC(c.Structure):
    _fields_ = [('reserved1', c.c_void_p), ('peb', c.c_void_p), ('reserved2', c.c_void_p * 2), ('pid', c.c_size_t), ('parent', c.c_size_t)]
native = c.WinDLL('ntdll'); native.NtQueryInformationProcess.argtypes = [w.HANDLE, w.ULONG, c.c_void_p, w.ULONG, c.c_void_p]; native.NtQueryInformationProcess.restype = c.c_long
handle = kernel.OpenProcess(0x100000 | 0x1000 | 1, False, record['pid'])
assert handle, c.get_last_error()
try:
    times = [w.FILETIME() for _ in range(4)]
    assert kernel.GetProcessTimes(handle, *[c.byref(t) for t in times])
    created = (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime
    assert str(created) == record['expectedCreationFileTime']
    basic = BASIC(); assert native.NtQueryInformationProcess(handle, 0, c.byref(basic), c.sizeof(basic), None) >= 0
    assert basic.pid == record['pid'] and basic.parent == record['expectedParent']
    size = w.DWORD(32768); image = c.create_unicode_buffer(size.value)
    assert kernel.QueryFullProcessImageNameW(handle, 0, image, c.byref(size))
    assert pathlib.Path(image.value).resolve() == pathlib.Path(r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe').resolve()
    now = datetime.datetime.now(datetime.timezone.utc).timestamp()
    assert now - (created / 10000000 - 11644473600) >= 360
    assert not (q / 'chrome-physical-stack-1-symbolized.json').exists(), 'A result arrived; preserve and inspect it instead.'
    assert kernel.TerminateProcess(handle, 124)
    assert kernel.WaitForSingleObject(handle, 10000) == 0
    record.update(status='bounded-offline-symbol-attempt-stopped-without-resolution',
                  nativeCreationAndParentVerified=True, sameHandleTermination=True,
                  nativeProcessExited=True, diagnosticExitCode=124)
finally:
    kernel.CloseHandle(handle)
record['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
with out.open('w', encoding='utf8') as f:
    f.write(json.dumps(record, indent=2) + '\n'); f.flush(); os.fsync(f.fileno())
print(json.dumps(record))
