import base64,datetime,gzip,hashlib,json,os,pathlib,re,shutil,struct,time,urllib.request,uuid
q=pathlib.Path(__file__).resolve().parent;key=json.loads((q/'chrome-symbol-key.json').read_bytes());d=q/'chrome-symbols-156.0.8078.76'
probe=json.loads((d/'encoding-probe.json').read_bytes());p=probe['prefix-gzip'];assert p['status']==206 and p['gzipMagic']
expected_wire=int(p['headers']['x-goog-stored-content-length']);etag=p['headers']['ETag'];assert expected_wire==1078604297
expected_raw=5709471744;assert shutil.disk_usage(d).free>expected_wire+expected_raw+2*1024**3
wire=d/'chrome.dll.pdb.gz';wirepart=d/'chrome.dll.pdb.gz.part';raw=d/'chrome.dll.pdb';rawpart=d/'chrome.dll.pdb.verified-uncompressed.part';status=d/'compressed-download-status.json'
assert all(not x.exists() for x in [wire,wirepart,raw,rawpart,status])
state={'status':'intent','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'publicSymbolKey':key['symbolKey'],'expectedWireBytes':expected_wire,'expectedRawBytes':expected_raw,'ETag':etag,'modelDataSent':False,'automaticRetries':False}
def save():
 tmp=status.with_suffix('.tmp')
 with tmp.open('w',encoding='utf8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(tmp,status)
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**k):raise RuntimeError('Unreviewed symbol redirect refused')
opener=urllib.request.build_opener(NoRedirect());save();started=time.monotonic()
try:
 digest=hashlib.sha256();md5=hashlib.md5();count=0;last=0
 request=urllib.request.Request(key['symbolURL'],headers={'Accept-Encoding':'gzip','If-Match':etag})
 with opener.open(request,timeout=30) as response:
  assert response.status==200 and response.headers.get('Content-Encoding')=='gzip' and response.headers.get('ETag')==etag
  assert int(response.headers.get('x-goog-stored-content-length','0'))==expected_wire
  hashes=response.headers.get('x-goog-hash','');state.update(status='downloading-compressed',wireBytes=0,providerHashes=hashes);save()
  with wirepart.open('xb') as f:
   while True:
    assert time.monotonic()-started<600
    chunk=response.read(1024**2)
    if not chunk:break
    count+=len(chunk);assert count<=expected_wire;f.write(chunk);digest.update(chunk);md5.update(chunk)
    if count-last>=128*1024**2:last=count;state['wireBytes']=count;save();print(json.dumps({'stage':'compressed','bytes':count}),flush=True)
   f.flush();os.fsync(f.fileno())
 assert count==expected_wire
 match=re.search(r'(?:^|,)\s*md5=([^,]+)',hashes)
 if match:assert base64.b64encode(md5.digest()).decode()==match.group(1).strip()
 assert md5.hexdigest()==etag.strip('"')
 os.rename(wirepart,wire);state.update(status='decompressing-with-CRC',wireBytes=count,wireSHA256=digest.hexdigest(),wireMD5=md5.hexdigest(),rawBytes=0);save()
 digest=hashlib.sha256();prefix=hashlib.sha256();count=0;last=0;old=d/'chrome.dll.pdb.part';prefix_size=old.stat().st_size
 with gzip.open(wire,'rb') as source,rawpart.open('xb') as dest:
  while True:
   chunk=source.read(1024**2)
   if not chunk:break
   before=count;count+=len(chunk);assert count<=expected_raw
   dest.write(chunk);digest.update(chunk)
   if before<prefix_size:prefix.update(chunk[:min(len(chunk),prefix_size-before)])
   if count-last>=512*1024**2:last=count;state['rawBytes']=count;save();print(json.dumps({'stage':'uncompressed','bytes':count}),flush=True)
  dest.flush();os.fsync(dest.fileno())
 assert count==expected_raw
 old_hash=hashlib.sha256()
 with old.open('rb') as f:
  for chunk in iter(lambda:f.read(1024**2),b''):old_hash.update(chunk)
 assert prefix.hexdigest()==old_hash.hexdigest()
 with rawpart.open('rb') as f:
  h=f.read(56);assert h[:32]==b'Microsoft C/C++ MSF 7.00\r\n\x1aDS\0\0\0'
  block,free_map,blocks,dir_bytes,reserved,map_block=struct.unpack_from('<6I',h,32)
  assert block in [512,1024,2048,4096,8192,16384,32768] and free_map in [1,2] and block*blocks==expected_raw and dir_bytes<=16*1024**2
  nblocks=(dir_bytes+block-1)//block;assert nblocks*4<=block and map_block<blocks
  f.seek(map_block*block);indices=struct.unpack('<'+'I'*nblocks,f.read(nblocks*4));chunks=[]
  for index in indices:assert index<blocks;f.seek(index*block);chunks.append(f.read(block))
  directory=b''.join(chunks)[:dir_bytes];n=struct.unpack_from('<I',directory)[0];assert 2<=n<=262144 and 4+4*n<=len(directory)
  sizes=struct.unpack_from('<'+'I'*n,directory,4);cursor=4+4*n+(0 if sizes[0]==0xffffffff else 4*((sizes[0]+block-1)//block))
  assert sizes[1]>=28 and cursor+4*((sizes[1]+block-1)//block)<=len(directory)
  first=struct.unpack_from('<I',directory,cursor)[0];assert first<blocks;f.seek(first*block);info=f.read(28)
  version,signature,age=struct.unpack_from('<3I',info);guid=str(uuid.UUID(bytes_le=info[12:28]));assert version==20000404 and guid==key['guid'] and age==key['age']
 os.rename(rawpart,raw);state.update(status='complete-exact-PDB-identity-CRC-and-provider-MD5-verified',rawBytes=count,rawSHA256=digest.hexdigest(),PDBGuid=guid,PDBAge=age,MSFBlockSize=block,streamCount=n,prefixMatchesInitialCappedDownload=True,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(json.dumps(state))
except Exception as e:
 state.update(status='failed-preserve-and-reconcile',errorType=type(e).__name__,error=str(e),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
