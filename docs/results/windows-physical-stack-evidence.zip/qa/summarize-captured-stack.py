import hashlib,json,pathlib,re
q=pathlib.Path(__file__).resolve().parent
p=q/'chrome-physical-stack-1-native-stack.json';r=json.loads(p.read_bytes());text=r['output']
headers=list(re.finditer(r'^\s*\.?\s*(\d+)\s+Id:\s*([0-9a-f]+)\.([0-9a-f]+).*$',text,re.M))
threads=[]
for i,m in enumerate(headers):
 end=headers[i+1].start() if i+1<len(headers) else text.find('start             end',m.end())
 block=text[m.end():end if end>=0 else len(text)]
 frames=[s.strip() for s in block.splitlines() if re.match(r'^[0-9a-f]{8}`[0-9a-f]{8}\s+[0-9a-f]{8}`[0-9a-f]{8}\s+',s)]
 name=re.search(r'Unfrozen\s+"([^"]+)"',m.group(0))
 threads.append({'index':int(m.group(1)),'tid':int(m.group(3),16),'name':name.group(1) if name else '', 'frames':frames})
module_part=text[text.find('start             end'):]
modules=[]
for m in re.finditer(r'^([0-9a-f]{8}`[0-9a-f]{8})\s+([0-9a-f]{8}`[0-9a-f]{8})\s+(\S+)\s*(.*)$',module_part,re.M):
 modules.append({'start':m.group(1),'end':m.group(2),'name':m.group(3),'info':m.group(4).strip()})
interesting=[t for t in threads if t['index']==0 or any(re.search(r'RPCRT4|combase|fastprox|wbem|netapi|dsreg|secur32|chromecompaneros',f,re.I) for f in t['frames'])]
result={'format':'model-lens-captured-stack-summary','status':'stack-addresses-and-thread-names-only','rawSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'threads':threads,'modules':modules,'threadCount':len(threads),'moduleCount':len(modules),
 'limitations':'Nearest exported Chrome names and huge offsets are not real resolved function names. WaitForSingleObject does not identify the waited-on object. No causal conclusion yet.'}
with (q/'chrome-physical-stack-1-stack-summary.json').open('x',encoding='utf8') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'threads':len(threads),'modules':len(modules),'chromeModules':[m for m in modules if m['name'].startswith('chrome')],'interestingThreads':[dict(t,frames=t['frames'][:8]) for t in interesting]}))
