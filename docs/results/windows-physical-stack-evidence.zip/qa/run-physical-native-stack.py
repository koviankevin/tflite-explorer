import datetime,hashlib,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2]
out=q/'chrome-physical-stack-1.json';log=q/'chrome-physical-stack-1.log';status=q/'physical-native-stack-status.json'
assert all(not p.exists() for p in [out,log,status,q/'chrome-physical-stack-1-native-stack.json',q/'chrome-physical-stack-1-failure-checkpoint.json'])
plan=json.loads((q/'physical-native-stack-plan.json').read_bytes());prepared=json.loads((q/'physical-native-stack-preparation.json').read_bytes())
assert hashlib.sha256((q/'model-lifecycle-native-stack.mjs').read_bytes()).hexdigest()==prepared['overlaySHA256']
assert hashlib.sha256((q/'owned-native-stack.py').read_bytes()).hexdigest()==plan['collector']['SHA256']
state={'status':'create-intent','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controllerPid':os.getpid(),'automaticRetries':False,'channel':'chrome','report':str(out),'log':str(log),'source':plan['driver'],'application':plan['application'],'caseCount':1}
def save():
 p=status.with_suffix('.tmp')
 with p.open('w',encoding='utf8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(p,status)
save()
native=root/'test/browser/windows-process-memory.py';scope={'__name__':'owned_census'};exec(compile(native.read_text('utf8').split('observer=Observer()')[0],str(native),'exec'),scope)
def exited(r):
 table=scope['snapshot']();identities=list(r.get('windowsObservedIdentities',[]))
 for key in ['failureNativeObservation','processCleanup','normalNativeObservation']:identities+=r.get(key,{}).get('identities',[])
 for identity in identities:
  row=table.get(identity['pid'])
  if row:assert scope['inspect']({**row,'startTicks':identity['startTicks']}) is None,'Earlier owned browser remains; no new case'
for name in ['chrome-physical1641-2.json','msedge-physical1641-2.json','chrome-stack-1/report.json','chrome-stack-2/report.json','baseline-stack-1.json']+[f'chrome-stack-sampling-{n}/report.json' for n in [1,2,3]]:exited(json.loads((q/name).read_bytes()))
node=r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
env={**os.environ,'LIFECYCLE_MODE':'gate','MODEL_LENS_BROWSER_CHANNEL':'chrome','MODEL_LENS_QA_PYTHON':sys.executable,'MODEL_LENS_TRUSTED_BOOTSTRAP':'1','LIFECYCLE_BUILD':str(root/'build/qa/op-validation/v1.3.0-prepared-artifacts/core'),'LIFECYCLE_REPORT':str(out),'DEBUG':'pw:browser'}
with log.open('xb') as f:
 p=subprocess.Popen([node,str(q/'model-lifecycle-native-stack.mjs'),'--allow-local-browser'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 state.update(status='running',pid=p.pid);save();print(json.dumps({'status':'running','pid':p.pid,'report':str(out)}),flush=True);code=p.wait()
state.update(status='producer-exited',exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
if out.exists():
 r=json.loads(out.read_bytes());state['reportedStatus']=r['status'];exited(r);state['nativeIdentitiesReconciledExited']=True
 stack=q/'chrome-physical-stack-1-native-stack.json'
 if stack.exists():
  s=json.loads(stack.read_bytes());state['stackStatus']=s['status'];state['stackDetached']=s.get('detached')
else:state['missingFinalReport']=True
save();print(json.dumps(state));sys.exit(code)
