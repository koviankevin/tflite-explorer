"""Local-only symbolization of saved addresses; no live target or source execution."""
import ctypes as c,datetime,hashlib,json,os,pathlib,re,sys,uuid
from ctypes import wintypes as w
q=pathlib.Path(__file__).resolve().parent;d=q/'chrome-symbols-156.0.8078.76';sdk=q/'dbgeng-20260319'
key=json.loads((q/'chrome-symbol-key.json').read_bytes());receipt=json.loads((d/'pdb-identity-verification.json').read_bytes())
assert receipt['status']=='complete-exact-PDB-identity-CRC-and-provider-MD5-verified' and receipt['PDBGuid']==key['guid'] and receipt['PDBAge']==key['age']
summary=json.loads((q/'chrome-physical-stack-1-stack-summary.json').read_bytes());assert summary['rawSHA256']==key['stackSHA256']
assert c.sizeof(c.c_void_p)==8
manifest=json.loads((sdk/'extracted-manifest.json').read_bytes());sig=json.loads((sdk/'authenticode.json').read_text(encoding='utf-8-sig'))
assert all(r['status']=='Valid' and 'O=Microsoft Corporation' in r['subject'] for r in sig)
for row in manifest['files']:
 if row['path'].startswith('content/amd64/'):assert hashlib.sha256((sdk/'extracted'/row['path']).read_bytes()).hexdigest()==row['sha256']
for name in ['_NT_SYMBOL_PATH','_NT_ALT_SYMBOL_PATH','_NT_SOURCE_PATH','_NT_SYMBOL_PROXY']:os.environ[name]=''
os.environ['DBGHELP_HOMEDIR']=str(d)
directory=os.add_dll_directory(str(sdk/'extracted/content/amd64'))
dbg=c.WinDLL(str(sdk/'extracted/content/amd64/dbghelp.dll'),winmode=0x100|0x1000,use_last_error=True)
k=c.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=w.HANDLE;process=k.GetCurrentProcess()
U64=c.c_ulonglong
class GUID(c.Structure):_fields_=[('a',w.DWORD),('b',w.WORD),('c',w.WORD),('d',c.c_ubyte*8)]
class SYMBOL(c.Structure):
 _fields_=[('SizeOfStruct',w.ULONG),('TypeIndex',w.ULONG),('Reserved',U64*2),('Index',w.ULONG),('Size',w.ULONG),('ModBase',U64),('Flags',w.ULONG),('Value',U64),('Address',U64),('Register',w.ULONG),('Scope',w.ULONG),('Tag',w.ULONG),('NameLen',w.ULONG),('MaxNameLen',w.ULONG),('Name',w.WCHAR*1)]
class MODULE(c.Structure):
 _fields_=[('SizeOfStruct',w.DWORD),('BaseOfImage',U64),('ImageSize',w.DWORD),('TimeDateStamp',w.DWORD),('CheckSum',w.DWORD),('NumSyms',w.DWORD),('SymType',c.c_int),('ModuleName',w.WCHAR*32),('ImageName',w.WCHAR*256),('LoadedImageName',w.WCHAR*256),('LoadedPdbName',w.WCHAR*256),('CVSig',w.DWORD),('CVData',w.WCHAR*780),('PdbSig',w.DWORD),('PdbSig70',GUID),('PdbAge',w.DWORD),('PdbUnmatched',w.BOOL),('DbgUnmatched',w.BOOL),('LineNumbers',w.BOOL),('GlobalSymbols',w.BOOL),('TypeInfo',w.BOOL),('SourceIndexed',w.BOOL),('Publics',w.BOOL),('MachineType',w.DWORD),('Reserved',w.DWORD)]
assert c.sizeof(SYMBOL)==88 and SYMBOL.Name.offset==84 and c.sizeof(MODULE)==3264
dbg.SymSetOptions.argtypes=[w.DWORD];dbg.SymSetOptions.restype=w.DWORD
dbg.SymInitializeW.argtypes=[w.HANDLE,w.LPCWSTR,w.BOOL];dbg.SymInitializeW.restype=w.BOOL
dbg.SymCleanup.argtypes=[w.HANDLE];dbg.SymCleanup.restype=w.BOOL
dbg.SymLoadModuleExW.argtypes=[w.HANDLE,w.HANDLE,w.LPCWSTR,w.LPCWSTR,U64,w.DWORD,c.c_void_p,w.DWORD];dbg.SymLoadModuleExW.restype=U64
dbg.SymFromAddrW.argtypes=[w.HANDLE,U64,c.POINTER(U64),c.POINTER(SYMBOL)];dbg.SymFromAddrW.restype=w.BOOL
dbg.SymGetModuleInfoW64.argtypes=[w.HANDLE,U64,c.POINTER(MODULE)];dbg.SymGetModuleInfoW64.restype=w.BOOL
base=int(key['loadedModule']['start'].replace('`',''),16);end=base+key['imageSize'];rows=[]
for thread in summary['threads']:
 previous_return=None
 for index,line in enumerate(thread['frames']):
  m=re.match(r'^[0-9a-f]{8}`[0-9a-f]{8}\s+([0-9a-f]{8}`[0-9a-f]{8})\s+(.*)$',line)
  assert m
  if previous_return is not None and re.match(r'chrome(?:!|\+)',m.group(2)):
   assert base<=previous_return<end
   rows.append({'thread':thread['index'],'threadName':thread['name'],'frame':index,'address':hex(previous_return),'rva':hex(previous_return-base),'originalNearestExport':m.group(2)})
  previous_return=int(m.group(1).replace('`',''),16)
assert rows and rows[0]['thread']==0
result={'format':'model-lens-offline-Chrome-symbols','status':'failed','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stackSHA256':key['stackSHA256'],'PDBSHA256':receipt['rawSHA256'],'PDBGuid':key['guid'],'PDBAge':key['age'],'source':'Official public Chrome symbols, exact GUID/age verified','scope':'Only saved addresses and local files; no live process attach, symbol network, source-server execution or model content.', 'frames':rows}
initialized=False
try:
 # Explicit local path and ignore inherited paths. No source/symsrv API is used.
 dbg.SymSetOptions(0x2|0x4|0x200|0x400|0x1000|0x80000|0x2000000)
 if not dbg.SymInitializeW(process,str(d),False):raise c.WinError(c.get_last_error())
 initialized=True
 loaded=dbg.SymLoadModuleExW(process,None,key['binary'],'chrome',base,key['imageSize'],None,0)
 if loaded!=base:raise c.WinError(c.get_last_error())
 cache={}
 for row in rows:
  address=int(row['address'],16)
  if address not in cache:
   storage=c.create_string_buffer(c.sizeof(SYMBOL)+2*4096);ptr=c.cast(storage,c.POINTER(SYMBOL));ptr.contents.SizeOfStruct=c.sizeof(SYMBOL);ptr.contents.MaxNameLen=4096
   displacement=U64()
   if dbg.SymFromAddrW(process,address,c.byref(displacement),ptr):
    s=ptr.contents;assert 0<s.NameLen<4096 and s.ModBase==base
    name=c.wstring_at(c.addressof(storage)+SYMBOL.Name.offset,s.NameLen)
    cache[address]={'function':name,'displacement':displacement.value,'symbolAddress':hex(s.Address),'symbolSize':s.Size,'flags':s.Flags}
   else:cache[address]={'error':c.get_last_error()}
  row.update(cache[address])
 info=MODULE();info.SizeOfStruct=c.sizeof(MODULE)
 if not dbg.SymGetModuleInfoW64(process,base,c.byref(info)):raise c.WinError(c.get_last_error())
 guid=str(uuid.UUID(bytes_le=c.string_at(c.byref(info.PdbSig70),16)))
 result['observedModuleIdentity']={'GUID':guid,'age':info.PdbAge,'unmatchedPDB':bool(info.PdbUnmatched),'unmatchedDBG':bool(info.DbgUnmatched),'symbolType':info.SymType,'PDB':info.LoadedPdbName}
 assert guid==key['guid'] and info.PdbAge==key['age'] and not info.PdbUnmatched and not info.DbgUnmatched
 assert info.SymType in [3,7] and pathlib.Path(info.LoadedPdbName).resolve()==(d/'chrome.dll.pdb').resolve()
 result['loadedSymbols']={'type':info.SymType,'count':info.NumSyms,'PDB':info.LoadedPdbName,'GUID':guid,'age':info.PdbAge,'exactMatched':True}
 assert all('function' in r for r in rows if r['thread']==0)
 result['status']='exact-official-PDB-offline-addresses-resolved'
except Exception as e:result['error']=str(e)
finally:
 if initialized:result['symbolCleanup']=bool(dbg.SymCleanup(process))
 directory.close();result['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 out=q/'chrome-physical-stack-1-symbolized.json';assert not out.exists()
 with out.open('x',encoding='utf8') as f:f.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k!='frames'}))
 print(json.dumps({'mainThread':[r for r in rows if r['thread']==0]}))
if result['status']!='exact-official-PDB-offline-addresses-resolved':sys.exit(1)
