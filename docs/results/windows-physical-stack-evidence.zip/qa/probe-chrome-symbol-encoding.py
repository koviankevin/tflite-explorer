import datetime,json,pathlib,urllib.error,urllib.request
q=pathlib.Path(__file__).resolve().parent;key=json.loads((q/'chrome-symbol-key.json').read_bytes());d=q/'chrome-symbols-156.0.8078.76'
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**k):raise RuntimeError('Unreviewed symbol redirect refused')
opener=urllib.request.build_opener(NoRedirect());result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Inspect stored compressed representation of exact official public PDB; no model or diagnostic upload'}
names=['Content-Length','Content-Encoding','Content-Range','x-goog-stored-content-length','x-goog-stored-content-encoding','ETag']
for name,method,headers in [('head-gzip','HEAD',{'Accept-Encoding':'gzip'}),('prefix-gzip','GET',{'Accept-Encoding':'gzip','Range':'bytes=0-55'})]:
 try:
  with opener.open(urllib.request.Request(key['symbolURL'],method=method,headers=headers),timeout=20) as r:
   data=r.read(57) if method=='GET' else b''
   result[name]={'status':r.status,'headers':{n:r.headers.get(n) for n in names},'bytesRead':len(data),'prefixHex':data[:8].hex(),'gzipMagic':data[:2]==b'\x1f\x8b'}
 except urllib.error.HTTPError as e:result[name]={'status':e.code,'headers':{n:e.headers.get(n) for n in names}}
out=d/'encoding-probe.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result))
