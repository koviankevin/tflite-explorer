import datetime,hashlib,json,os,pathlib,struct,time,urllib.parse,urllib.request,uuid
q=pathlib.Path(__file__).resolve().parent;key=json.loads((q/'chrome-symbol-key.json').read_bytes())
head=json.loads((q/'chrome-symbol-head.json').read_bytes());assert head['status']==200
url=key['symbolURL'];assert urllib.parse.urlparse(url).hostname=='chromium-browser-symsrv.commondatastorage.googleapis.com'
d=q/'chrome-symbols-156.0.8078.76';d.mkdir(exist_ok=False)
status=d/'download-status.json';part=d/'chrome.dll.pdb.part';dest=d/'chrome.dll.pdb';limit=1024**3
state={'status':'request-intent','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'publicModule':key['pdb'],'publicSymbolKey':key['symbolKey'],'modelDataSent':False,'automaticRetries':False,'bytes':0,'limit':limit}
def save():
 p=status.with_suffix('.tmp')
 with p.open('w',encoding='utf8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(p,status)
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**k):raise RuntimeError('Unreviewed symbol redirect refused')
opener=urllib.request.build_opener(NoRedirect());save();start=time.monotonic();h=hashlib.sha256()
try:
 with opener.open(urllib.request.Request(url,headers={'Accept-Encoding':'identity'}),timeout=30) as response:
  assert response.status==200;length=int(response.headers.get('Content-Length','0'));assert length<=limit
  state.update(status='streaming',contentLength=length,contentType=response.headers.get('Content-Type'));save()
  with part.open('xb') as f:
   last=0
   while True:
    assert time.monotonic()-start<600,'Bounded symbol download elapsed limit exceeded'
    chunk=response.read(1024**2)
    if not chunk:break
    state['bytes']+=len(chunk);assert state['bytes']<=limit
    f.write(chunk);h.update(chunk)
    if state['bytes']-last>=32*1024**2:
     last=state['bytes'];save();print(json.dumps({'status':'streaming','bytes':last}),flush=True)
   f.flush();os.fsync(f.fileno())
  if length:assert length==state['bytes']
 # Validate the PDB's own info-stream GUID/age against the signed stock PE RSDS.
 with part.open('rb') as f:
  header=f.read(56);assert header[:32]==b'Microsoft C/C++ MSF 7.00\r\n\x1aDS\0\0\0'
  block_size,free_map,num_blocks,dir_size,reserved,map_block=struct.unpack_from('<6I',header,32)
  assert block_size in [512,1024,2048,4096] and free_map in [1,2] and num_blocks*block_size==state['bytes']
  assert 4<=dir_size<=16*1024**2 and map_block<num_blocks
  count=(dir_size+block_size-1)//block_size;assert count*4<=block_size
  f.seek(map_block*block_size);directory_blocks=struct.unpack('<'+'I'*count,f.read(count*4))
  chunks=[]
  for block in directory_blocks:
   assert block<num_blocks;f.seek(block*block_size);chunks.append(f.read(block_size))
  directory=b''.join(chunks)[:dir_size];n=struct.unpack_from('<I',directory)[0];assert 2<=n<=262144 and 4+4*n<=len(directory)
  sizes=struct.unpack_from('<'+'I'*n,directory,4);cursor=4+4*n
  first_blocks=0 if sizes[0]==0xffffffff else (sizes[0]+block_size-1)//block_size;cursor+=4*first_blocks
  assert sizes[1]>=28;info_blocks=(sizes[1]+block_size-1)//block_size;assert cursor+4*info_blocks<=len(directory)
  first=struct.unpack_from('<I',directory,cursor)[0];assert first<num_blocks
  f.seek(first*block_size);info=f.read(28);version,signature,age=struct.unpack_from('<3I',info)
  guid=str(uuid.UUID(bytes_le=info[12:28]));assert version==20000404 and guid==key['guid'] and age==key['age']
 assert not dest.exists();os.rename(part,dest)
 state.update(status='downloaded-and-exact-PDB-GUID-age-verified',sha256=h.hexdigest(),PDBGuid=guid,PDBAge=age,MSFBlockSize=block_size,streamCount=n,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(json.dumps(state))
except Exception as e:
 state.update(status='failed-preserve-partial-and-reconcile',errorType=type(e).__name__,error=str(e),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
