import datetime,hashlib,json,os,pathlib,struct,uuid,zlib
q=pathlib.Path(__file__).resolve().parent;d=q/'chrome-symbols-156.0.8078.76';key=json.loads((q/'chrome-symbol-key.json').read_bytes())
prior=json.loads((d/'compressed-download-status.json').read_bytes());assert prior['status']=='failed-preserve-and-reconcile' and prior['errorType']=='AssertionError'
wire=d/'chrome.dll.pdb.gz';raw=d/'chrome.dll.pdb.verified-uncompressed.part';dest=d/'chrome.dll.pdb'
assert wire.stat().st_size==1078604297 and raw.stat().st_size==5709471744 and not dest.exists()
md5=hashlib.md5();wire_sha=hashlib.sha256()
with wire.open('rb') as f:
 for chunk in iter(lambda:f.read(1024**2),b''):md5.update(chunk);wire_sha.update(chunk)
 f.seek(-8,2);expected_crc,isize=struct.unpack('<II',f.read(8))
assert md5.hexdigest()==prior['ETag'].strip('"')==prior['wireMD5'] and wire_sha.hexdigest()==prior['wireSHA256']
digest=hashlib.sha256();prefix=hashlib.sha256();crc=0;count=0;prefix_bytes=(d/'chrome.dll.pdb.part').stat().st_size
with raw.open('rb') as f:
 for chunk in iter(lambda:f.read(1024**2),b''):
  before=count;count+=len(chunk);digest.update(chunk);crc=zlib.crc32(chunk,crc)
  if before<prefix_bytes:prefix.update(chunk[:min(len(chunk),prefix_bytes-before)])
assert count==5709471744 and count%(2**32)==isize and crc==expected_crc
old=hashlib.sha256()
with (d/'chrome.dll.pdb.part').open('rb') as f:
 for chunk in iter(lambda:f.read(1024**2),b''):old.update(chunk)
assert old.hexdigest()==prefix.hexdigest()
with raw.open('rb') as f:
 h=f.read(56);assert h[:32]==b'Microsoft C/C++ MSF 7.00\r\n\x1aDS\0\0\0'
 block,free_map,blocks,dir_bytes,reserved,map_block=struct.unpack_from('<6I',h,32)
 assert block==8192 and free_map in [1,2] and blocks*block==count and 0<dir_bytes<=16*1024**2
 nblocks=(dir_bytes+block-1)//block;assert nblocks*4<=block
 f.seek(map_block*block);indices=struct.unpack('<'+'I'*nblocks,f.read(nblocks*4));chunks=[]
 for index in indices:assert index<blocks;f.seek(index*block);chunks.append(f.read(block))
 directory=b''.join(chunks)[:dir_bytes];n=struct.unpack_from('<I',directory)[0];assert 4<=n<=262144
 sizes=struct.unpack_from('<'+'I'*n,directory,4)
 def stream_head(index,need):
  assert sizes[index]>=need;cursor=4+4*n+sum(0 if size==0xffffffff else 4*((size+block-1)//block) for size in sizes[:index])
  page=struct.unpack_from('<I',directory,cursor)[0];assert page<blocks;f.seek(page*block);return f.read(need)
 info=stream_head(1,28);version,signature,info_age=struct.unpack_from('<3I',info);guid=str(uuid.UUID(bytes_le=info[12:28]))
 dbi=stream_head(3,64);dbi_signature,dbi_version,dbi_age=struct.unpack_from('<iII',dbi)
 assert version==20000404 and dbi_signature==-1 and dbi_version==19990903 and guid==key['guid'] and dbi_age==key['age']
 assert info_age==2 and dbi_age==1
 # Do not modify either age or any PDB/binary bytes. The normal debugger must
 # independently accept this file with EXACT_SYMBOLS and no unmatched flags.
# Windows denies renaming the file while this process's read handle is open.
# All metadata was read and verified above; close that handle before renaming.
os.rename(raw,dest)
result={'status':'complete-exact-PDB-identity-CRC-and-provider-MD5-verified','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'rawBytes':count,'rawSHA256':digest.hexdigest(),'wireBytes':wire.stat().st_size,'wireSHA256':wire_sha.hexdigest(),'wireMD5':md5.hexdigest(),'gzipCRC32':format(crc,'08x'),
 'PDBGuid':guid,'PDBAge':dbi_age,'PDBInfoAge':info_age,'DBIAge':dbi_age,'moduleRSDSAge':key['age'],'MSFBlockSize':block,'streamCount':n,
 'originalFailedAcquisitionPreserved':True,'binaryAndPDBModified':False,'normalDebuggerExactMatchStillRequired':True,
 'ageReview':'Info age2 differs from DBI/executable age1. Chrome source indexing increments one age; do not mask a loader mismatch or patch the file. Exact-symbol debugger acceptance is a separate mandatory check.',
 'references':['https://groups.google.com/a/chromium.org/g/chromium-dev/c/Ve4p_Mnz-74','https://raw.githubusercontent.com/llvm/llvm-project/main/llvm/include/llvm/DebugInfo/MSF/MSFCommon.h']}
out=d/'pdb-identity-verification.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result))
