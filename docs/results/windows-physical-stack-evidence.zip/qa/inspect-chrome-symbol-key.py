import hashlib,json,pathlib,struct,uuid
q=pathlib.Path(__file__).resolve().parent
plan=json.loads((q/'chrome-symbol-plan.json').read_bytes());binary=pathlib.Path(plan['binary'])
summary=json.loads((q/'chrome-physical-stack-1-stack-summary.json').read_bytes())
module=next(m for m in summary['modules'] if m['name']=='chrome')
assert str(binary) in module['info'] and binary.is_file() and not binary.is_symlink()
with binary.open('rb') as f:
 assert f.read(2)==b'MZ';f.seek(0x3c);offset=struct.unpack('<I',f.read(4))[0];assert offset<1024**2
 f.seek(offset);header=f.read(24);assert header[:4]==b'PE\0\0'
 machine,sections=struct.unpack_from('<HH',header,4);optional_size=struct.unpack_from('<H',header,20)[0]
 assert machine==0x8664 and 1<=sections<=96 and 168<=optional_size<=4096
 optional=f.read(optional_size);assert struct.unpack_from('<H',optional)[0]==0x20b
 image_size=struct.unpack_from('<I',optional,56)[0]
 assert int(module['end'].replace('`',''),16)-int(module['start'].replace('`',''),16)==image_size
 debug_rva,debug_size=struct.unpack_from('<II',optional,112+6*8);assert debug_size>0 and debug_size%28==0 and debug_size<=28*128
 section_table=f.read(sections*40);debug_offset=None
 for i in range(sections):
  virtual_size,rva,raw_size,raw_ptr=struct.unpack_from('<IIII',section_table,i*40+8)
  if rva<=debug_rva<rva+raw_size:debug_offset=raw_ptr+debug_rva-rva
 assert debug_offset is not None
 f.seek(debug_offset);entries=f.read(debug_size);found=[]
 for i in range(debug_size//28):
  kind,size,address,ptr=struct.unpack_from('<IIII',entries,i*28+12)
  if kind!=2:continue
  assert 24<size<=4096;f.seek(ptr);data=f.read(size)
  if data[:4]!=b'RSDS':continue
  guid=uuid.UUID(bytes_le=data[4:20]);age=struct.unpack_from('<I',data,20)[0];pdb=pathlib.PureWindowsPath(data[24:].split(b'\0')[0].decode('utf8')).name
  assert pdb=='chrome.dll.pdb';found.append({'guid':str(guid),'age':age,'pdb':pdb,'RSDSBytesSHA256':hashlib.sha256(data).hexdigest()})
 assert len(found)==1;key=found[0]
 f.seek(0);h=hashlib.sha256()
 for chunk in iter(lambda:f.read(1024**2),b''):h.update(chunk)
result={'status':'saved-loaded-module-and-stock-PE-key-bound','binary':str(binary),'binaryBytes':binary.stat().st_size,'binarySHA256':h.hexdigest(),'imageSize':image_size,'loadedModule':module,
        **key,'symbolKey':guid.hex.upper()+format(age,'X'),'stackSHA256':summary['rawSHA256'],'symbolURL':'https://chromium-browser-symsrv.commondatastorage.googleapis.com/'+pdb+'/'+guid.hex.upper()+format(age,'X')+'/'+pdb}
out=q/'chrome-symbol-key.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result))
