import datetime,json,pathlib,struct,urllib.parse,urllib.request
q=pathlib.Path(__file__).resolve().parent;key=json.loads((q/'chrome-symbol-key.json').read_bytes());d=q/'chrome-symbols-156.0.8078.76'
part=d/'chrome.dll.pdb.part'
with part.open('rb') as f:h=f.read(56)
block,_,count,dir_size,_,map_block=struct.unpack_from('<6I',h,32)
total=block*count;start=map_block*block;end=min(total,start+block)-1
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**k):raise RuntimeError('Unreviewed symbol redirect refused')
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Full public PDB is larger than1GiB initial cap; preserve partial, probe exact byte ranges to resolve saved frames without downloading unrelated type streams. No partial file claimed as a complete PDB.',
 'partialBytes':part.stat().st_size,'expectedFullBytes':total,'MSFBlockSize':block,'rangeStart':start,'rangeEnd':end,'modelDataSent':False}
request=urllib.request.Request(key['symbolURL'],headers={'Range':f'bytes={start}-{end}','Accept-Encoding':'identity'})
with urllib.request.build_opener(NoRedirect()).open(request,timeout=20) as r:
 result.update(status=r.status,contentRange=r.headers.get('Content-Range'));data=r.read(block+1)
result['bytesRead']=len(data);result['exactRangeSupported']=result['status']==206 and result['contentRange']==f'bytes {start}-{end}/{total}' and len(data)==block
if result['exactRangeSupported']:(d/'directory-map-probe.bin').write_bytes(data)
(d/'range-probe.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result))
