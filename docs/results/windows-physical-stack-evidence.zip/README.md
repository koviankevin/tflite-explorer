# Physical Windows Chrome failure evidence

One predeclared synthetic 1,349,965,216-byte / 21,005-OP eight-cycle case.
Application: public v1.3.0 / 7debc69 / build44782d0412ebc0b8.
Driver: 3f2115c / tree76ee1c3, isolated official Playwright1.64.1.
Only a post-original-failure checkpoint/stack hook was added to the bound driver.
Original RSS, read, URL and10sclose verdicts remain unchanged.

Exports, weights, custom options, pattern positive/negative cases, 40modelWorkers,
16fingerprintWorkers and57nativeWorkerClose events passed. Original memory
sub-verdict passed; original whole case still failed normal browser teardown.
The later SDK forced cleanup is not normal exit or a repaired acceptance.

Unlike the preceding diagnostic set, a genuine failing Chrome root stack was
captured after the original failure checkpoint and detached. Public Chrome
symbols were acquired using only module GUID/age. Offline decoding uses local
saved addresses and the stock signed DLL, never a model or stack upload.
Nearest-export names in the original stack are not accurate function names.
Read the offline result status and exact-match identity before interpreting names.
No symbol mismatch is forced or file rewritten to make a debugger accept it.
The PDB Info age differs from DBI/executable age and is recorded separately.
The single offline decoding attempt did not produce a result within its separately
chosen six-minute bound. Only that owned diagnostic was stopped, with same-handle
PID/creation/parent/image proof. Normal debugger exact-symbol acceptance remains
unproven; no decoded Chrome functions or causal root-cause claim are available.

This archive contains unchanged metadata, bounded stack text, reports and sources.
The large synthetic fixture, PDB, gzip, incomplete download and debugger binaries
are intentionally retained locally and not redistributed. Initial acquisition,
age-check and own-file-handle rename failures are preserved as setup failures.
No company models, personal profiles, raw memory dumps or input/weight bytes.
No deployment, Release/tag rewrite, relaxed policies or further soak. A snapshot
does not by itself prove what object is awaited or establish the historical cause.

manifest.json binds unchanged originals and deduplicated members. Controllers
are archived sources, not automatically executable acceptance instructions.
