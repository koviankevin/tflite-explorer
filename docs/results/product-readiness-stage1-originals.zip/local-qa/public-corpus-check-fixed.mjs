import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import vm from 'node:vm';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {parseModel} from '../../../src/model-engine.js';
import {editTfliteModel} from '../../../src/tflite-model-edit.js';
import {validateTfliteConstants} from '../../../src/tflite-constant-checks.js';
import {executeRuntime} from '../../../src/tflite-runtime-execute.js';
import {runtimePlan} from '../../../src/tflite-runtime-policy.js';
import {Archive} from '../../../vendor/netron/zip.js';
import {gitSource} from '../../../scripts/lib/release-artifact.mjs';
const source=gitSource(),sha=b=>createHash('sha256').update(b).digest('hex'),directory='build/qa/product-next/public-corpus-check-2';await mkdir(directory);
const corpus='build/qa/product-next/public-corpus',manifest=JSON.parse(await readFile(corpus+'/manifest.json','utf8')),metadata=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',import.meta.url),'utf8'));
assert.equal(source.dirty,false);assert.equal(manifest.files.length,4);const report={source,status:'failed',corpus:manifest,models:[],scope:'Four official public small TFLite models,identity edit/reparse,all retained buffers and bounded constant checks;admitted static models require real CPU identity equivalence;dynamic models remain not-verified with no model-body/runtime execution. Not expected-answer accuracy or private models.'};
const base=new URL('../../../vendor/litert/2.6.0/',import.meta.url),messages=[];globalThis.self=globalThis;globalThis.require=createRequire(import.meta.url);globalThis.__dirname=fileURLToPath(base);globalThis.importScripts=url=>vm.runInThisContext(readFileSync(new URL(url),'utf8'),{filename:fileURLToPath(url)});globalThis.Module={locateFile:name=>fileURLToPath(new URL(name,base)),printErr:s=>{messages.push(String(s));if(messages.length>12)messages.shift();}};
const rt=await import('../../../vendor/litert/2.6.0/core.js');await rt.loadLiteRt(new URL('litert_wasm_compat_internal.js',base).href);
const parse=raw=>parseModel((o,n)=>raw.subarray(o,o+n),raw.length,metadata),payload=(m,b,id)=>{const x=m.buffers[id];return x.size?b.subarray(Number(x.offset),Number(x.offset+x.size)):new Uint8Array(x.data||[]);};
try{
 for(const item of manifest.files){
  assert.equal(path.basename(item.file),item.file);const raw=new Uint8Array(await readFile(corpus+'/'+item.file));assert.equal(raw.length,item.bytes);assert.equal(sha(raw),item.sha256);const row={name:item.file,status:'failed',sourceSHA256:item.sha256};report.models.push(row);
  try{
   const index=await parse(raw),plans=index.raw.subgraphs.map((g,graph)=>({graph,operators:g.operators.map((o,template)=>({template,inputs:Array.from(o.inputs)}))}));row.operators=index.raw.subgraphs.reduce((n,g)=>n+g.operators.length,0);row.graphs=index.raw.subgraphs.length;
   const result=editTfliteModel(index,new File([raw],item.file),plans),edited=new Uint8Array(await result.blob.arrayBuffer()),reopened=await parse(edited);row.outputSHA256=sha(edited);row.outputBytes=edited.length;await writeFile(directory+'/'+item.file+'.edited.tflite',edited,{flag:'wx'});
   assert.equal(index.raw.buffers.length,reopened.raw.buffers.length);row.buffers=[];for(let id=0;id<index.raw.buffers.length;id++){const a=payload(index.raw,raw,id),b=payload(reopened.raw,edited,id);assert.deepEqual(b,a);row.buffers.push({id,bytes:a.length,sha256:sha(a)});}
   row.constants=reopened.raw.subgraphs.map((g,id)=>validateTfliteConstants(reopened.raw,id,(o,n)=>edited.subarray(o,o+n)));
   const outputs=[];row.runtime=[];
   for(const [label,model,blob]of [['original',index.raw,new Blob([raw])],['edited',reopened.raw,result.blob]]){
    const plan=runtimePlan(model,blob.size);if(!plan.eligible){const skipped=await executeRuntime({blob:{size:blob.size,arrayBuffer(){throw Error('ineligible model must not read body');}},plan,rt:null});assert.equal(skipped.status,'not-verified');assert.match(skipped.reason,/動態/);outputs.push(null);row.runtime.push({label,status:skipped.status,reason:skipped.reason,bodyReads:0});continue;}messages.length=0;const r=await executeRuntime({blob,plan,rt,diagnostics:()=>messages});assert.equal(r.status,'passed',JSON.stringify(r));const bytes=new Uint8Array(await r.io.archive.arrayBuffer()),name=item.file+'.'+label+'.io.zip';await writeFile(directory+'/'+name,bytes,{flag:'wx'});const zip=Archive.open(bytes,'zip'),m=JSON.parse(new TextDecoder().decode(zip.entries.get('manifest.json').peek()));assert.equal(m.validation.status,'passed');outputs.push(m.outputs.map(o=>new Uint8Array(zip.entries.get(o.file).peek())));row.runtime.push({label,modelSHA256:r.modelSHA256,compiled:r.compiled,invoked:r.invoked,stage:r.stage,io:{file:name,bytes:bytes.length,sha256:sha(bytes)},outputs:m.outputs.map((o,i)=>({shape:o.shape,dtype:o.dtype,bytes:o.bytes,sha256:sha(outputs.at(-1)[i])}))});
   }
   assert.deepEqual(outputs[0],outputs[1]);row.runtimeStatus=outputs[0]===null?'not-verified':'passed';row.status='passed';
  }catch(error){row.error=error.stack||String(error);}
  console.log(JSON.stringify({name:row.name,status:row.status,operators:row.operators,error:row.error}));
 }
 assert.ok(report.models.every(m=>m.status==='passed'));assert.deepEqual(gitSource(),source);report.sourceUnchanged=true;report.status='passed';
}catch(error){report.error=error.stack||String(error);process.exitCode=1;}
finally{rt.unloadLiteRt();await writeFile(directory+'/report.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({status:report.status,models:report.models.length,error:report.error}));}
