import datetime,hashlib,json,os,pathlib,subprocess,zipfile
q=pathlib.Path(__file__).resolve().parent;repo=q.parents[2];dest=repo/'docs/results'
load=lambda n:json.loads((q/n).read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
verified=load('v1.2-published-review.json');assert verified['status']=='passed' and verified['goalComplete']==False
assert verified['source']=='f592e3d9df7ed48fae2ca19e353c7215638959a3' and verified['checks']==34 and verified['siteFiles']==1445
root=load('v1.2-current-root-review.json');assert root['status']=='passed-independent-current-root' and root['sha256']==verified['rootEntrySHA256']
archive=dest/'product-readiness-v1.2-evidence.zip';receipt=dest/'product-readiness-v1.2-published.json';assert not archive.exists() and not receipt.exists()
files={}
def add(name,p):
 b=p.read_bytes();assert 0<len(b)<=8*1024**2 and name not in files;files[name]=b
for name in ['v1.2-published-review.json','v1.2-prepared-review.json','v1.2-prepare-run.json','v1.2-prepare-jobs.json','v1.2-prepare-artifacts.json','v1.2-prepared-output.json','v1.2-publish-run.json','v1.2-publish-jobs.json','v1.2-publish-artifacts.json','v1.2-release.json','v1.2-latest-release.json','v1.2-tag.json','v1.2-deployment-map.json','v1.2-release-downloads-review.json','v1.2-current-http-review.json','v1.2-current-root-review.json','v1.2-live-index.json']:
 add('metadata/'+name,q/name)
for name in ['live-release-verification.zip','published-release-verification.zip','pages-live-report.json','production-smoke.json','production-smoke.png','pages-release-report.json']:
 add('original-live-reports/'+name,q/'v1.2-published-artifacts'/name)
for name in ['release-manifest.json','release-gates.json','model-lens-public-1.2.0-d69754e5b6791ecd.zip.sha256']:
 add('actual-release-downloads/'+name,q/'v1.2-release-downloads'/name)
for name in ['review-v1.2-published.mjs','review-v1.2-prepared.mjs','extract-v1.2-prepared.py','archive-v1.2-published.py']:
 add('readers/'+name,q/name)
for name in ['LICENSE','vendor/netron/LICENSE','scripts/lib/live-site.mjs','scripts/lib/deployment-history.mjs','scripts/lib/pages-release.mjs','test/browser/runtime-lifecycle-policy.mjs']:
 b=subprocess.check_output(['git','show',verified['source']+':'+name],cwd=repo);files['published-source/'+name]=b
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,b in sorted(files.items()):z.writestr(name,b)
members=[]
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for name,b in sorted(files.items()):assert z.read(name)==b;members.append(dict(path=name,bytes=len(b),sha256=sha(b)))
raw=archive.read_bytes()
result=dict(format='model-lens-product-readiness-v1.2-delivery',version=1,status='published-verified',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),published=verified,independentCurrentRoot=root,
 archive=dict(path=archive.name,bytes=len(raw),sha256=sha(raw),members=members),
 fullZIP=dict(retainedOnReleaseAndLocally=True,sourceURL='https://github.com/koviankevin/tflite-explorer/releases/download/v1.2.0/model-lens-public-1.2.0-d69754e5b6791ecd.zip',bytes=41262165,sha256='d2635dcef7f433da2524bb0213c47532439651e890d7cefb07afb354031e6eb5',notDuplicatedInEvidenceArchive=True),
 previousEvidence=['product-readiness-main-verification.json','product-readiness-stage1.json','product-readiness-stage2.json','product-readiness-stage3.json','product-readiness-stage3-update.json','font-reflow-verification.json'],
 remaining=['Windows physical Chrome final normal-close remains failed/unresolved; Linux and focused native acceptance do not replace it.','Unknown custom references stay conservative; arbitrary kernel/dialect/packing semantics and external MLIR resource selection remain outside verified support.','Historical startup timeout root cause is not proved fixed; full human/OS power-loss/arbitrary migration coverage is not claimed.'],
 scope='Incremental public release; full product goal active. No Sites/GHStudio sync, mobile,Firefox/WebKit,company data or new two-hour soak. No successful deployment rerun, GC/RSS subtraction/timer/security changes.')
with receipt.open('x',encoding='utf8') as f:f.write(json.dumps(result,indent=2)+'\n');f.flush();os.fsync(f.fileno())
review=dict(status='published-evidence-archive-verified',archive=archive.name,bytes=len(raw),members=len(members),sha256=sha(raw),receiptSHA256=sha(receipt.read_bytes()),source=verified['source'])
with (q/'v1.2-published-archive-review.json').open('x',encoding='utf8') as f:f.write(json.dumps(review,indent=2)+'\n');f.flush();os.fsync(f.fileno())
print(json.dumps(review),flush=True)
