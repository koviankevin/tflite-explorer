import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {validateDelivery,fileSHA256} from '../../../scripts/lib/pages-release.mjs';
import {verifyArtifact,sha256} from '../../../scripts/lib/release-artifact.mjs';
import {verifySite} from '../../../scripts/lib/versioned-site.mjs';
import {SITE_BASELINE,BASELINE_MANIFEST_SHA256} from '../../../scripts/lib/release-baseline.mjs';
const q=path.dirname(fileURLToPath(import.meta.url)),root=path.resolve(q,'../../..'),out=path.join(q,'v1.2-prepared-artifacts'),load=async n=>JSON.parse(await readFile(path.join(q,n),'utf8'));
const source='f592e3d9df7ed48fae2ca19e353c7215638959a3',tree='c0ac061dd6e864b2a2366fca3fb0f880e4012640';
const run=await load('v1.2-prepare-run.json'),jobs=(await load('v1.2-prepare-jobs.json')).jobs,metadata=await load('v1.2-prepare-artifacts.json'),prepared=await load('v1.2-prepared-output.json');
assert.equal(run.id,41177179195);assert.equal(run.status,'completed');assert.equal(run.conclusion,'success');assert.equal(run.run_attempt,1);assert.equal(run.event,'workflow_dispatch');assert.equal(run.head_branch,'main');assert.equal(run.head_sha,source);assert.equal(run.path,'.github/workflows/verified-pages.yml');assert.equal(run.repository.full_name,'koviankevin/tflite-explorer');assert.equal(run.head_repository.id,run.repository.id);
const prepare=jobs.filter(j=>j.name==='prepare');assert.equal(prepare.length,1);assert.equal(prepare[0].conclusion,'success');assert.equal(prepare[0].head_sha,source);assert.ok(jobs.filter(j=>j.name!=='prepare').length===3&&jobs.filter(j=>j.name!=='prepare').every(j=>j.conclusion==='skipped'));
assert.equal(metadata.total_count,2);assert.deepEqual(metadata.artifacts.map(a=>a.name).sort(),['github-pages','release-delivery']);
for(const a of metadata.artifacts){assert.equal(a.expired,false);assert.equal(a.workflow_run.id,run.id);assert.equal(a.workflow_run.head_sha,source);assert.equal(a.workflow_run.repository_id,run.repository.id);assert.equal('sha256:'+await fileSHA256(path.join(out,a.name+'.zip')),a.digest);assert.ok(Date.parse(a.created_at)>=Date.parse(prepare[0].started_at)&&Date.parse(a.created_at)<=Date.parse(prepare[0].completed_at));}
assert.equal(prepared.prepared,true);assert.equal(prepared.promotion,false);assert.equal(prepared.controllerSource,source);assert.equal(prepared.coreSource,source);
const actualTree=execFileSync('git',['rev-parse','HEAD^{tree}'],{cwd:root,encoding:'utf8',windowsHide:true}).trim();assert.equal(actualTree,tree);
const directory=path.join(out,'delivery'),manifestRaw=await readFile(path.join(directory,'release-manifest.json')),receiptRaw=await readFile(path.join(directory,'release-gates.json'));
const expected={source,build:prepared.buildId,manifest:sha256(manifestRaw),receipt:sha256(receiptRaw),zip:prepared.zipSHA256};
const checked=await validateDelivery(directory,expected),manifest=await verifyArtifact(path.join(out,'core'),{publicOnly:true,requireClean:true,expectedCommit:source});assert.deepEqual(manifest,checked.manifest);assert.equal(manifest.release.version,'1.2.0');assert.equal(manifest.release.source.tree,tree);assert.equal(manifest.files.length,322);
const receipt=checked.receipt;assert.equal(receipt.repository,'koviankevin/tflite-explorer');
const stable=value=>JSON.stringify(value,(_,v)=>v&&!Array.isArray(v)&&typeof v==='object'?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b))):v);
assert.equal(receipt.reproducibleManifestSHA256,sha256(Buffer.from(stable(manifest))));
const core=await load('font-main-core-reuse-review.json'),originalCore=await load('main-core-review.json');
const expectedGates={core:{run:core.run,source:core.testedSource,artifactId:originalCore.artifactId,providerDigest:core.providerDigest,reportSHA256:core.reportSHA256,scopeFingerprint:core.fingerprint,scopeFiles:core.files}};
for(const kind of ['browser','contract','site'])expectedGates[kind]=await load('font-main-'+kind+'-review.json');
assert.deepEqual(receipt.gates.map(g=>g.kind),['core','browser','contract','site']);
for(const g of receipt.gates){const e=expectedGates[g.kind];assert.equal(g.runId,e.run);assert.equal(g.testedCommit,e.source);assert.equal(g.artifactId,e.artifactId);assert.equal(g.artifactDigest,e.providerDigest);assert.equal(g.reportSHA256,e.reportSHA256);assert.equal(g.scopeFingerprint,e.scopeFingerprint);assert.equal(g.scopeFiles.length,e.scopeFiles);assert.equal(sha256(Buffer.from(stable(g.scopeFiles))),e.scopeFingerprint);assert.equal(g.reused,true);}
const site=await verifySite(path.join(out,'snapshot'),{publicOnly:true}),siteRaw=await readFile(path.join(out,'snapshot','site-manifest.json'));
assert.equal(site.siteId,prepared.siteId);assert.equal(sha256(siteRaw),prepared.siteManifestSHA256);assert.deepEqual(site.current.release,manifest.release);assert.equal(site.current.manifestSHA256,expected.manifest);assert.equal(site.legacyRoot.release.buildId,SITE_BASELINE.build);assert.equal(site.legacyRoot.release.source.commit,SITE_BASELINE.source);assert.equal(site.legacyRoot.manifestSHA256,BASELINE_MANIFEST_SHA256);assert.ok(site.retainedBuildIds.includes('9338194b51c14371'));
for(const item of prepared.history){if(item.kind==='github-release'){const ref=site.versions.find(v=>v.release.buildId===item.build);assert.ok(ref);assert.equal(ref.manifestSHA256,item.manifestSHA256);assert.equal(ref.release.source.commit,item.source);}}
const result={status:'passed-prepared-artifact-review',at:new Date().toISOString(),run:run.id,source,tree,buildId:prepared.buildId,siteId:site.siteId,siteManifestSHA256:prepared.siteManifestSHA256,expected,coreFiles:manifest.files.length,siteFiles:site.files.length+1,assets:checked.assets,artifacts:metadata.artifacts.map(a=>({id:a.id,name:a.name,bytes:a.size_in_bytes,digest:a.digest})),gates:receipt.gates.map(g=>({kind:g.kind,runId:g.runId,reused:g.reused,scopeFingerprint:g.scopeFingerprint})),retainedBuildIds:site.retainedBuildIds,legacyBuild:site.legacyRoot.release.buildId,readyForExactSourcePublish:true,published:false,goal:'active; Windows physical normal-close and other unverified requirements remain'};
await writeFile(path.join(q,'v1.2-prepared-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
