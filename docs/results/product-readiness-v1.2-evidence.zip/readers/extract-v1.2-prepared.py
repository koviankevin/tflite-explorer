import hashlib,json,pathlib,shutil,stat,tarfile,zipfile
q=pathlib.Path(__file__).resolve().parent;out=q/'v1.2-prepared-artifacts'
meta=json.loads((q/'v1.2-prepare-artifacts.json').read_bytes());prepared=json.loads((q/'v1.2-prepared-output.json').read_bytes())
assert meta['total_count']==2 and {a['name'] for a in meta['artifacts']}=={'github-pages','release-delivery'}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for a in meta['artifacts']:
 p=out/(a['name']+'.zip');assert p.stat().st_size==a['size_in_bytes'] and 'sha256:'+sha(p)==a['digest']
reserved={'CON','PRN','AUX','NUL'}|{'COM'+str(i) for i in range(1,10)}|{'LPT'+str(i) for i in range(1,10)}
def safe(name):
 assert name and not name.startswith('/') and '\\' not in name and ':' not in name and '\x00' not in name
 p=pathlib.PurePosixPath(name);assert '..' not in p.parts
 assert all(x not in ('','.') and not x.endswith(('.',' ')) and x.split('.')[0].upper() not in reserved for x in p.parts)
 return p
def unzip(archive,target,expected):
 assert not target.exists();target.mkdir()
 with zipfile.ZipFile(archive) as z:
  items=z.infolist();names=[i.filename for i in items]
  assert 0<len(items)<=1000 and len({n.casefold() for n in names})==len(names) and set(names)==set(expected)
  assert sum(i.file_size for i in items)<=512*1024**2 and z.testzip() is None
  for i in items:
   assert not i.is_dir() and stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG);safe(i.filename)
   if i.filename in ('release-manifest.json','release-gates.json'):assert i.file_size<=4*1024**2
   if i.filename.endswith('.sha256'):assert i.file_size<=1024
  for i in items:
   p=target/pathlib.Path(*safe(i.filename).parts);p.parent.mkdir(parents=True,exist_ok=True)
   with z.open(i) as src,p.open('xb') as dst:shutil.copyfileobj(src,dst,1024**2)
 return len(items)
zipname='model-lens-public-1.2.0-'+prepared['buildId']+'.zip'
delivery=out/'delivery';unzip(out/'release-delivery.zip',delivery,[zipname,zipname+'.sha256','release-manifest.json','release-gates.json'])
manifest=json.loads((delivery/'release-manifest.json').read_bytes());core=out/'core'
assert manifest['release']['source']['commit']==prepared['coreSource'] and manifest['release']['buildId']==prepared['buildId']
core_files=unzip(delivery/zipname,core,[x['path'] for x in manifest['files']]+['release-manifest.json'])
tarpath=out/'artifact.tar'
with zipfile.ZipFile(out/'github-pages.zip') as z:
 assert z.namelist()==['artifact.tar'] and z.testzip() is None and z.getinfo('artifact.tar').file_size<=528*1024**2
 with z.open('artifact.tar') as src,tarpath.open('xb') as dst:shutil.copyfileobj(src,dst,1024**2)
snapshot=out/'snapshot';assert not snapshot.exists();snapshot.mkdir()
with tarfile.open(tarpath,'r:') as t:
 members=t.getmembers();assert len(members)<=8192;names=set();total=0
 for m in members:
  assert m.isdir() or m.isfile()
  if m.name in ('.','./'):assert m.isdir();continue
  n=safe(m.name);key=str(n).casefold();assert key not in names;names.add(key)
  total+=m.size if m.isfile() else 0
 assert total<=512*1024**2
 for m in members:
  if m.name in ('.','./'):continue
  p=snapshot/pathlib.Path(*safe(m.name).parts)
  assert p.resolve().is_relative_to(snapshot.resolve())
  if m.isdir():p.mkdir(parents=True,exist_ok=True)
  else:
   p.parent.mkdir(parents=True,exist_ok=True)
   with t.extractfile(m) as src,p.open('xb') as dst:shutil.copyfileobj(src,dst,1024**2)
result=dict(status='bounded-extraction-passed',source=prepared['coreSource'],build=prepared['buildId'],siteId=prepared['siteId'],coreZipEntries=core_files,snapshotTarEntries=len(members),snapshotPayloadBytes=total)
(q/'v1.2-prepared-extraction.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result),flush=True)
