import {assertStableCoverage101} from './assert-stable-coverage101.mjs';
import {assertWorkspaceStorage34} from './assert-workspace-storage34.mjs';
import {assertStartupRecovery33} from './assert-startup-recovery33.mjs';
import {assertRuntimeModule32} from './assert-runtime-module32.mjs';
import {assertRuntimeIOChromium30} from './assert-runtime-io-chromium32.mjs';
import {assertActiveCompute31} from './assert-active-compute31.mjs';
import {assertRuntimeIO31} from './assert-runtime-io31.mjs';
import {assertInputCleanup31} from './assert-input-cleanup31.mjs';
import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {gitSource,sha256,verifyArtifact} from '../../scripts/lib/release-artifact.mjs';
import {assertReport} from '../../scripts/lib/release-gates.mjs';
const [id,head,build,label='final']=process.argv.slice(2),source=gitSource();assert.match(id,/^\d+$/);assert.match(head,/^[a-f0-9]{40}$/);assert.match(label,/^[a-z0-9-]+$/);assert.equal(source.commit,head);assert.equal(source.dirty,false);
const built=await verifyArtifact(build,{publicOnly:true,expectedCommit:head,requireClean:true});assert.deepEqual(built.release.source,source);assert.equal(built.release.version,'1.1.0');
const call=(route,binary=false)=>execFileSync(process.env.GH_BIN,['api','repos/koviankevin/tflite-explorer/'+route],{encoding:binary?undefined:'utf8',maxBuffer:8*1024**2,windowsHide:true,timeout:60000}),json=route=>JSON.parse(call(route));
const run=json(`actions/runs/${id}`),jobs=json(`actions/runs/${id}/attempts/1/jobs?per_page=100`),listing=json(`actions/runs/${id}/artifacts?per_page=100`);
assert.equal(run.status,'completed');assert.ok(['success','failure'].includes(run.conclusion));assert.equal(run.run_attempt,1);assert.equal(run.path,'.github/workflows/production-smoke.yml');assert.equal(run.head_branch,'main');assert.equal(run.head_sha,head);assert.equal(run.event,'workflow_dispatch');assert.equal(run.head_repository.full_name,'koviankevin/tflite-explorer');assert.equal(jobs.total_count,jobs.jobs.length);assert.equal(listing.total_count,listing.artifacts.length);
const job=jobs.jobs.find(j=>j.name==='site-upgrade');assert.equal(job.status,'completed');assert.equal(job.run_attempt,1);assert.equal(job.head_sha,head);
const directory=`build/qa/model-safety-native-main-${id}-${label}`;await mkdir(directory);for(const [name,value]of Object.entries({run,jobs,listing}))await writeFile(`${directory}/${name}.json`,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
async function archive(name,stem,jsonName){
 const matches=listing.artifacts.filter(a=>a.name===name);assert.equal(matches.length,1);const artifact=matches[0];assert.equal(artifact.expired,false);assert.equal(artifact.workflow_run.id,Number(id));assert.equal(artifact.workflow_run.head_sha,head);assert.ok(artifact.size_in_bytes>0&&artifact.size_in_bytes<=4*1024**2);assert.ok(Date.parse(artifact.created_at)>=Date.parse(job.started_at)&&Date.parse(artifact.created_at)<=Date.parse(job.completed_at)+1000);
 const bytes=call(`actions/artifacts/${artifact.id}/zip`,true);assert.equal(bytes.length,artifact.size_in_bytes);assert.equal('sha256:'+sha256(bytes),artifact.digest);await writeFile(`${directory}/${stem}.zip`,bytes,{flag:'wx'});await writeFile(`${directory}/${stem}-artifact.json`,JSON.stringify(artifact,null,2)+'\n',{flag:'wx'});
 const allowed=[jsonName,jsonName.replace(/\.json$/,'.png')],py=`import io,sys,json,zipfile,hashlib,pathlib
z=zipfile.ZipFile(io.BytesIO(sys.stdin.buffer.read()));items=z.infolist();allowed=${JSON.stringify(allowed)}
assert 1<=len(items)<=2 and len(set(z.namelist()))==len(items) and ${JSON.stringify(jsonName)} in z.namelist()
assert set(z.namelist())<=set(allowed)
assert all(0<i.file_size<=4*1024**2 and not i.is_dir() for i in items)
assert z.testzip() is None
rows=[]
for i in items:
 b=z.read(i)
 with open(pathlib.Path(sys.argv[1])/i.filename,'xb') as f:f.write(b)
 rows.append({'name':i.filename,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
print(json.dumps(rows))`;
 const members=JSON.parse(execFileSync(process.env.PYTHON_BIN,['-I','-c',py,directory],{input:bytes,encoding:'utf8',maxBuffer:4*1024**2,windowsHide:true}));return {artifact,members,report:JSON.parse(await readFile(`${directory}/${jsonName}`,'utf8'))};
}
const site=await archive(`versioned-site-browser-${head}-1`,'site','versioned-site-browser.json');assertReport(site.report,'site',run,source.tree);assert.equal(site.report.sourceUnchanged,true);
const native=await archive(`versioned-delivery-smoke-${head}-1`,'native','production-smoke.json'),r=native.report;
assert.equal(r.driverSourceCommit,head);assert.deepEqual(r.siteRelease,built.release);assert.equal(r.expectedBuild,built.release.buildId);assert.equal(r.target,'isolated-versioned-snapshot');assert.equal(r.status==='passed'?'success':'failure',job.conclusion);assert.deepEqual(r.errors,[]);

const modelURL=new URL(r.workers.find(w=>/\/model-worker\.js(?:\?|$)/.test(w.url)).url);assert.equal(modelURL.protocol,'http:');assert.equal(modelURL.hostname,'127.0.0.1');assert.match(modelURL.port,/^\d+$/);const workerBase=modelURL.origin+'/tflite-explorer/versions/'+built.release.buildId+'/src/';assert.equal(modelURL.href,workerBase+'model-worker.js?v='+built.release.buildId);assert.equal(r.siteId,site.report.snapshots[1].siteId);assert.equal(r.staticVerification.status,'passed');assert.equal(r.staticVerification.siteId,r.siteId);assert.equal(r.staticVerification.files,site.report.snapshots[1].files);
const core=assertRuntimeIOChromium30(r,{release:built.release,runtimePrefix:modelURL.origin+'/tflite-explorer/versions/'+built.release.buildId+'/vendor/litert/2.6.0/'}),active=await assertActiveCompute31(r,{workerBase}),lifecycle=await assertRuntimeIO31(r,{workerBase}),cleanup=assertInputCleanup31(r,true);const models=r.workers.filter(w=>/\/model-worker\.js(?:\?|$)/.test(w.url)),runtimes=r.workers.filter(w=>/\/tflite-runtime-worker\.js(?:\?|$)/.test(w.url)),t=r.tfliteRuntime;
const moduleProof=await assertRuntimeModule32({...r,base:modelURL.origin+'/tflite-explorer/',staticVerification:{checks:built.files}});
assert.equal(r.runtimeIOTransferRequired,true);const retained=r.retainedRuntimeInputs;assert.equal(retained.format,'model-lens-retained-runtime-input');assert.equal(retained.version,1);assert.equal(retained.status,'passed');assert.equal(retained.contextClosed,true);assert.equal(retained.downloads,0);assert.deepEqual(retained.errors,[]);assert.deepEqual(retained.cases.map(c=>c.action),['confirm','cancel']);for(const c of retained.cases){assert.deepEqual(c.before,{connected:true,type:'file',files:1,valueEmpty:false});assert.deepEqual(c.after,{connected:false,type:'file',files:0,valueEmpty:true});}assert.equal(retained.workers.filter(w=>w.kind==='model').length,1);assert.equal(retained.workers.filter(w=>w.kind==='runtime').length,1);assert.ok(retained.workers.every(w=>w.closed));
const startup=await assertStartupRecovery33(r,{base:modelURL.origin+'/tflite-explorer/',buildId:built.release.buildId,screenshotPath:directory+'/startup-failure.png'});const workspaceStorage=await assertWorkspaceStorage34(r,{base:modelURL.origin+'/tflite-explorer/',buildId:built.release.buildId,screenshotPath:directory+'/storage-failure.png'});const stableCoverage=assertStableCoverage101(r);assert.deepEqual(gitSource(),source);const review={authentication:'passed',acceptance:'passed',source,sourceUnchanged:true,runId:Number(id),attempt:1,jobId:job.id,release:built.release,site:{artifact:site.artifact,members:site.members,checks:site.report.checks,status:site.report.status},native:{stableCoverage,workspaceStorage,startup,moduleProof,retained,artifact:native.artifact,members:native.members,status:r.status,checks:r.checks,modelWorkers:models.length,runtimeWorkers:runtimes.length,runtime:t,demo:r.demoRuntime,core,active,lifecycle,cleanup},scope:'Hosted Chromium public synthetic candidate; original/edit/composition/slice reopen then run exact opened bytes, native input choosers/downloads, cancellation and 1280/1366 desktop; not production acceptance'};
await writeFile(directory+'/review.json',JSON.stringify(review,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({directory,authentication:'passed',acceptance:'passed',source,build:built.release.buildId,siteChecks:site.report.checks.length,checks:r.checks.length,modelWorkers:models.length,runtimeWorkers:runtimes.length,runtimeCases:t.cases}));
