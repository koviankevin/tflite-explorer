import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';
import path from 'node:path';
import {gitSource,sha256} from '../../scripts/lib/release-artifact.mjs';
import {HEX_MIB,SOURCE_BYTES,SOURCE_SHA256,PAYLOAD_SHA256,requirements,resourceShortfalls} from '../../scripts/large-mlir-resources.mjs';
import {parsePatternFile,exportPatterns} from '../../src/pattern-library.js';
import {parseMLIRFile} from '../../src/mlir-engine.js';
import {captureMLIRPattern} from '../../src/mlir-pattern.js';

const [id,head,label='final']=process.argv.slice(2);assert.match(id,/^\d+$/);assert.match(head,/^[a-f0-9]{40}$/);assert.match(label,/^[a-z0-9-]+$/);
const source=gitSource();assert.equal(source.commit,head);assert.equal(source.dirty,false);
const call=(route,binary=false)=>execFileSync(process.env.GH_BIN,['api','repos/koviankevin/tflite-explorer/'+route],{encoding:binary?undefined:'utf8',maxBuffer:16*1024**2,timeout:60000,windowsHide:true});
const json=route=>JSON.parse(call(route));
const run=json(`actions/runs/${id}`),commit=json(`git/commits/${head}`),jobs=json(`actions/runs/${id}/attempts/1/jobs?per_page=100`),listing=json(`actions/runs/${id}/artifacts?per_page=100`);
assert.equal(commit.sha,head);assert.equal(commit.tree.sha,source.tree);
assert.equal(run.status,'completed');assert.equal(run.conclusion,'success');assert.equal(run.run_attempt,1);assert.equal(run.path,'.github/workflows/large-mlir.yml');assert.equal(run.head_sha,head);assert.equal(run.head_branch,'main');assert.equal(run.event,'workflow_dispatch');assert.equal(run.head_repository.full_name,'koviankevin/tflite-explorer');
assert.equal(jobs.total_count,1);assert.equal(jobs.jobs.length,1);assert.equal(listing.total_count,listing.artifacts.length);
const job=jobs.jobs[0];assert.equal(job.name,'large-mlir');assert.equal(job.status,'completed');assert.equal(job.conclusion,'success');assert.equal(job.head_sha,head);assert.equal(job.run_attempt,1);assert.ok(job.labels.includes('ubuntu-24.04'));
assert.equal(job.steps.find(s=>s.name==='Generate, verify and audit physical 2.5 GiB MLIR')?.conclusion,'success');
const matches=listing.artifacts.filter(a=>a.name===`large-mlir-node-${head}-1`);assert.equal(matches.length,1);const artifact=matches[0];assert.equal(artifact.expired,false);assert.equal(artifact.workflow_run.id,Number(id));assert.equal(artifact.workflow_run.head_sha,head);assert.match(artifact.digest,/^sha256:[a-f0-9]{64}$/);assert.ok(Date.parse(artifact.created_at)>=Date.parse(job.started_at)&&Date.parse(artifact.created_at)<=Date.parse(job.completed_at)+1000);
const bytes=call(`actions/artifacts/${artifact.id}/zip`,true);assert.equal(bytes.length,artifact.size_in_bytes);assert.equal('sha256:'+sha256(bytes),artifact.digest);
const expected=['acceptance-report.json','fixture.json','node-report.json','plan.json','events.jsonl','branch-loop-pattern.json'].sort();
const py=`import io,sys,json,zipfile,base64
z=zipfile.ZipFile(io.BytesIO(sys.stdin.buffer.read()))
items=z.infolist()
expected=${JSON.stringify(expected)}
assert sorted(i.filename for i in items)==expected
assert len(items)==len(expected)
assert all(0<i.file_size<=2*1024**2 and not i.is_dir() and not(i.flag_bits&1) for i in items)
assert sum(i.file_size for i in items)<=4*1024**2
assert z.testzip() is None
print(json.dumps({i.filename:base64.b64encode(z.read(i)).decode('ascii') for i in items}))`;
const encoded=JSON.parse(execFileSync(process.env.PYTHON_BIN,['-I','-c',py],{input:bytes,maxBuffer:8*1024**2,windowsHide:true}));
const members=Object.fromEntries(Object.entries(encoded).map(([name,b64])=>[name,Buffer.from(b64,'base64')]));
const read=name=>JSON.parse(members[name].toString('utf8'));
const report=read('acceptance-report.json'),fixture=read('fixture.json'),v=read('node-report.json'),plan=read('plan.json');
assert.equal(report.schemaVersion,1);assert.equal(report.status,'passed');assert.equal(report.sourceCommit,head);assert.equal(report.workingTreeDirty,false);assert.deepEqual(report.requested,{hexMiB:HEX_MIB,sourceBytes:SOURCE_BYTES});assert.deepEqual(report.requirements,requirements);assert.deepEqual(resourceShortfalls(report.preflight),[]);
assert.equal(report.environment.platform,'linux');assert.equal(report.environment.arch,'x64');assert.match(report.environment.node,/^v24\.\d+\.\d+$/);assert.equal(report.environment.repository,'koviankevin/tflite-explorer');assert.equal(report.environment.ref,'refs/heads/main');assert.equal(report.environment.workflowCommit,head);assert.equal(report.environment.runId,id);assert.equal(report.environment.runAttempt,'1');
assert.ok(Date.parse(report.startedAt)>=Date.parse(job.started_at)&&Date.parse(report.finishedAt)<=Date.parse(job.completed_at)+1000&&Date.parse(report.finishedAt)>Date.parse(report.startedAt));
assert.deepEqual(report.fixture,fixture);assert.deepEqual(report.verification,v);assert.equal(fixture.bytes,SOURCE_BYTES);assert.equal(fixture.sha256,SOURCE_SHA256);assert.equal(fixture.payloadSha256,PAYLOAD_SHA256);assert.equal(fixture.payloadBytes,HEX_MIB*1024**2+4);assert.equal(plan.hexMiB,HEX_MIB);
assert.equal(v.stats.denseValidation.checked,1);assert.equal(v.stats.denseValidation.unchecked,0);assert.equal(v.source,fixture.file);assert.equal(v.sourceBytes,SOURCE_BYTES);assert.equal(v.stats.fileBytes,SOURCE_BYTES);assert.equal(v.stats.bytesRead,SOURCE_BYTES);assert.equal(v.stats.deferredPayloads,1);assert.equal(v.stats.deferredBytes,HEX_MIB*1024**2+4);assert.ok(v.stats.structureBytes>0&&v.stats.structureBytes<1024**2);assert.ok(Number.isSafeInteger(v.outputBytes)&&v.outputBytes>=SOURCE_BYTES);assert.equal(v.patternMatches,1);assert.equal(v.reopenedPatternMatches,1);assert.equal(v.ssaDominance,true);assert.equal(v.payloadSha256,PAYLOAD_SHA256);assert.equal(v.originalPayloadSha256,PAYLOAD_SHA256);assert.equal(v.node,report.environment.node);
assert.deepEqual(report.files.source,{bytes:SOURCE_BYTES,sha256:SOURCE_SHA256});assert.equal(report.files.output.bytes,v.outputBytes);assert.match(report.files.output.sha256,/^[a-f0-9]{64}$/);
assert.equal(report.stages.length,2);for(const [i,s]of report.stages.entries()){assert.equal(s.name,['large-mlir-fixture.mjs','verify-large-mlir.mjs'][i]);assert.equal(s.code,0);assert.equal(s.signal,null);assert.equal(s.stderr,'');assert.ok(s.elapsedMs>0);const r=i?v:fixture;assert.equal(s.measurement.maxRSS,r.maxRSS);assert.equal(s.measurement.totalMs,r.totalMs);assert.ok(Number.isSafeInteger(r.maxRSS)&&r.maxRSS>0);assert.ok(r.totalMs>0);}
// CFG patterns contain selected operators plus block/argument structure. The
// first review incorrectly counted all structural nodes as selected operators.
const patterns=parsePatternFile(members['branch-loop-pattern.json'].toString('utf8'));assert.equal(patterns.length,1);assert.equal(patterns[0].nodes.filter(n=>n.kind==='operator').length,5);assert.equal(patterns[0].nodes.filter(n=>n.kind==='block').length,5);assert.equal(patterns[0].nodes.filter(n=>n.kind==='argument').length,4);assert.equal(patterns[0].nodes.length,14);
const generator=await readFile('scripts/large-mlir-fixture.mjs','utf8'),start=generator.indexOf('const name='),end=generator.indexOf('const plan=');assert.ok(start>0&&end>start);
const small=runInNewContext(generator.slice(start,end)+'\nhead+"1"+tail',{hexMiB:HEX_MIB,path,directory:'/synthetic-fixture'},{timeout:1000});assert.ok(Buffer.byteLength(small)<1024**2);
const smallIndex=await parseMLIRFile(new Blob([small]),{identifier:'large.mlir',metadata:await readFile('vendor/netron/mlir-metadata.json','utf8')});
const expectedPattern={name:'大型權重分支迴圈',...captureMLIRPattern(smallIndex,[0,1,2,3,4].map(graph=>({graph,nodes:[0]})))};assert.deepEqual(patterns,parsePatternFile(exportPatterns([expectedPattern])));
const events=members['events.jsonl'].toString('utf8').trim().split('\n').map(line=>JSON.parse(line));assert.ok(events.some(e=>e.operation_id==='generate'&&e.event==='created'&&e.sha256===SOURCE_SHA256));assert.ok(events.some(e=>e.operation_id==='export'&&e.event==='verified'&&e.ssaDominance===true&&e.payloadSha256===PAYLOAD_SHA256));
assert.deepEqual(gitSource(),source);
const directory=`build/qa/large-mlir-${id}-${label}`;await mkdir(directory);await writeFile(directory+'/artifact.zip',bytes,{flag:'wx'});for(const [name,value]of Object.entries(members))await writeFile(directory+'/'+name,value,{flag:'wx'});for(const [name,value]of Object.entries({run,jobs,artifact,commit}))await writeFile(`${directory}/${name}.json`,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const review={authentication:'passed',acceptance:'passed',source,sourceUnchanged:true,runId:Number(id),attempt:1,jobId:job.id,artifactId:artifact.id,digest:artifact.digest,members:Object.entries(members).map(([name,b])=>({name,bytes:b.length,sha256:sha256(b)})),node:report.environment.node,sourceBytes:SOURCE_BYTES,sourceSHA256:SOURCE_SHA256,outputBytes:v.outputBytes,outputSHA256:report.files.output.sha256,payloadSHA256:PAYLOAD_SHA256,patternMatches:v.patternMatches,reopenedPatternMatches:v.reopenedPatternMatches,ssaDominance:true,denseValidation:v.stats.denseValidation,structureBytes:v.stats.structureBytes,openMs:v.openMs,totalMs:v.totalMs,maxRSS:v.maxRSS,limitations:['Node physical synthetic file only; no browser/process/Worker memory measurement','Project syntax/SSA/dominance checks, no full LLVM/dialect/native compiler verification','No private company models or runtime acceptance']};
await writeFile(directory+'/review.json',JSON.stringify(review,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({directory,...review}));
