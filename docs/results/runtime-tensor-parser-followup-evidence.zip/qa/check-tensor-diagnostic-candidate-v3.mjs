import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
import {verifyArtifact,gitSource} from '../../../scripts/lib/release-artifact.mjs';
const q=new URL('./',import.meta.url),site=new URL('candidate-site-v3/',q),source=gitSource();
assert.equal(source.commit,'bad7a726c743100ba2365f04407c802946e1fed8');assert.equal(source.dirty,false);
const artifact=await verifyArtifact(fileURLToPath(site),{publicOnly:true,requireClean:true,expectedCommit:source.commit});assert.equal(artifact.release.buildId,'f4a92b2cc2c2f632');
const [{parseModel},{editTfliteModel},{exportTflite},{editWorkspaceSnapshot,exportEditWorkspace},{modelEditDraft},{validateTfliteConstants},{captureGraphPattern,prepareGraphPattern,findSubgraphPatterns},{executeRuntime},{runtimePlan,runtimeSummary}]=await Promise.all([
    'model-engine.js','tflite-model-edit.js','tflite-export.js','model-edit-workspace.js','model-edit-draft.js','tflite-constant-checks.js','subgraph-pattern.js','tflite-runtime-execute.js','tflite-runtime-policy.js'
].map(name=>import(new URL('src/'+name,site))));
const output=new URL('negative-after-v3/',q);await mkdir(output);
const manifest=JSON.parse(await readFile(new URL('manifest.json',q),'utf8')),metadata=JSON.parse(await readFile(new URL('vendor/netron/tflite-metadata.json',site),'utf8'));
const raw=new Uint8Array(await readFile(new URL('person_detect.tflite',q))),sha=b=>createHash('sha256').update(b).digest('hex');assert.equal(sha(raw),manifest.files[0].sha256);
const file=new File([raw],'person_detect.tflite'),parse=b=>parseModel((o,n)=>b.subarray(o,o+n),b.length,metadata),index=await parse(raw),g=index.raw.subgraphs[0];
const base=new URL('vendor/litert/2.6.0/',site),diagnostics=[];globalThis.self=globalThis;globalThis.require=createRequire(import.meta.url);globalThis.__dirname=fileURLToPath(base);
globalThis.importScripts=url=>vm.runInThisContext(readFileSync(new URL(url),'utf8'),{filename:fileURLToPath(url)});
globalThis.Module={locateFile:name=>fileURLToPath(new URL(name,base)),printErr:s=>{diagnostics.push(String(s));if(diagnostics.length>12)diagnostics.shift();}};
const rt=await import(new URL('core.js',base));let loaded=false;
const norm=x=>JSON.parse(JSON.stringify(x,(_,v)=>typeof v==='bigint'?String(v):ArrayBuffer.isView(v)?Array.from(v):v));
const tensor=t=>norm({name:t.name,type:t.type,shape:t.shape,shape_signature:t.shape_signature,has_rank:t.has_rank,quantization:t.quantization,sparsity:t.sparsity,is_variable:t.is_variable});
const payload=(m,b,t)=>{const p=m.buffers[t.buffer];return p.size?b.subarray(Number(p.offset),Number(p.offset+p.size)):new Uint8Array(p.data||[]);};
const report={status:'failed',format:'model-lens-public-tensor-diagnostics-candidate',source,release:artifact.release,startedAt:new Date().toISOString(),phase:'setup',variants:[],runtime:[],
    scope:'The unmodified public original remains CPU-incompatible; success here means diagnostic regression and structural/data preservation, not inference/accuracy/equivalence. Manual QA, existing CPU WASM, no browser/private model or policy change.'};
try{
    const selected=[0,1,2],all=g.operators.map((_,i)=>i),pattern=captureGraphPattern(index.graphs[0],selected),spec={...prepareGraphPattern(pattern.nodes,pattern.edges),induced:true};
    const initial=await findSubgraphPatterns(index,spec);assert.equal(initial.truncated,false);assert.equal(initial.items.length,1);
    await rt.loadLiteRt(new URL('litert_wasm_compat_internal.js',base).href);loaded=true;
    const run=async(label,model,blob,spec={mode:'zero'})=>{
        report.phase='CPU-negative-'+label;diagnostics.length=0;const plan=runtimePlan(model,blob.size);assert.equal(plan.eligible,true,plan.reason);
        const result=await executeRuntime({blob,plan,rt,specs:[spec],diagnostics:()=>diagnostics});
        assert.equal(result.status,'failed');assert.equal(result.stage,'compile');assert.equal(result.compiled,false);assert.equal(result.invoked,false);assert.equal(result.io,undefined);
        assert.match(result.reason,/套用測試輸入之前/);assert.ok(result.failureLocations.length>0);
        for(const location of result.failureLocations){
            assert.equal(location.kind,'tensor');assert.equal(location.unique,false);assert.ok(location.candidates.length>0);
            for(const candidate of location.candidates){const op=model.subgraphs[candidate.graph].operators[candidate.node];assert.ok(op.inputs.includes(location.tensor)||op.outputs.includes(location.tensor));}
        }
        assert.match(runtimeSummary(result),/tensor #\d+.*使用者.*Subgraph #0 · OP #/s);
        report.runtime.push({label,inputMode:spec.mode,...result});
    };
    await run('original-zero',index.raw,file);
    const bytes=new Uint8Array(await readFile(new URL('person.bin',q)));assert.equal(sha(bytes),manifest.inputs[0].sha256);
    await run('original-raw-bin',index.raw,file,{mode:'bin',file:new File([bytes],'person.bin')});
    const targets=all.map(node=>({graph:0,node})),snapshot=editWorkspaceSnapshot(index,{targets,composition:true}),draft=modelEditDraft(snapshot);
    draft.apply({kind:'import',node:'op:0:0',nodes:all.map(n=>'op:0:'+n),label:'official unmodified public network'});
    const names=new Map(g.tensors.map((t,i)=>[t.name,i]));assert.equal(names.size,g.tensors.length);
    for(const label of ['identity','full-cut','composition','prefix-cut']){
        report.phase='export-'+label;
        const result=label==='identity'?editTfliteModel(index,file,[{graph:0}]):label==='composition'?await exportEditWorkspace(index,file,snapshot,draft.commands):exportTflite(index,0,label==='prefix-cut'?selected:all,file);
        const bytes=new Uint8Array(await result.blob.arrayBuffer()),reopened=await parse(bytes),candidate=reopened.raw.subgraphs[0],nodes=label==='prefix-cut'?selected:all;
        assert.equal(candidate.operators.length,nodes.length);const weights=[];
        for(const [id,t]of candidate.tensors.entries()){
            const before=g.tensors[names.get(t.name)];assert.ok(before);assert.deepEqual(tensor(t),tensor(before));
            const a=payload(index.raw,raw,before),b=payload(reopened.raw,bytes,t);assert.deepEqual(b,a);if(a.length)weights.push({tensor:id,sourceTensor:names.get(t.name),bytes:a.length,sha256:sha(a)});
        }
        const ports=(graph,ids)=>Array.from(ids,id=>id<0?null:graph.tensors[id].name);
        for(const [id,op]of candidate.operators.entries()){
            const before=g.operators[nodes[id]];
            assert.deepEqual(norm(reopened.raw.operator_codes[op.opcode_index]),norm(index.raw.operator_codes[before.opcode_index]));
            assert.deepEqual(norm(op.builtin_options),norm(before.builtin_options));assert.deepEqual(norm(op.builtin_options_2),norm(before.builtin_options_2));
            assert.deepEqual(ports(candidate,op.inputs),ports(g,before.inputs));assert.deepEqual(ports(candidate,op.outputs),ports(g,before.outputs));
        }
        const matches=await findSubgraphPatterns(reopened,spec);assert.equal(matches.truncated,false);assert.equal(matches.items.length,1);
        const constants=validateTfliteConstants(reopened.raw,0,(o,n)=>bytes.subarray(o,o+n));
        const name=label+'.tflite';await writeFile(new URL(name,output),bytes,{flag:'wx'});
        report.variants.push({label,file:name,bytes:bytes.length,sha256:sha(bytes),operators:candidate.operators.length,weights,metadataPreserved:true,connectionsAndOptionsPreserved:true,patternMatches:matches.items.length,constants});
        await run(label,reopened.raw,result.blob);
    }
    assert.deepEqual(gitSource(),source);report.sourceUnchanged=true;report.phase='complete';report.status='diagnostic-regression-and-preservation-passed-original-CPU-still-rejected';
}catch(error){report.error=error.stack||String(error);process.exitCode=1;}
finally{if(loaded)rt.unloadLiteRt();report.finishedAt=new Date().toISOString();await writeFile(new URL('report.json',output),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
    console.log(JSON.stringify({status:report.status,phase:report.phase,runtimeCases:report.runtime.length,variants:report.variants.map(v=>({label:v.label,operators:v.operators,bytes:v.bytes})),error:report.error}));}
