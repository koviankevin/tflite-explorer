import datetime,hashlib,json,pathlib,zipfile
q=pathlib.Path(__file__).resolve().parent;repo=q.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
proof=json.loads((q/'parser-followup-reuse-review.json').read_bytes());assert proof['knownFailureLocationsAndReasonsIdentical']
members={};records=[]
for name in ['parser-followup-plan.json','parser-followup-reuse-review.json','mixed-tensor-log-red.json','mixed-tensor-log-green.json',
             'check-tensor-diagnostic-candidate-v3.mjs','negative-after-v3/report.json','negative-after-v3/process-result.json','archive-parser-followup.py']:
    data=(q/name).read_bytes();members['qa/'+name]=data;records.append({'path':'qa/'+name,'bytes':len(data),'sha256':sha(data),'modified':False})
for name in ['src/tflite-runtime-diagnostics.js','test/tflite-runtime-diagnostics.test.mjs','LICENSE']:
    data=(repo/name).read_bytes();members['source/'+name]=data;records.append({'path':'source/'+name,'bytes':len(data),'sha256':sha(data),'modified':False})
manifest={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'evidenceModified':False,
          'scope':'Only stricter explicit-failure grammar differs in src/vendor from0537. Actual six CPU negative reference/reason objects and all serialized variants equal prior evidence. UI/transport/runtime/CSS unchanged; reuse recorded0537 Windows UI, no new Windows run claimed. Raw model/input bytes remain local.'}
members['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=repo/'docs/results/runtime-tensor-parser-followup-evidence.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    for r in records:assert sha(z.read(r['path']))==r['sha256']
receipt={**proof,'status':'parser-guard-targeted-and-component-reuse-evidence-reviewed-not-published',
         'archive':{'file':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'members':len(members),
                    'originalRecords':len(records),'manifestSHA256':sha(members['manifest.json']),'crc':'passed','allRecordedSHA256':'passed'},
         'published':False,'goalComplete':False}
out=repo/'docs/results/runtime-tensor-parser-followup.json';assert not out.exists();out.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':receipt['status'],'archive':receipt['archive']}))
