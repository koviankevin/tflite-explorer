from pathlib import Path
import json,hashlib,zipfile,re,datetime
q=Path(__file__).resolve().parent
repo=q.parents[3]/'tflite-explorer-transpose'
# q is original/build/qa/op-validation; the sibling checkout is under Tflite.
repo=q.parents[3]/'tflite-explorer-transpose'
if not repo.exists():
    repo=Path(r'D:\Users\kovia\OneDrive\文件\ChatGPT\Tflite\tflite-explorer-transpose')
out=repo/'docs/results/operator-validation-candidate-evidence.zip'
receipt=repo/'docs/results/operator-validation-candidate.json'
assert not out.exists() and not receipt.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
chrome=json.loads((q/'chrome-2/report.json').read_text(encoding='utf-8'))
edge=json.loads((q/'msedge-2/report.json').read_text(encoding='utf-8'))
assert chrome['functionalStatus']=='passed' and chrome['status']=='failed' and 'normal browser.close exceeded10s' in chrome['error']
assert edge['status']=='passed' and edge['browserClosed'] and edge['processCleanup']['allReaped'] and not edge['processCleanup']['remaining']
assert chrome['source']==edge['source'] and chrome['source']['commit']=='54a8b6a3efa58db38a0499b83bea85377d4ff5a1' and not chrome['source']['dirty']
for report in [chrome,edge]:
    assert report['release']['buildId']=='d0c7296728a41a1b'
    assert report['flow']['modelWorkers']==4 and report['flow']['automaticRuntimeWorkers']==0
    assert [(c['name'],c['status']) for c in report['flow']['cases']]==[('SPLIT','passed'),('PAD','not-run'),('SLICE','rejected')]
    assert all(w['closed'] for w in report['workers']) and not report['errors']
    for case in report['flow']['cases'][:2]:
        assert case['layout']['width']==1280 and case['layout']['documentWidth']==1280
    assert report['flow']['cases'][2]['downloads']==0
for folder in ['chrome-2','msedge-2']:
    for name in ['SPLIT','PAD']:
        body=(q/folder/f'operand-{name}-edited.tflite').read_bytes()
        r=json.loads((q/folder/f'operand-{name}.report.json').read_text(encoding='utf-8'))
        assert len(r['operatorValidation'])==2
        assert all(c['status']==('passed' if name=='SPLIT' else 'not-run') for c in r['operatorValidation'])
        c=next(c for c in (chrome if folder=='chrome-2' else edge)['flow']['cases'] if c['name']==name)
        assert sha(body)==c['outputSHA256']
        source=(q/folder/f'operand-{name}-source.tflite').read_bytes()
        for segment in r['provenance']['ranges']:
            a,b,n=segment['sourceOffset'],segment['outputOffset'],segment['bytes']
            assert source[a:a+n]==body[b:b+n] and len(body[b:b+n])==n
log=(q/'targeted.log').read_text(encoding='utf-8')
assert re.search(r'tests 136\b',log) and re.search(r'pass 136\b',log) and re.search(r'fail 0\b',log)
members=[]
for name in ['plan.json','native-plan.json','native-plan-2.json','baseline-red.log','first-checks.log','boundaries.log','runtime-report.log','split-ports-fixed.log','targeted.log','chrome-1.log','chrome-2.log','msedge-2.log','archive-candidate.py']:
    p=q/name;assert p.is_file();members.append((name,p))
for folder in ['chrome-1','chrome-2','msedge-2','upstream']:
    for p in sorted((q/folder).iterdir()):
        assert p.is_file() and not p.is_symlink();members.append((folder+'/'+p.name,p))
rows=[]
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in members:
        b=p.read_bytes();z.writestr(name,b);rows.append({'path':name,'bytes':len(b),'sha256':sha(b)})
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None and z.namelist()==[r['path'] for r in rows]
    for r in rows: assert sha(z.read(r['path']))==r['sha256']
r={'format':'model-lens-operator-validation-candidate','status':'reviewed-mixed-native-results-not-published','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':edge['source'],'release':edge['release'],'targetedTests':{'passed':136,'failed':0,'scope':'semantic, serialized operands, report, editing, composition, shape inference, release-feature selection; source changes since this log only editor report entry and browser driver'},'cpuCases':14,'browsers':{'chrome':{'functional':'passed','normalClose':'failed-10s','wholeAttempt':'failed','workersClosed':len(chrome['workers'])},'msedge':{'functional':'passed','normalClose':'passed','wholeAttempt':'passed','workersClosed':len(edge['workers'])}},'archive':{'file':out.name,'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'members':rows},'limitations':['No formal deployment yet.','Chrome SDK forced cleanup is not normal-close success.','Other kernels, unknown constants, custom execution and numerical equivalence remain unverified.','No company, mobile, Firefox/WebKit, new two-hour soak or private data.']}
receipt.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':r['status'],'archiveBytes':out.stat().st_size,'members':len(rows),'sha256':r['archive']['sha256']},ensure_ascii=False))
