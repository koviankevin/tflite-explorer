import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {parseModel} from '../../../src/model-engine.js';
import {editTfliteModel} from '../../../src/tflite-model-edit.js';
import {exportTflite} from '../../../src/tflite-export.js';
import {createModelEditReport} from '../../../src/model-edit-report.js';
import {createExportReport} from '../../../src/export-report.js';
import {inspectTfliteQuantization} from '../../../src/tflite-quantization-checks.js';
import {checkBuiltinPorts} from '../../../src/tflite-new-ops.js';
import {gitSource} from '../../../scripts/lib/release-artifact.mjs';
const q=new URL('./',import.meta.url),metadata=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',import.meta.url),'utf8'));
const raw=new Uint8Array(await readFile(new URL('../public-quantized-compatibility/person_detect.tflite',q))),sha=b=>createHash('sha256').update(b).digest('hex');assert.equal(sha(raw),'808cfdfc0cf3a6fa6f6fa26bfa379ea97c16d5db7334637766e39c3408502e9d');
const parse=bytes=>parseModel((o,n)=>bytes.subarray(o,o+n),bytes.length,metadata),index=await parse(raw),g=index.raw.subgraphs[0],expected=[33,36,40,44,48,52,56,60,64,68,72,76,80,84],inspection=inspectTfliteQuantization(index.raw,[0]),file=new File([raw],'person_detect.tflite');
file.arrayBuffer=()=>assert.fail('no whole-source File read');
assert.deepEqual(inspection.tensors.filter(t=>t.status==='failed').map(t=>t.tensor),expected);
const payload=(m,b,t)=>{const x=m.buffers[t.buffer];return x.size?b.subarray(Number(x.offset),Number(x.offset+x.size)):new Uint8Array(x.data||[]);};
const report={status:'failed',source:gitSource(),sourceSHA256:sha(raw),inspection,rewireRejections:[],variants:[],runtime:'Not invoked; unchanged original/runtime bytes reuse the recorded real compile failure from v1.3.1.'};
for(const id of expected){
 const node=g.operators.findIndex(o=>o.inputs.includes(id)),op=g.operators[node],code=index.raw.operator_codes[op.opcode_index];
 assert.throws(()=>checkBuiltinPorts(Math.max(code.builtin_code,code.deprecated_builtin_code||0),Array.from(op.inputs,n=>n<0?null:g.tensors[n]),Array.from(op.outputs,n=>g.tensors[n]),op.builtin_options),/quantized_dimension/);
 report.rewireRejections.push({tensor:id,node});
}
for(const mode of ['identity','full-cut']){
 const result=mode==='identity'?editTfliteModel(index,file,[{graph:0}]):exportTflite(index,0,g.operators.map((_,i)=>i),file),bytes=new Uint8Array(await result.blob.arrayBuffer()),candidate=await parse(bytes),cg=candidate.raw.subgraphs[0];
 const built=mode==='identity'?createModelEditReport(index,file,{...result,roundTrip:true},candidate,{graph:0,node:0,mode:'replace'},{outputName:mode+'.tflite'}):createExportReport(index,file,result,{graph:0,nodes:g.operators.map((_,i)=>i),outputName:mode+'.tflite'});
 const document=JSON.parse(await built.blob.text());assert.equal(document.quantizationSummary.failed,14);assert.equal(document.checks.find(c=>c.id==='quantization-metadata').status,'failed');
 const weights=[];for(const [id,t]of cg.tensors.entries()){
   const source=mode==='identity'?id:result.provenance.tensorMap.find(x=>x.outputId===id).sourceId;
   assert.deepEqual(t.quantization,g.tensors[source].quantization);
   const a=payload(index.raw,raw,g.tensors[source]),b=payload(candidate.raw,bytes,t);assert.deepEqual(a,b);if(a.length)weights.push({sourceTensor:source,outputTensor:id,bytes:a.length,sha256:sha(a)});
 }
 await writeFile(new URL(mode+'.report.json',q),await built.blob.text(),{flag:'wx'});
 report.variants.push({mode,bytes:bytes.length,sha256:sha(bytes),operators:cg.operators.length,quantizationSummary:document.quantizationSummary,weights,sourceUnmodified:sha(raw)===report.sourceSHA256});
}
report.status='passed-real-original-metadata-reproduction-reports-and-data-preservation';await writeFile(new URL('public-model-after.json',q),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:report.status,failedTensorIDs:expected,inspectedValues:inspection.inspectedValues,quantizedTensors:inspection.total,checked:inspection.checked,unchecked:inspection.unchecked,variants:report.variants.map(x=>({mode:x.mode,bytes:x.bytes,weights:x.weights.length,failed:x.quantizationSummary.failed}))}));

