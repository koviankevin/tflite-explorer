import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {parseModel} from '../../../src/model-engine.js';
import {checkBuiltinPorts} from '../../../src/tflite-new-ops.js';
import {editTfliteModel} from '../../../src/tflite-model-edit.js';
import {validateTfliteConstants} from '../../../src/tflite-constant-checks.js';
import {gitSource} from '../../../scripts/lib/release-artifact.mjs';
const q=new URL('./',import.meta.url),metadata=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',import.meta.url),'utf8'));
const bytes=new Uint8Array(await readFile(new URL('../public-quantized-compatibility/person_detect.tflite',q)));
const sha=createHash('sha256').update(bytes).digest('hex');assert.equal(sha,'808cfdfc0cf3a6fa6f6fa26bfa379ea97c16d5db7334637766e39c3408502e9d');
const index=await parseModel((o,n)=>bytes.subarray(o,o+n),bytes.length,metadata),g=index.raw.subgraphs[0],affected=[64,68,72,76,80,84],rows=[];
for(const id of affected){
 const t=g.tensors[id],quant=t.quantization,consumers=[];
 for(const [node,op]of g.operators.entries())if(op.inputs.includes(id)){
   const code=index.raw.operator_codes[op.opcode_index];let status='accepted',reason;
   try{checkBuiltinPorts(Math.max(code.builtin_code,code.deprecated_builtin_code||0),Array.from(op.inputs,n=>n<0?null:g.tensors[n]),Array.from(op.outputs,n=>g.tensors[n]),op.builtin_options||op.builtin_options_2);}catch(e){status='rejected';reason=e.message;}
   consumers.push({node,status,reason});
 }
 rows.push({tensor:id,shape:[...t.shape],signature:[...(t.shape_signature||[])],hasRank:t.has_rank,type:t.type,scaleCount:quant.scale.length,zeroPointCount:quant.zero_point.length,dimension:quant.quantized_dimension,details:quant.details?.constructor.name,consumers});
}
let reads=0;const proof=validateTfliteConstants(index.raw,0,(o,n)=>{reads+=n;return bytes.subarray(o,o+n);});
const exported=editTfliteModel(index,new File([bytes],'person_detect.tflite'),[{graph:0}]);
const report={status:'captured-current-behavior',source:gitSource(),modelSHA256:sha,rows,constantValidation:{checked:proof.checked,unchecked:proof.unchecked,quantizationReported:proof.operators.some(o=>'quantization' in o),additionalBytesRead:reads},identityExport:{bytes:exported.blob.size,allowed:true},runtimeFailureReused:'../public-quantized-compatibility/negative-after-v3/report.json: original-zero Tensor64/68/72/76/80/84 rejected before inputs'};
await writeFile(new URL('baseline.json',q),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(report));

