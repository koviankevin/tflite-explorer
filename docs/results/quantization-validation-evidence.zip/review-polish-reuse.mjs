import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {quantizationFixture as before} from './fixture-0968-reference.mjs';
import {quantizationFixture as after} from '../../../test/quantization-fixture.mjs';
const q=new URL('./',import.meta.url),changes=execFileSync('git',['diff','--name-only','0968b0bf915291c22aea8d367fe3ae84aa22ebfc','70946a276962915861fa44aa2091a4bb84125f42','--','src','vendor'],{encoding:'utf8'}).trim().split('\n');
assert.deepEqual(changes,['src/export-report-ui.js','src/export-report.js']);
const fixtures=[];for(const options of [{},{rank:false},{rank:false,dimension:3},{layers:201}]){
 const a=await before(options),b=await after(options);assert.deepEqual(b.bytes,a.bytes);fixtures.push({options,bytes:b.bytes.length,sha256:createHash('sha256').update(b.bytes).digest('hex')});
}
const tap=await readFile(new URL('report-polish-green.tap',q),'utf8');assert.match(tap,/pass\s+12/);assert.match(tap,/fail\s+0/);
const receipt={status:'passed-source-and-fixture-byte-reuse-review',before:'0968b0bf915291c22aea8d367fe3ae84aa22ebfc',after:'70946a276962915861fa44aa2091a4bb84125f42',applicationChanges:changes,fixtures,reportNodeChecks:12,
scope:'Only report presentation/summary strings changed in application. Affine validator,model serializers,parser,runtime/vendor unchanged. Four default/CPU/differential/large generator byte outputs identical. Reuse original actual CPU/public-model evidence; changed report Node tests pass; new UI now requires its own native run.'};
await writeFile(new URL('report-polish-reuse-review.json',q),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));

