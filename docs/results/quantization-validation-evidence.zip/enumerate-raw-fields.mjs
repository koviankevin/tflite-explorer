import {readFile,writeFile} from 'node:fs/promises';
import {parseModel} from '../../../src/model-engine.js';
const q=new URL('./',import.meta.url),b=new Uint8Array(await readFile(new URL('../public-quantized-compatibility/person_detect.tflite',q))),m=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',import.meta.url),'utf8')),index=await parseModel((o,n)=>b.subarray(o,o+n),b.length,m);
const rows=index.raw.subgraphs[0].tensors.flatMap((t,id)=>t.quantization?.scale?.length&&t.shape.length&&t.quantization.quantized_dimension>=t.shape.length?[{tensor:id,shape:[...t.shape],hasRank:t.has_rank,scaleCount:t.quantization.scale.length,dimension:t.quantization.quantized_dimension}]:[]);
await writeFile(new URL('extra-findings-raw-metadata.json',q),JSON.stringify({status:'independent-raw-field-enumeration-not-runtime',rows,priorReaderFailure:'Expected six retained runtime-log tensors;actual static inspection found14. First reader preserved, no production bounds or original bytes changed.'},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(rows));

