import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {buildSite} from '../../../scripts/build.mjs';
import {gitSource,verifyArtifact} from '../../../scripts/lib/release-artifact.mjs';
const q=new URL('./',import.meta.url),source=gitSource();assert.equal(source.commit,'0968b0bf915291c22aea8d367fe3ae84aa22ebfc');assert.equal(source.dirty,false);
const records=JSON.parse(await readFile(new URL('node-test-source-review.json',q),'utf8'));
for(const row of records.files){const b=execFileSync('git',['show',source.commit+':'+row.path]);assert.equal(createHash('sha256').update(b).digest('hex'),row.normalizedLFSHA256);}
await writeFile(new URL('candidate-build-intent.json',q),JSON.stringify({status:'create-intent',source,path:'build/qa/quantization-preflight/candidate-site',kind:'temporary',producer:'build-candidate.mjs',purpose:'Immutable v1.4.0 candidate desktop QA;not public deployment',retention:'Preserve artifacts/source/failures;no cleanup'},null,2)+'\n',{flag:'wx'});
const result=await buildSite({output:'build/qa/quantization-preflight/candidate-site'}),manifest=await verifyArtifact(result.directory,{publicOnly:true,requireClean:true,expectedCommit:source.commit});
const receipt={status:'built-and-verified',directory:result.directory,release:manifest.release,files:manifest.files.length,selectedNodeSourceBodiesVerified:true};
await writeFile(new URL('candidate-build.json',q),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));

