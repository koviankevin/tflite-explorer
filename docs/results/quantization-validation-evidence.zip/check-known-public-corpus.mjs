import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {parseModel} from '../../../src/model-engine.js';
import {inspectTfliteQuantization} from '../../../src/tflite-quantization-checks.js';
const q=new URL('./',import.meta.url),corpus=new URL('../../../../tflite-explorer/build/qa/product-next/public-corpus/',q);
const manifest=JSON.parse(await readFile(new URL('manifest.json',corpus),'utf8')),metadata=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',q),'utf8')),cases=[];
for(const f of manifest.files){
 const b=new Uint8Array(await readFile(new URL(f.file,corpus))),sha=createHash('sha256').update(b).digest('hex');assert.equal(sha,f.sha256);assert.equal(b.length,f.bytes);
 const index=await parseModel((o,n)=>b.subarray(o,o+n),b.length,metadata),r=inspectTfliteQuantization(index.raw,index.raw.subgraphs.map((_,i)=>i));
 cases.push({file:f.file,source:f.url,bytes:b.length,sha256:sha,total:r.total,checked:r.checked,failed:r.failed,unchecked:r.unchecked,inspectedValues:r.inspectedValues,failures:r.tensors.filter(t=>t.status==='failed')});
}
const report={status:cases.some(c=>c.failed)?'failed-metadata-regression':'passed-metadata-regression',cases,scope:'New static affine checks only; previous CPU/dynamic policy results retain their original scope and are not rerun or relabeled here.'};
await writeFile(new URL('known-public-corpus-metadata.json',q),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));assert.ok(cases.every(c=>c.failed===0));

