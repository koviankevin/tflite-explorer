import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {buildSite} from '../../../scripts/build.mjs';
import {gitSource,verifyArtifact} from '../../../scripts/lib/release-artifact.mjs';
const q=new URL('./',import.meta.url),source=gitSource();assert.equal(source.commit,'70946a276962915861fa44aa2091a4bb84125f42');assert.equal(source.dirty,false);
const records=JSON.parse(await readFile(new URL('node-test-source-review.json',q),'utf8'));
for(const row of records.files){if(['src/export-report.js','src/export-report-ui.js'].includes(row.path))continue;const b=execFileSync('git',['show',source.commit+':'+row.path]);assert.equal(createHash('sha256').update(b).digest('hex'),row.normalizedLFSHA256);}
await writeFile(new URL('candidate-build-intent-v2.json',q),JSON.stringify({status:'create-intent',source,path:'build/qa/quantization-preflight/candidate-site-v2',kind:'temporary',producer:'build-candidate.mjs',purpose:'Immutable v1.4.0 candidate desktop QA;not public deployment',retention:'Preserve artifacts/source/failures;no cleanup'},null,2)+'\n',{flag:'wx'});
const reuse=JSON.parse(await readFile(new URL('report-polish-reuse-review.json',q),'utf8'));assert.equal(reuse.status,'passed-source-and-fixture-byte-reuse-review');assert.equal(reuse.after,source.commit);
const result=await buildSite({output:'build/qa/quantization-preflight/candidate-site-v2'}),manifest=await verifyArtifact(result.directory,{publicOnly:true,requireClean:true,expectedCommit:source.commit});
const receipt={status:'built-and-verified',directory:result.directory,release:manifest.release,files:manifest.files.length,selectedNodeSourceBodiesVerified:true};
await writeFile(new URL('candidate-build-v2.json',q),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));

