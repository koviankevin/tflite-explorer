import hashlib,json,pathlib,re,subprocess
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];p=root/'test/quantization-fixture.mjs'
old=subprocess.check_output(['git','show','0968b0bf915291c22aea8d367fe3ae84aa22ebfc:test/quantization-fixture.mjs'],cwd=root).decode()
def replace(m):
    target=m[1];return "from '"+(p.parent/target).resolve().as_uri()+"'" if target.startswith('.') else m[0]
s=re.sub(r"from '([^']+)'",replace,old)
s=s.replace("new URL('../vendor/netron/tflite-metadata.json',import.meta.url)","new URL('"+(root/'vendor/netron/tflite-metadata.json').as_uri()+"')")
(q/'fixture-0968-reference.mjs').open('x',encoding='utf-8').write(s)
print(json.dumps({'status':'prepared-frozen-0968-fixture-reference','originalGitBlobSHA256':hashlib.sha256(old.encode()).hexdigest(),'onlyChanges':'Resolve imports/metadata URL from original test location; generator logic unchanged'}))

