import hashlib,json,pathlib,re
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];source=root/'test/browser/windows-operator-validation.mjs'
text=source.read_text(encoding='utf-8')
def replace(match):
    target=match[1]
    if target=='./operator-validation-flow.mjs':return "from '"+(root/'test/browser/quantization-validation-flow.mjs').as_uri()+"'"
    if target=='playwright':return "from '"+(root/'node_modules/playwright/index.mjs').as_uri()+"'"
    if target.startswith('.'):return "from '"+(source.parent/target).resolve().as_uri()+"'"
    return match[0]
overlay=re.sub(r"from '([^']+)'",replace,text).replace('operatorValidationFlow','quantizationValidationFlow').replace('error.operatorValidation','error.quantizationValidation')
overlay=overlay.replace('model-lens-windows-operator-validation','model-lens-windows-quantization-validation')
out=q/'windows-quantization-validation.mjs';assert not out.exists();out.write_text(overlay,encoding='utf-8')
receipt={'status':'source-bound-existing-native-driver-overlay-prepared','base':'test/browser/windows-operator-validation.mjs','baseRawSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'driverRawSHA256':hashlib.sha256(out.read_bytes()).hexdigest(),'driverNormalizedLFSHA256':hashlib.sha256(overlay.encode()).hexdigest(),'onlyChanges':['Resolve imports to recorded source','Use new quantization flow and report label/error slot'],'originalNativeClose10sSecurityFlagsAndDocumentFixtureUnchanged':True,'scope':'Native actual chooser/export/UI plus authenticated original HTML fixture,not formal public HTTPdocument transport or physical RSS.'}
(q/'browser-driver-preparation.json').open('x',encoding='utf-8').write(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))

