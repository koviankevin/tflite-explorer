import base64,gzip,hashlib,io,json,pathlib,urllib.request,zipfile
q=pathlib.Path(__file__).resolve().parent;out=q/'dbgeng-20260319'
version='20260319.1511.0';name='microsoft.debugging.platform.dbgeng'
assert out.is_dir() and (out/'registration.json').exists() and not (out/'package.nupkg').exists()
def decoded(raw,limit):
 if raw[:2]==b'\x1f\x8b':
  with gzip.GzipFile(fileobj=io.BytesIO(raw)) as g:raw=g.read(limit+1)
 assert len(raw)<=limit
 return raw
def get(url,limit):
 assert url.startswith(('https://api.nuget.org/','https://api.nuget.org:443/'))
 with urllib.request.urlopen(url,timeout=30) as r:data=r.read(limit+1)
 assert len(data)<=limit
 return data
meta=decoded((out/'registration.json').read_bytes(),1024**2)
with (out/'registration-decoded.json').open('xb') as f:f.write(meta)
registration=json.loads(meta)
entry_raw=get(registration['catalogEntry'],1024**2)
with (out/'catalog-entry-raw').open('xb') as f:f.write(entry_raw)
entry_bytes=decoded(entry_raw,1024**2);entry=json.loads(entry_bytes)
with (out/'catalog-entry.json').open('xb') as f:f.write(entry_bytes)
url=registration['packageContent'];assert url=='https://api.nuget.org/v3-flatcontainer/'+name+'/'+version+'/'+name+'.'+version+'.nupkg'
raw=get(url,32*1024**2)
assert entry['packageHashAlgorithm'].lower()=='sha512' and base64.b64encode(hashlib.sha512(raw).digest()).decode()==entry['packageHash']
with (out/'package.nupkg').open('xb') as f:f.write(raw)
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 assert len(z.infolist())<=4096 and sum(i.file_size for i in z.infolist())<=128*1024**2 and z.testzip() is None
 names=z.namelist();assert len(names)==len(set(names))
 for n in names:
  p=pathlib.PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts and '\\' not in n and ':' not in n
 report={'status':'official-package-SHA512-and-CRC-verified-no-binaries-loaded','package':name,'version':version,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'SHA512':entry['packageHash'],'members':len(names),'selectedNames':[n for n in names if any(k in n.lower() for k in ['x64','amd64','dbgeng.h','dbghelp.h','readme','license','notice','.nuspec'])]}
 with (out/'inspection.json').open('x',encoding='utf8') as f:f.write(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))
