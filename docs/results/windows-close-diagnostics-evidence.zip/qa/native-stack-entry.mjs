const timer=setTimeout(()=>{console.error('[DEBUG-owned-stack] original240s QA watchdog');process.exit(1);},240000);
try{process.argv.splice(1,1,new URL('./windows-operator-native-stack.mjs',import.meta.url).pathname);await import('./windows-operator-native-stack.mjs');}finally{clearTimeout(timer);}
