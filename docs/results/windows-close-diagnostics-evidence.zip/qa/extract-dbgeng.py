import hashlib,json,pathlib,stat,zipfile
q=pathlib.Path(__file__).resolve().parent;d=q/'dbgeng-20260319';p=d/'package.nupkg';r=json.loads((d/'inspection.json').read_bytes())
assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
dest=d/'extracted';dest.mkdir(exist_ok=False);rows=[]
with zipfile.ZipFile(p) as z:
 for i in z.infolist():
  n=i.filename
  if not (n.startswith('content/amd64/') or n.startswith('build/native/inc/') or n.endswith('.nuspec')):continue
  assert stat.S_IFMT(i.external_attr>>16) in [0,stat.S_IFREG]
  target=dest/pathlib.PurePosixPath(n);target.parent.mkdir(parents=True,exist_ok=True)
  assert target.resolve().is_relative_to(dest.resolve()) and not target.exists()
  data=z.read(i)
  with target.open('xb') as f:f.write(data)
  rows.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert len([r for r in rows if r['path'].startswith('content/amd64/')])==5
report={'status':'fixed-package-subset-extracted-not-loaded','packageSHA256':r['sha256'],'files':rows}
(d/'extracted-manifest.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':report['status'],'files':len(rows),'bytes':sum(r['bytes'] for r in rows)}))
