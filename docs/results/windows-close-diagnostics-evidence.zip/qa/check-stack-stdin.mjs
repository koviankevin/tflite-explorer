import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const q=new URL('./',import.meta.url),checkpoint=fileURLToPath(new URL('./chrome-stack-1/failure-checkpoint.json',q));
const r=JSON.parse(await readFile(checkpoint,'utf8')),row=r.failureNativeObservation.rows.find(x=>x.pid===r.root.pid);
assert.ok(row);const input=JSON.stringify({row,failureCheckpoint:checkpoint});
await writeFile(new URL('./stack-stdin-request-1.json',q),input+'\n',{flag:'wx'});
const python=process.env.MODEL_LENS_QA_PYTHON;assert.ok(python);
let red;
try{execFileSync(python,['-c','import json,sys; x=json.load(sys.stdin); print(json.dumps(x))'],{input,encoding:'utf8',windowsHide:true,stdio:['pipe','pipe','pipe']});}
catch(e){red={exitCode:e.status,stderr:e.stderr};}
assert.equal(red?.exitCode,1);assert.match(red.stderr,/Invalid \\escape/);
const green=JSON.parse(execFileSync(python,['-c','import json,sys; x=json.loads(sys.stdin.buffer.read().decode("utf8")); print(json.dumps(x))'],{input,encoding:'utf8',windowsHide:true}));
assert.deepEqual(green,JSON.parse(input));
const result={status:'actual-Node-to-Python-UTF8-boundary-red-green',red,green:'byte-read with explicit UTF8 restores exact path and full native row',noBrowserStarted:true};
await writeFile(new URL('./stack-stdin-red-green.json',q),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
