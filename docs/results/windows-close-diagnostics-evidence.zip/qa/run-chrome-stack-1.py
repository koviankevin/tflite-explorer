import datetime,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];repo=root.parent/'tflite-explorer-native-validation'
out=q/'chrome-stack-1';log=q/'chrome-stack-1.log';status=q/'chrome-stack-1-status.json'
assert not out.exists() and not log.exists() and not status.exists()
plan=json.loads((q/'native-stack-plan.json').read_bytes())
state={'status':'create-intent','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'channel':'chrome','source':plan['driverSource'],'tree':plan['driverTree'],'output':str(out),'automaticRetries':False}
def save():
 with status.open('w',encoding='utf8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save()
native=root/'test/browser/windows-process-memory.py';scope={'__name__':'owned_census'};exec(compile(native.read_text('utf8').split('observer=Observer()')[0],str(native),'exec'),scope)
table=scope['snapshot']();live=[]
for name in ['direct-pipe-1.json','chrome-nativeproof-2/report.json','msedge-nativeproof-2/report.json','chrome-physical1641-2.json','msedge-physical1641-2.json']:
 r=json.loads((q/name).read_bytes())
 for key in ['failureNativeObservation','processCleanup','normalNativeObservation']:
  for identity in r.get(key,{}).get('identities',[]):
   row=table.get(identity['pid'])
   if row:
    actual=scope['inspect']({**row,'startTicks':identity['startTicks']})
    if actual:live.append(actual)
assert not live,'Previous owned browser remains live; no overlapping diagnostic'
node=r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
entry=q/'native-stack-entry.mjs';assert entry.exists()
with log.open('xb') as f:
 env={**os.environ,'MODEL_LENS_QA_PYTHON':sys.executable,'MODEL_LENS_STACK_HELPER':str(q/'owned-native-stack.py'),'DEBUG':'pw:browser'}
 args=[node,str(entry),'chrome',str(repo/'build/qa/native-stack-candidate-1'),str(out),'--allow-local-browser']
 p=subprocess.Popen(args,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT);state.update(status='running',pid=p.pid);save();code=p.wait()
state.update(status='producer-exited',exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(json.dumps(state));sys.exit(code)
