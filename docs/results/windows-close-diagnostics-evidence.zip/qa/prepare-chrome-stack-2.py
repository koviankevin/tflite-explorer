import hashlib,json,pathlib
q=pathlib.Path(__file__).resolve().parent
source=(q/'run-chrome-stack-1.py').read_text(encoding='utf8')
source=source.replace("out=q/'chrome-stack-1';log=q/'chrome-stack-1.log';status=q/'chrome-stack-1-status.json'","out=q/'chrome-stack-2';log=q/'chrome-stack-2.log';status=q/'chrome-stack-2-status.json'")
source=source.replace("['direct-pipe-1.json',","['chrome-stack-1/report.json','direct-pipe-1.json',")
assert "out=q/'chrome-stack-2'" in source
target=q/'run-chrome-stack-2.py';assert not target.exists();target.write_text(source,encoding='utf8')
r=json.loads((q/'native-stack-plan.json').read_bytes());r.update(case='chrome-stack-2',purpose='One targeted supplementation after diagnostic stdin failure; original Chrome stack1 failure retained. Not a retry to turn acceptance green.',helperSHA256=hashlib.sha256((q/'owned-native-stack.py').read_bytes()).hexdigest(),UTF8Boundary='actual Node/Python red-green plus actual helper validate-request passed without attach',caseCount=1,automaticRetries=False)
(q/'native-stack-plan-2.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':'one-supplement-predeclared','case':r['case'],'helperSHA256':r['helperSHA256']}))
