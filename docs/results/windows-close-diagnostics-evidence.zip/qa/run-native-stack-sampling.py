import datetime,hashlib,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];repo=root.parent/'tflite-explorer-native-validation'
plan=json.loads((q/'native-stack-sampling-plan.json').read_bytes());status=q/'native-stack-sampling-status.json'
assert not status.exists() and len(plan['cases'])==plan['maxSamples']==3
assert hashlib.sha256((q/'owned-native-stack.py').read_bytes()).hexdigest()==plan['helperSHA256']
assert hashlib.sha256((q/'windows-operator-native-stack.mjs').read_bytes()).hexdigest()==plan['driverSHA256']
for name in plan['cases']:assert not (q/name).exists() and not (q/(name+'.log')).exists()
state={'status':'create-intent','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controllerPid':os.getpid(),'purpose':plan['purpose'],'maxSamples':3,'cases':[]}
def save():
 with status.open('w',encoding='utf8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save()
native=root/'test/browser/windows-process-memory.py';scope={'__name__':'owned_census'};exec(compile(native.read_text('utf8').split('observer=Observer()')[0],str(native),'exec'),scope)
def exited(report):
 table=scope['snapshot']();live=[]
 for key in ['failureNativeObservation','processCleanup','normalNativeObservation']:
  for identity in report.get(key,{}).get('identities',[]):
   row=table.get(identity['pid'])
   if row:
    actual=scope['inspect']({**row,'startTicks':identity['startTicks']})
    if actual:live.append(actual)
 assert not live,'Owned prior browser remains; no next sample permitted'
for p in ['chrome-stack-1/report.json','chrome-stack-2/report.json','baseline-stack-1.json','direct-pipe-1.json']:exited(json.loads((q/p).read_bytes()))
node=r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
for name in plan['cases']:
 case={'name':name,'status':'create-intent','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['cases'].append(case);state['status']='running';save()
 with (q/(name+'.log')).open('xb') as log:
  env={**os.environ,'MODEL_LENS_QA_PYTHON':sys.executable,'MODEL_LENS_STACK_HELPER':str(q/'owned-native-stack.py'),'DEBUG':'pw:browser'}
  args=[node,str(q/'native-stack-entry.mjs'),'chrome',str(repo/'build/qa/native-stack-candidate-1'),str(q/name),'--allow-local-browser']
  p=subprocess.Popen(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT);case.update(status='running',pid=p.pid);save();code=p.wait()
 case.update(status='producer-exited',exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 report_path=q/name/'report.json'
 if not report_path.exists():state['status']='stopped-missing-final-report';save();break
 r=json.loads(report_path.read_bytes());case['wholeStatus']=r['status'];case['functionalStatus']=r.get('functionalStatus');exited(r);case['nativeIdentitiesReconciledExited']=True
 stack_path=q/name/'native-root-stack.json'
 if stack_path.exists():
  stack=json.loads(stack_path.read_bytes());case['stackStatus']=stack['status'];case['stackDetached']=stack.get('detached')
 save()
 if code!=0 or r['status']!='passed':state['status']='stopped-at-first-original-failure';save();break
else:state['status']='bounded-samples-complete-no-failure';save()
state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(state))
sys.exit(0 if state['status']=='bounded-samples-complete-no-failure' else 1)
