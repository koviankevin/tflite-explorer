import base64,hashlib,io,json,pathlib,urllib.request,zipfile
q=pathlib.Path(__file__).resolve().parent;out=q/'dbgeng-20260319';out.mkdir(exist_ok=False)
version='20260319.1511.0';name='microsoft.debugging.platform.dbgeng'
def get(url,limit):
 assert url.startswith(('https://api.nuget.org/','https://api.nuget.org:443/'))
 with urllib.request.urlopen(url,timeout=30) as r:data=r.read(limit+1)
 assert len(data)<=limit
 return data
meta_raw=get('https://api.nuget.org/v3/registration5-gz-semver2/'+name+'/'+version+'.json',1024**2)
(out/'registration.json').write_bytes(meta_raw);registration=json.loads(meta_raw)
entry_raw=get(registration['catalogEntry'],1024**2);(out/'catalog-entry.json').write_bytes(entry_raw);entry=json.loads(entry_raw)
url=registration['packageContent'];assert url=='https://api.nuget.org/v3-flatcontainer/'+name+'/'+version+'/'+name+'.'+version+'.nupkg'
raw=get(url,32*1024**2)
assert entry['packageHashAlgorithm'].lower()=='sha512' and base64.b64encode(hashlib.sha512(raw).digest()).decode()==entry['packageHash']
(out/'package.nupkg').write_bytes(raw)
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 assert len(z.infolist())<=4096 and sum(i.file_size for i in z.infolist())<=128*1024**2 and z.testzip() is None
 names=z.namelist();assert len(names)==len(set(names))
 for n in names:
  p=pathlib.PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts and '\\' not in n and ':' not in n
 report={'status':'official-package-SHA512-and-CRC-verified-no-binaries-loaded','package':name,'version':version,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'SHA512':entry['packageHash'],'members':len(names),'selectedNames':[n for n in names if any(k in n.lower() for k in ['x64','amd64','dbgeng.h','dbghelp.h','readme','license','notice','.nuspec'])]}
 (out/'inspection.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
 print(json.dumps(report))
