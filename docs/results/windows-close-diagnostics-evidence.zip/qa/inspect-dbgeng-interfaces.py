import json,pathlib,re
q=pathlib.Path(__file__).resolve().parent
s=(q/'dbgeng-20260319/extracted/build/native/inc/dbgeng.h').read_text(encoding='utf8')
wanted={'IDebugClient':['AttachProcess','DetachProcesses','EndSession','SetOutputCallbacks','SetOutputMask'],
        'IDebugControl':['Execute','WaitForEvent','SetEngineOptions'],
        'IDebugSymbols':['SetSymbolPath','SetSymbolOptions'], 'IDebugOutputCallbacks':['Output']}
result={}
for name,methods in wanted.items():
 start=s.index('#define INTERFACE '+name+'\n')
 rest=s[start:];end=rest.index('#undef INTERFACE')
 names=[a or b for a,b in re.findall(r'STDMETHODV?\((\w+)\)|STDMETHODV?_\(\w+,\s*(\w+)\)',rest[:end])]
 result[name]={'vtable':{m:i for i,m in enumerate(names) if m in methods},'methodCount':len(names),'IID':re.search(r'DEFINE_GUID\(IID_'+name+r',[\s\S]*?\);',s).group(0)}
result['constants']=re.findall(r'#define (?:DEBUG_ATTACH_NONINVASIVE|DEBUG_END_ACTIVE_DETACH|DEBUG_EXECUTE_NO_REPEAT|DEBUG_ENGOPT_DISALLOW_SHELL_COMMANDS|DEBUG_ENGOPT_DISABLE_EXECUTION_COMMANDS|DEBUG_ENGOPT_DISABLESQM)\s+[^\n]+',s)
(q/'dbgeng-20260319/interfaces.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
