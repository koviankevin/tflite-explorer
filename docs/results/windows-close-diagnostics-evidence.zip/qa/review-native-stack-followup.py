import datetime,hashlib,json,pathlib,re,subprocess
q=pathlib.Path(__file__).resolve().parent;repo=q.parents[2].parent/'tflite-explorer-native-validation'
load=lambda n:json.loads((q/n).read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=repo,text=True).strip()
assert git('rev-parse','HEAD')=='70c32602d7c71ce0eb7687e012e033cbecf4c953' and not git('status','--porcelain')
subprocess.run(['git','diff','--exit-code','7debc69df1a1c91e8ed3928a8a4932a493324180','HEAD','--','src','vendor','scripts','.github','test/browser/operator-validation-flow.mjs','docs/export-reports.md'],cwd=repo,check=True,capture_output=True)
direct=load('direct-pipe-1.json');cleanup=load('direct-pipe-1-cleanup.json')
assert load('direct-pipe-1-status.json')['exitCode']==0 and direct['status']=='normal-native-exit'
assert direct['actualCDPRootVerified'] and direct['childExitObserved'] and 0<direct['normalCloseMs']<=10000
assert direct['normalNativeObservation']['rows']==[] and len(direct['normalNativeObservation']['identities'])==8
assert cleanup['originalStatus']==direct['status'] and cleanup['afterPipeEOF']['rows']==[] and 'forced' not in cleanup
events={e['kind']:e['elapsedMs'] for e in direct['events']}
assert events['idle-end']-events['idle-start']>=25000 and events['native-child-exit']<events['normal-close-end']
baseline_log=(q/'sdk1641-1.log').read_text(encoding='utf8');exe=direct['launch']['executable']
args=next(s for s in baseline_log.splitlines() if '<launching>' in s).split('<launching> '+exe+' ',1)[1].split(' ')
assert ['--user-data-dir=<owned>' if a.startswith('--user-data-dir=') else a for a in args]==['--user-data-dir=<owned>' if a.startswith('--user-data-dir=') else a for a in direct['launch']['args']]
assert sha(q/'direct-cdp-close.mjs')==direct['driverSHA256'] and sha(q/'sdk1641-1.log')==direct['launch']['baselineLogSHA256']
pre=load('dbgeng-preflight-3.json');assert pre['status']=='captured-owned-native-stacks' and pre['detached'] and pre['targetResumed'] and pre['targetExitCode']==0
assert len(pre['output'].encode())<1024**2 and re.search(r'ntdll!NtReadFile',pre['output'])
assert 'Network paths are disallowed' in pre['output'] and 'Packages count: 0' in pre['output']
assert load('dbgeng-preflight-1.json')['status']=='failed' and load('dbgeng-preflight-1.json')['targetExitCode']==0
assert load('stack-helper-request-1.json')['status']=='UTF8-stack-request-validated-no-attach'
assert load('stack-stdin-red-green.json')['red']['exitCode']==1
assert sha(q/'owned-native-stack.py')==load('native-stack-plan-2.json')['helperSHA256']==load('baseline-stack-plan.json')['helperSHA256']
cases=[]
for name,expected in [('chrome-stack-1','failed'),('chrome-stack-2','passed')]:
 r=load(name+'/report.json');s=load(name+'-status.json');log=(q/(name+'.log')).read_text(encoding='utf8')
 assert s['status']=='producer-exited' and r['status']==expected and r['functionalStatus']=='passed' and r['errors']==[]
 assert r['source']['commit']=='70c32602d7c71ce0eb7687e012e033cbecf4c953' and r['release']['buildId']=='d3500ba9cd43f789'
 assert not r['source']['dirty'] and r['flow']['modelWorkers']==5 and r['flow']['automaticRuntimeWorkers']==0 and all(w['closed'] for w in r['workers'])
 assert [(c['name'],c['status']) for c in r['flow']['cases']]==[('SPLIT','passed'),('PAD','not-run'),('SLICE','rejected'),('Large','mixed')]
 assert r['flow']['cases'][2]['downloads']==0 and r['flow']['cases'][3]['operators']==21006 and r['flow']['cases'][3]['visibleReportRows']==200
 for case in r['flow']['cases']:
  if case['name']=='SLICE':continue
  assert sha(q/name/('operand-'+case['name']+'-edited.tflite'))==case['outputSHA256']
  assert len(load(name+'/operand-'+case['name']+'.report.json')['operatorValidation'])==case['operators']
 assert all(len(s['rows'])>1 for s in r['nativeProcessSnapshots'])
 if expected=='failed':
  assert s['exitCode']==1 and 'normal browser.close exceeded10s' in r['error'] and len(r['failureNativeObservation']['rows'])==2 and '<will force kill>' in log
  assert 'Invalid \\escape' in load(name+'/native-root-stack-error.json')['message']
  assert not (q/name/'native-root-stack.json').exists()
 else:
  assert s['exitCode']==0 and r['processCleanup']['allReaped'] and r['processCleanup']['remaining']==[] and '<will force kill>' not in log
  assert not (q/name/'native-root-stack.json').exists() and not (q/name/'failure-checkpoint.json').exists()
 cases.append({'case':name,'functionalStatus':'passed','wholeStatus':r['status'],'producerExitCode':s['exitCode'],'reportSHA256':sha(q/name/'report.json'),'stackCaptured':False,'reason':'UTF8 stdin failed before attach; original failure preserved' if expected=='failed' else 'normal exit; hook intentionally not called'})
name='baseline-stack-1';r=load(name+'.json');s=load(name+'-status.json');log=(q/(name+'.log')).read_text(encoding='utf8')
assert s['status']=='producer-exited' and r['driverSHA256']==load('baseline-stack-plan.json')['driverSHA256'] and r['browserVersion']=='156.0.8078.76'
assert r['source']['commit']=='f592e3d9df7ed48fae2ca19e353c7215638959a3'
events={e['kind']:e['elapsedMs'] for e in r['events']};assert events['idle-end']-events['idle-start']>=25000
row={'case':name,'wholeStatus':r['status'],'producerExitCode':s['exitCode'],'reportSHA256':sha(q/(name+'.json'))}
if r['status']=='failed':
 assert s['exitCode']==1 and 'normal browser.close exceeded10s' in r['error'] and events['failed']-events['browser-close-start']>=10000
 assert '<will force kill>' in log and len(r['failureNativeObservation']['rows'])>=1
 stack=load(name+'-native-stack.json');checkpoint=load(name+'-failure-checkpoint.json')
 assert stack['status']=='captured-owned-native-stacks' and stack['detached'] and stack['kind']=='failed-synthetic-browser'
 assert stack['identity'] in checkpoint['failureNativeObservation']['rows'] and stack['identity']['pid']==r['root']['pid']
 assert stack['failureCheckpointSHA256']==sha(q/(name+'-failure-checkpoint.json'))
 assert datetime.datetime.fromisoformat(stack['startedAt'])>=datetime.datetime.fromisoformat(next(e['at'] for e in checkpoint['events'] if e['kind']=='failed'))
 assert len(stack['output'].encode())<1024**2
 row.update(stackCaptured=True,stackSHA256=sha(q/(name+'-native-stack.json')),detached=True)
else:
 assert s['exitCode']==0 and r['status']=='completed-diagnostic' and r['browserClosed'] and r['processCleanup']['allReaped']
 assert r['processCleanup']['remaining']==[] and '<will force kill>' not in log and not (q/(name+'-native-stack.json')).exists()
 row.update(stackCaptured=False,reason='normal native exit; no further retry in this predefined set')
cases.append(row)
result={'format':'model-lens-native-stack-followup-review','status':'bounded-diagnostic-set-reviewed','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'directPipe':{'status':direct['status'],'normalCloseMs':direct['normalCloseMs'],'identities':8,'reportSHA256':sha(q/'direct-pipe-1.json'),'causalInference':'single pass is inconclusive'},
        'nativeDebugger':{'fixedPackageSHA256':pre['packageSHA256'],'signatures':'five Microsoft signatures Valid; package officialSHA512 andCRC checked','preflight':'real stack,detach,targetresume andexit0','UTF8Boundary':'actual old reader red/new byte reader green, actual helper request validated without attach'},
        'cases':cases,'applicationFilesUnchangedFromPublishedSource':True,'rootCauseFixed':False,'goalComplete':False,
        'scope':'Diagnostic evidence only; no changed application, whole physical memory acceptance, website deployment, fixed asset rewrite or relaxed timers.'}
with (q/'native-stack-followup-review.json').open('x',encoding='utf8') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
