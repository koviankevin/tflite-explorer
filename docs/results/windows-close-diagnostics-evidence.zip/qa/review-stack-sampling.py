import datetime,hashlib,json,pathlib,re
q=pathlib.Path(__file__).resolve().parent;load=lambda n:json.loads((q/n).read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=load('native-stack-sampling-plan.json');state=load('native-stack-sampling-status.json')
assert state['status']=='bounded-samples-complete-no-failure' and len(state['cases'])==3 and plan['maxSamples']==3
assert sha(q/'owned-native-stack.py')==plan['helperSHA256'] and sha(q/'windows-operator-native-stack.mjs')==plan['driverSHA256']
rows=[]
for case in state['cases']:
 name=case['name'];r=load(name+'/report.json');log=(q/(name+'.log')).read_text(encoding='utf8')
 assert name in plan['cases'] and case['exitCode']==0 and case['nativeIdentitiesReconciledExited'] and r['status']=='passed' and r['functionalStatus']=='passed'
 assert r['source']['commit']=='70c32602d7c71ce0eb7687e012e033cbecf4c953' and r['source']['tree']=='87895360f8ad30267a123aee4468b935daf98497'
 assert r['release']['buildId']=='d3500ba9cd43f789' and r['errors']==[] and r['flow']['modelWorkers']==5 and r['flow']['automaticRuntimeWorkers']==0
 assert len(r['workers'])>=5 and all(w['closed'] for w in r['workers']) and r['processCleanup']['allReaped'] and r['processCleanup']['remaining']==[]
 assert len(r['processCleanup']['identities'])>1 and all(len(s['rows'])>1 for s in r['nativeProcessSnapshots'])
 assert '<will force kill>' not in log and '<forcefully close>' not in log
 assert not (q/name/'failure-checkpoint.json').exists() and not (q/name/'native-root-stack.json').exists()
 assert [(c['name'],c['status']) for c in r['flow']['cases']]==[('SPLIT','passed'),('PAD','not-run'),('SLICE','rejected'),('Large','mixed')]
 assert r['flow']['cases'][2]['downloads']==0 and r['flow']['cases'][3]['operators']==21006 and r['flow']['cases'][3]['visibleReportRows']==200
 for c in r['flow']['cases']:
  if c['name']=='SLICE':continue
  assert sha(q/name/('operand-'+c['name']+'-edited.tflite'))==c['outputSHA256']
  assert len(load(name+'/operand-'+c['name']+'.report.json')['operatorValidation'])==c['operators']
 rows.append({'case':name,'wholeStatus':r['status'],'producerExitCode':case['exitCode'],'nativeIdentities':len(r['processCleanup']['identities']),'workers':len(r['workers']),'reportSHA256':sha(q/name/'report.json'),'stackCaptured':False,'normalNativeExit':True})
native=q.parents[2]/'test/browser/windows-process-memory.py';scope={'__name__':'final_owned_census'};exec(compile(native.read_text('utf8').split('observer=Observer()')[0],str(native),'exec'),scope)
table=scope['snapshot']();live=[]
reports=['direct-pipe-1.json','baseline-stack-1.json','chrome-stack-1/report.json','chrome-stack-2/report.json']+[c['name']+'/report.json' for c in state['cases']]
for name in reports:
 r=load(name)
 for key in ['failureNativeObservation','processCleanup','normalNativeObservation']:
  for identity in r.get(key,{}).get('identities',[]):
   row=table.get(identity['pid'])
   if row:
    actual=scope['inspect']({**row,'startTicks':identity['startTicks']})
    if actual:live.append(actual)
assert not live
correlation=[]
for name in ['baseline-1','baseline-2','stdio-2','stdio-3','sdk1641-1','sdk1641-2','chrome-ui1641-1','chrome-nativeproof-2','chrome-physical1641-2','chrome-stack-1','chrome-stack-2']:
 data=(q/(name+'.log')).read_text(encoding='utf8');correlation.append({'case':name,'builtinTFLiteStderr':'Created TensorFlow Lite XNNPACK' in data,'SDKForcedCleanup':'<will force kill>' in data,'logSHA256':sha(q/(name+'.log'))})
assert any(r['builtinTFLiteStderr'] and not r['SDKForcedCleanup'] for r in correlation)
assert any(not r['builtinTFLiteStderr'] and r['SDKForcedCleanup'] for r in correlation)
result={'format':'model-lens-bounded-native-reproduction-review','status':'three-samples-ended-no-failure','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'cases':rows,'allSevenDiagnosticBrowserIdentitiesExited':True,'nativeStacksAtActualChromeFailure':'not obtained; original failure before UTF8 repair and later predefined samples did not trigger it',
        'builtinTFLiteLogCorrelation':correlation,'logInference':'Marker is neither necessary nor sufficient for native close failure; no inference of website runtime execution.',
        'previousReview':'native-stack-followup-review.json','rootCauseFixed':False,'goalComplete':False,
        'nextEvidenceNeeded':'Native thread stack during an original10s failure. Do not repeat this successful set, rewrite old failures or claim acceptance repair.'}
with (q/'native-stack-sampling-review.json').open('x',encoding='utf8') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='builtinTFLiteLogCorrelation'}))
