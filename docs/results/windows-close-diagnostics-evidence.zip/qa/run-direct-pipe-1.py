import datetime,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2]
out=q/'direct-pipe-1.json';log=q/'direct-pipe-1.log';status=q/'direct-pipe-1-status.json'
assert all(not p.exists() for p in [out,log,status,q/'direct-pipe-1-cleanup.json'])
state={'status':'create-intent','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'automaticRetries':False,'outputs':[str(out),str(log)],'scope':'one direct-CDP isolated empty Chrome diagnostic; not acceptance'}
def save():
 with status.open('w',encoding='utf8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save()
native=root/'test/browser/windows-process-memory.py';scope={'__name__':'owned_census'};exec(compile(native.read_text('utf8').split('observer=Observer()')[0],str(native),'exec'),scope)
table=scope['snapshot']();live=[]
for name in ['chrome-physical1641-2.json','msedge-physical1641-2.json','chrome-nativeproof-2/report.json','msedge-nativeproof-2/report.json','baseline-1.json','baseline-2.json','sdk1641-1.json','sdk1641-2.json']:
 r=json.loads((q/name).read_bytes());groups=[r.get(k,{}) for k in ['failureNativeObservation','processCleanup','nativeProcessCleanup','normalNativeObservation']]
 for group in groups:
  for identity in group.get('identities',[]):
   row=table.get(identity['pid'])
   if row:
    actual=scope['inspect']({**row,'startTicks':identity['startTicks']})
    if actual:live.append(actual)
assert not live,'Prior owned browser still live; no overlapping diagnostic'
env={**os.environ,'MODEL_LENS_QA_PYTHON':sys.executable,'DIRECT_CLOSE_REPORT':str(out)}
node=r'C:\Users\kovia\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
with log.open('xb') as f:
 p=subprocess.Popen([node,str(q/'direct-cdp-close.mjs'),'--allow-local-browser'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 state.update(status='running',pid=p.pid);save();code=p.wait()
state.update(status='producer-exited',exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
print(json.dumps(state))
sys.exit(code)
