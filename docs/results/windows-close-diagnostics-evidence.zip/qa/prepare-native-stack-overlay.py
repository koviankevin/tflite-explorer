import difflib,hashlib,json,pathlib,re,subprocess
q=pathlib.Path(__file__).resolve().parent
repo=q.parents[2].parent/'tflite-explorer-native-validation'
git=lambda *a:subprocess.check_output(['git',*a],cwd=repo,text=True).strip()
assert git('rev-parse','HEAD')=='70c32602d7c71ce0eb7687e012e033cbecf4c953' and not git('status','--porcelain')
pre=json.loads((q/'dbgeng-preflight-3.json').read_bytes())
assert pre['status']=='captured-owned-native-stacks' and pre['detached'] and pre['targetResumed'] and pre['targetExitCode']==0
f=repo/'test/browser/windows-operator-validation.mjs';original=f.read_text(encoding='utf8')
committed=subprocess.check_output(['git','show','HEAD:test/browser/windows-operator-validation.mjs'],cwd=repo).decode()
assert original==committed
def rewrite(m):
 spec=m.group(1)
 if spec.startswith('node:'):return m.group(0)
 target=repo/'node_modules/playwright/index.mjs' if spec=='playwright' else (f.parent/spec).resolve()
 assert target.is_file()
 return "from '"+target.as_uri()+"'"
overlay=re.sub(r"from '([^']+)'",rewrite,original)
overlay="import {execFileSync as ownedStackExec} from 'node:child_process';\n"+overlay
needle="await writeFile(path.join(directory,'failure-checkpoint.json'),JSON.stringify(report,null,2)+'\\n',{flag:'wx'});"
assert overlay.count(needle)==1
hook="""
    // [DEBUG-owned-stack] Diagnostic only, after the original failure checkpoint.
    // No changed verdict/timer, and no stack hook on successful native close.
    if(report.functionalStatus==='passed'&&report.error?.includes('normal browser.close exceeded10s')&&report.failureNativeObservation?.rows?.length){
        const nativeRoot=report.failureNativeObservation.rows.find(r=>r.pid===report.root.pid&&r.startTicks===report.root.startTicks);
        if(nativeRoot)try{
            const text=ownedStackExec(process.env.MODEL_LENS_QA_PYTHON,[process.env.MODEL_LENS_STACK_HELPER,'--failed-browser',path.join(directory,'native-root-stack.json')],{input:JSON.stringify({row:nativeRoot,failureCheckpoint:path.join(directory,'failure-checkpoint.json')}),encoding:'utf8',windowsHide:true,timeout:30000,maxBuffer:1024**2});
            await writeFile(path.join(directory,'native-root-stack-driver.log'),text,{flag:'wx'});
        }catch(e){await writeFile(path.join(directory,'native-root-stack-error.json'),JSON.stringify({status:'diagnostic-failed',originalAcceptance:'failed',message:e.message},null,2)+'\\n',{flag:'wx'});}
    }
"""
overlay=overlay.replace(needle,needle+hook)
driver=q/'windows-operator-native-stack.mjs';assert not driver.exists();driver.write_text(overlay,encoding='utf8')
diff=''.join(difflib.unified_diff(original.splitlines(True),overlay.splitlines(True),fromfile='canonical/windows-operator-validation.mjs',tofile='ignored-QA/windows-operator-native-stack.mjs'))
(q/'windows-native-stack-overlay.patch').write_text(diff,encoding='utf8')
plan={'status':'predeclared-before-browser','case':'chrome-stack-1','driverSource':git('rev-parse','HEAD'),'driverTree':git('rev-parse','HEAD^{tree}'),
      'canonicalDriverSHA256':hashlib.sha256(committed.encode()).hexdigest(),'diagnosticOverlaySHA256':hashlib.sha256(driver.read_bytes()).hexdigest(),
      'overlay':'absolute import resolution plus one post-checkpoint owned-stack hook; original flow/policy/verdict unchanged',
      'preflight':{'report':'dbgeng-preflight-3.json','sha256':hashlib.sha256((q/'dbgeng-preflight-3.json').read_bytes()).hexdigest()},
      'caseCount':1,'automaticRetries':False,'browser':'Windows installed Chrome only','nativeCloseDeadlineMs':10000,
      'watchdogMs':240000,'applicationComparison':'No source application edits; candidate built clean from recorded70c source. Not a new public deployment or a whole physical-memory pass.',
      'next':'If failed, original checkpoint precedes debugger attach. If passed, preserve inconclusive result without repeating to obtain failure.'}
(q/'native-stack-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8')
print(json.dumps(plan))
