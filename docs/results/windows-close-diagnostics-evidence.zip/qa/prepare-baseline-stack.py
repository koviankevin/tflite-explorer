import difflib,hashlib,json,pathlib
q=pathlib.Path(__file__).resolve().parent
original=(q/'native-close-baseline.mjs').read_text(encoding='utf8')
needle=" if(observer)try{report.observerClose=await observer.close();}catch(e){report.status='failed';report.errors.push(e.message);}"
assert original.count(needle)==1
hook="""
 // [DEBUG-owned-stack] This is after the unchanged10s verdict, before SDK exit cleanup.
 if(report.status==='failed'&&report.error?.includes('normal browser.close exceeded10s')&&report.failureNativeObservation?.rows?.length){
  const checkpoint=output.replace(/\\.json$/,'-failure-checkpoint.json');
  await writeFile(checkpoint,JSON.stringify(report,null,2)+'\\n',{flag:'wx'});
  const row=report.failureNativeObservation.rows.find(r=>r.pid===report.root.pid&&r.startTicks===report.root.startTicks);
  if(row)try{
   const text=execFileSync(process.env.MODEL_LENS_QA_PYTHON,[fileURLToPath(new URL('./owned-native-stack.py',import.meta.url)),'--failed-browser',output.replace(/\\.json$/,'-native-stack.json')],{input:JSON.stringify({row,failureCheckpoint:checkpoint}),encoding:'utf8',windowsHide:true,timeout:30000,maxBuffer:1024**2});
   await writeFile(output.replace(/\\.json$/,'-stack-driver.log'),text,{flag:'wx'});
  }catch(e){await writeFile(output.replace(/\\.json$/,'-stack-error.json'),JSON.stringify({status:'diagnostic-failed',originalAcceptance:'failed',message:e.message},null,2)+'\\n',{flag:'wx'});}
 }
"""
overlay=original.replace(needle,hook+needle)
driver=q/'native-close-baseline-stack.mjs';assert not driver.exists();driver.write_text(overlay,encoding='utf8')
(q/'baseline-stack-overlay.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),overlay.splitlines(True),fromfile='original/native-close-baseline.mjs',tofile='ignored-QA/native-close-baseline-stack.mjs')),encoding='utf8')
controller=(q/'run-sdk1641-2.py').read_text(encoding='utf8')
for a,b in [('sdk1641-2.json','baseline-stack-1.json'),('sdk1641-2.log','baseline-stack-1.log'),('sdk1641-2-status.json','baseline-stack-1-status.json'),('native-close-sdk1641.mjs','native-close-baseline-stack.mjs')]:controller=controller.replace(a,b)
controller=controller.replace("['../op-validation/chrome-3/report.json'","['chrome-stack-1/report.json','chrome-stack-2/report.json','direct-pipe-1.json','../op-validation/chrome-3/report.json'")
assert "out=q/'baseline-stack-1.json'" in controller
target=q/'run-baseline-stack-1.py';assert not target.exists();target.write_text(controller,encoding='utf8')
plan={'status':'predeclared-before-browser','case':'baseline-stack-1','automaticRetries':False,'caseCount':1,
      'purpose':'Attach the validated UTF8 native stack collector to the already observed red minimal empty-page loop, originalSDK1.56.1, original25s idle,10s close,120s watchdog unchanged. Does not update dependencies or product.',
      'previousCase':'chrome-stack-2 wholepassed; no stack collected and no claim of root-cause repair',
      'driverSHA256':hashlib.sha256(driver.read_bytes()).hexdigest(),'helperSHA256':hashlib.sha256((q/'owned-native-stack.py').read_bytes()).hexdigest(),
      'hypothesis':'Need actual native thread stacks after original close failure to distinguish Chrome shutdown vs external module waits. Coexistence, a single pass and builtinTFLite stderr are not causal evidence.',
      'fallback':'If this case passes, stop this predefined set; no retry to obtain a preferred verdict.'}
(q/'baseline-stack-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8');print(json.dumps(plan))
