# Native shutdown diagnostic follow-up

This is diagnostic evidence, not a product release or a repaired Chrome acceptance.
Exact canonical driver source70c3260/tree8789536, candidatebuildd3500ba9cd43f789;
application inputs unchanged from published7debc69/build44782d0412ebc0b8.
Legacy empty-page driver remains originalf592e3d/SDK1.56.1. Canonical OP usesSDK1.64.1.

Direct CDP empty-page control passed in1143ms; this single pass is inconclusive.
First OP whole attempt failed original10sclose; UTF8 stdin decoding failed before
native attach. Original failure and subsequent SDK forced cleanup remain failures.
After actual Node/Python byte-boundary repair, one OP and one legacy empty control
passed, then a predeclared three-sample reproduction set also passed and stopped.
No actual failing Chrome stack was captured. Nothing here proves its root cause fixed.

Official Microsoft/WinDbg NuGet package20260319.1511.0 SHA512,CRC and five extracted
Microsoft Authenticode signatures were checked. A real synthetic Python child stack
was captured noninvasively, detached, resumed and exited0. Initial pre-attach header
parser failure and gzip-metadata failure are preserved as setup-only failures.
Collector uses fixed stack/module-name commands, process-local private debugger
directories, disabled symbol network/shell/execution commands/SQM. Only after the
original browser failure checkpoint may it suspend/unwind the admitted owned root.
No raw memory dump or stack bytes are saved. Stack frames from preflight are not a
Chrome failure or an explanation of the native wait. DLLs/nupkg are retained locally,
not redistributed in this archive; official metadata and checksums bind their source.

manifest.json binds every unchanged original and deduplicated member. Large metadata
fixtures are omitted with hashes and retained locally. No company models/profile,
new deployment/tag/Release rewrite, altered10sclose/RSS/GC/security policy or extra soak.
Do not automatically execute controllers from this archive; they launch isolated
browsers. Restore original source-relative QA imports against the recorded Git source.
