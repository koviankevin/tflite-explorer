import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {gitSource} from '../../scripts/lib/release-artifact.mjs';
import {gitReader,sourceScope} from '../../scripts/lib/release-gates.mjs';
const source=gitSource();assert.equal(source.commit,'71ea9855333b3ee880012a9b737eee166d643e9b');assert.equal(source.dirty,false);const reader=gitReader(),reference='5746284846937690178f2ed63347a2bffd8c8980',rows=[];
for(const kind of ['core','browser','contract','site']){const prior=sourceScope(kind,reference,reader),next=sourceScope(kind,source.commit,reader),old=new Map(prior.files.map(f=>[f.path,JSON.stringify(f)]));rows.push({kind,same:prior.fingerprint===next.fingerprint,fingerprint:next.fingerprint,files:next.files.length,changed:next.files.filter(f=>JSON.stringify(f)!==old.get(f.path)).map(f=>f.path)});}
assert.deepEqual(gitSource(),source);await writeFile('build/qa/runtime-bin32-scope.json',JSON.stringify({source,reference,rows},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(rows));
