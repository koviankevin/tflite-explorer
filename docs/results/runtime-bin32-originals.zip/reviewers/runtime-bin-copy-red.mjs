import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {runtimeInput} from '../../src/tflite-runtime-inputs.js';
const raw=new Float32Array(1048576).fill(7).buffer;
let reads=0;class PublicInput extends File{async arrayBuffer(){reads++;return raw;}}
const source=new PublicInput([raw],'public-allocation.bin'),result=await runtimeInput({dtype:'float32',shape:[1,1024,1024]},{mode:'bin',file:source});
const hash=b=>createHash('sha256').update(new Uint8Array(b)).digest('hex');assert.equal(reads,1);assert.equal(hash(result.buffer),hash(raw));assert.equal(result.byteLength,4194304);
assert.equal(result.buffer===raw,true,'A private little-endian raw File buffer should not require another full tensor allocation');
