import base64,hashlib,io,json,pathlib,stat,sys,urllib.request,zipfile
q=pathlib.Path(__file__).resolve().parent
kind=sys.argv[1]; assert kind in ['core','contract','browser','site','delivery']
meta_kind='site' if kind=='delivery' else kind
load=lambda n:json.loads((q/n).read_bytes())
run=load('main-'+meta_kind+'-run.json'); meta=load('main-'+meta_kind+'-artifacts.json')['artifacts']
assert run['status']=='completed' and run['conclusion']=='success' and run['event']=='workflow_dispatch' and run['head_branch']=='main' and run['head_sha']=='655e5dd384ac3b9e0a05642d77095bb388333e27' and run['run_attempt']==1
prefix={'core':'core-performance','contract':'release-contract','browser':'browser-lifecycle','site':'versioned-site-browser','delivery':'versioned-delivery-smoke'}[kind]
selected=[a for a in meta if a['name']==prefix+'-'+run['head_sha']+'-1']; assert len(selected)==1
a=selected[0];assert not a['expired'] and a['workflow_run']['id']==run['id'] and a['workflow_run']['head_sha']==run['head_sha']
dest=q/('main-'+kind+'-artifact.zip');out=q/('main-'+kind+'-report.json');assert not dest.exists() and not out.exists()
url=base64.b64decode(sys.argv[2]).decode();assert url.startswith('https://')
with urllib.request.urlopen(url,timeout=30) as response:raw=response.read(4*1024**2+1)
del url
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(raw)==a['size_in_bytes'] and 'sha256:'+sha(raw)==a['digest']
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert z.testzip() is None
    entries=z.infolist(); assert len(entries)<12 and sum(i.file_size for i in entries)<8*1024**2
    assert all(not i.is_dir() and '/' not in i.filename and '\\\\' not in i.filename and stat.S_IFMT(i.external_attr>>16) in [0,stat.S_IFREG] for i in entries)
    reports=[i for i in entries if i.filename.endswith('.json')]; assert len(reports)==1
    body=z.read(reports[0])
with dest.open('xb') as f:f.write(raw)
with out.open('xb') as f:f.write(body)
r=json.loads(body)
print(json.dumps({'kind':kind,'providerDigest':a['digest'],'artifactId':a['id'],'reportSHA256':sha(body),'status':r.get('status'),'archiveMembers':[i.filename for i in entries]}))

