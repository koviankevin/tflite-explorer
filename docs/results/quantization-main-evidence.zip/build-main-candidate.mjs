import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {buildSite} from '../../../scripts/build.mjs';
import {gitSource,verifyArtifact} from '../../../scripts/lib/release-artifact.mjs';
const q=new URL('./',import.meta.url),source=gitSource(),proof=JSON.parse(await readFile(new URL('pr203-merge-proof.json',q),'utf8'));
assert.equal(source.commit,'655e5dd384ac3b9e0a05642d77095bb388333e27');assert.equal(source.tree,proof.tree);assert.equal(source.dirty,false);
const reviewed=JSON.parse(await readFile(new URL('pr203-final-ci-review.json',q),'utf8'));assert.equal(reviewed.status,'PR203-required-checks-source-and-original-policy-verified');assert.equal(reviewed.tree,source.tree);
await writeFile(new URL('main-candidate-intent.json',q),JSON.stringify({status:'create-intent',source,producer:'build-main-candidate.mjs',path:'build/qa/quantization-preflight/main-candidate',purpose:'Exact main source build ID for four release gates;not public deployment',retention:'Keep original/failed source and QA;no cleanup'},null,2)+'\n',{flag:'wx'});
const result=await buildSite({output:'build/qa/quantization-preflight/main-candidate'}),m=await verifyArtifact(result.directory,{publicOnly:true,requireClean:true,expectedCommit:source.commit});assert.equal(m.release.version,'1.4.0');assert.equal(m.files.length,324);
const receipt={status:'built-exact-verified-main',directory:result.directory,release:m.release,files:m.files.length,PRTreeUnchanged:true};await writeFile(new URL('main-candidate-build.json',q),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));

