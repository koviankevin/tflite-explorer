import datetime,json,os,pathlib,subprocess,sys
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];plan=json.loads((q/'main-gates-plan.json').read_bytes());kind=sys.argv[1];assert kind in plan['workflows'];workflow=plan['workflows'][kind];repo=plan['repository'];gh=r'H:\mc2llvm\.work\gh\bin\gh.exe'
p=q/('main-'+kind+'-dispatch.json');assert not p.exists(),'Reconcile existing intent;never repeat dispatch.'
state={'status':'create-intent','kind':kind,'workflow':workflow,'source':plan['source'],'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'postAttempted':False,'automaticRetries':False}
def save():
    with p.open('w',encoding='utf-8') as f:json.dump(state,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save()
def git(*args):return subprocess.check_output(['git',*args],cwd=root).decode('utf-8-sig').strip()
def api(route):return json.loads(subprocess.check_output([gh,'api','repos/'+repo+'/'+route],cwd=root,timeout=45).decode('utf-8-sig'))
assert git('rev-parse','HEAD')==plan['source'] and git('rev-parse','HEAD^{tree}')==plan['tree'] and not git('status','--porcelain')
assert api('git/ref/heads/main')['object']['sha']==plan['source']
before=api('actions/runs?head_sha='+plan['source']+'&event=workflow_dispatch&per_page=100');assert before['total_count']==len(before['workflow_runs'])
assert not any(r['path']=='.github/workflows/'+workflow for r in before['workflow_runs']),'Existing target run;inspect instead of repeating.'
(q/('main-'+kind+'-before-runs.json')).open('x',encoding='utf-8').write(json.dumps(before,indent=2)+'\n')
state.update(status='dispatch-intent',postAttempted=True,knownBeforeIds=[r['id'] for r in before['workflow_runs']]);save()
args=[gh,'workflow','run',workflow,'--repo',repo,'--ref','main']
if kind=='site':args+=['-f','scenario=versioned','-f','expected_build_id='+plan['candidateBuild']]
try:
    r=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
    state.update(status='accepted-await-authoritative-run' if r.returncode==0 else 'dispatch-result-needs-reconciliation',exitCode=r.returncode,stdout=r.stdout.decode('utf-8','replace')[:4096],stderr=r.stderr.decode('utf-8','replace')[:4096])
except subprocess.TimeoutExpired:state['status']='unknown-dispatch-result-reconcile'
state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({k:v for k,v in state.items() if k not in ['stdout','stderr','knownBeforeIds']}));sys.exit(0 if state['status']=='accepted-await-authoritative-run' else 1)

