import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {performance} from 'node:perf_hooks';
import {quantizationFixture} from '../../../test/quantization-fixture.mjs';
import {parseModel} from '../../../src/model-engine.js';
import {editTfliteModel} from '../../../src/tflite-model-edit.js';
import {validateTfliteConstants} from '../../../src/tflite-constant-checks.js';
import {createModelEditReport} from '../../../src/model-edit-report.js';
import {createModelEditReport as baselineReport} from '../public-quantized-compatibility/v1.3.1-prepared-artifacts/core/src/model-edit-report.js';
import {gitSource} from '../../../scripts/lib/release-artifact.mjs';
const q=new URL('./',import.meta.url),started=performance.now(),f=await quantizationFixture({layers:21005}),metadata=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',q),'utf8'));
f.file.arrayBuffer=()=>assert.fail('no whole original File read');
const result=editTfliteModel(f.index,f.file,[{graph:0}]),raw=new Uint8Array(await result.blob.arrayBuffer()),candidate=await parseModel((o,n)=>raw.subarray(o,o+n),raw.length,metadata);
result.semanticValidation=[validateTfliteConstants(candidate.raw,0,(o,n)=>raw.subarray(o,o+n))];result.roundTrip=true;
const report={status:'failed',source:gitSource(),operators:21005,tensors:candidate.raw.subgraphs[0].tensors.length,sourceBytes:f.bytes.length,outputBytes:raw.length,cases:[],scope:'Metadata-only synthetic chain;not1GiB weight storage,browserRSS,or interpreter. Same parsed/candidate objects used with actual frozenv1.3.1 formatter for comparison.'};
for(const [name,build]of [['baseline-v1.3.1',baselineReport],['candidate-v1.4.0',createModelEditReport]]){
 const begin=performance.now();try{const r=build(f.index,f.file,result,candidate,{graph:0,node:0,mode:'replace'},{outputName:'large-quantized.tflite'});report.cases.push({name,status:'passed',reportBytes:r.blob.size,operatorRows:r.summary.operatorValidation.length,quantization:r.summary.quantizationSummary,elapsedMs:performance.now()-begin});}catch(error){report.cases.push({name,status:'failed',reason:error.message,elapsedMs:performance.now()-begin});}
}
report.elapsedMs=performance.now()-started;report.nodeMemory=process.memoryUsage();report.status=report.cases.every(c=>c.status==='passed')?'passed-quantized-report-size':'failed-quantized-report-size';
await writeFile(new URL('large-quantized-report.json',q),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));assert.equal(report.status,'passed-quantized-report-size');

