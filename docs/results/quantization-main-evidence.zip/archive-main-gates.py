import datetime,hashlib,json,pathlib,zipfile
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];load=lambda n:json.loads((q/n).read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
source='655e5dd384ac3b9e0a05642d77095bb388333e27';tree='402703eba099a1f12aa4ddcb2e7b0e583d187e9c';reviews={}
for k in ['core','browser','contract','site']:
    r=load('main-'+k+'-review.json');assert r['status']=='passed-original-gate-review' and r['source']==source and r['tree']==tree;reviews[k]=r
delivery=load('main-delivery-smoke-review.json');assert delivery['status']=='passed-reviewed' and delivery['checks']==36 and delivery['source']==source
large=load('large-quantized-report.json');assert large['status']=='passed-quantized-report-size' and large['source']['commit']==source and large['operators']==21005 and large['cases'][1]['reportBytes']==13785165 and large['cases'][1]['reportBytes']<16*1024**2
names=['main-gates-plan.json','main-gates-accepted-run-identities.json','main-candidate-build.json','main-candidate-intent.json','pr203-final-ci-review.json','pr203-merge-proof.json','main-delivery-artifact.zip','main-delivery-report.json','main-delivery-smoke-review.json','dispatch-main-gate.py','build-main-candidate.mjs','download-main-gate.py','review-main-gate.mjs','review-main-delivery-smoke.mjs','large-quantized-report-plan.json','check-large-quantized-report.mjs','large-quantized-report.json','archive-main-gates.py']
for k in reviews:names+=['main-'+k+'-'+s for s in ['dispatch.json','before-runs.json','run.json','jobs.json','artifacts.json','artifact.zip','report.json','review.json']]
records=[{'path':n,'bytes':(q/n).stat().st_size,'sha256':sha((q/n).read_bytes())} for n in names]
m=(json.dumps({'format':'model-lens-quantization-main-originals','source':source,'tree':tree,'records':records,'privacy':'Original provider metadata/reports/ZIPs and reader sources only. No model/weight/BIN/BMP payloads;metadata-only large report benchmark includes size/timing,notbrowserRSS.'},indent=2)+'\n').encode()
dest=root/'docs/results/quantization-main-evidence.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('manifest.json',m)
    for n in names:z.write(q/n,n)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    for v in records:assert sha(z.read(v['path']))==v['sha256']
b=dest.read_bytes();receipt={'format':'model-lens-quantization-main-review','status':'passed-main-release-gates-not-published','version':'1.4.0','source':source,'tree':tree,'candidateBuild':'5584055c9f7af4e5','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'gates':reviews,'deliverySmoke':delivery,'largeQuantizedReport':large,'originals':{'path':dest.name,'bytes':len(b),'sha256':sha(b),'manifestSHA256':sha(m),'records':len(records)},'limitations':['These main dispatch gates and metadata benchmark are not public deployment.','Native Windows authenticated HTML fixture retains originalsource709/scoped reuse;notformalHTTPS/RSS or historicalChromeclosefix.','Metadata scale benchmark uses10MB synthetic source,no1GiBweights/browserRSS/interpreter/GC;physical1.25GiB gate is separatelyverified.','Arbitrarykernel/customcodec,company/OSpowerloss notpromised.'],'goalComplete':False}
(root/'docs/results/quantization-main.json').open('x',encoding='utf-8').write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'records':len(records),'archiveBytes':len(b),'archiveSHA256':sha(b),'runs':{k:r['run'] for k,r in reviews.items()}}))

