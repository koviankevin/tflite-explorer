import assert from 'node:assert/strict';
export function assertStableCoverage101(report){
    const features={demoRuntime:true,inputCleanup:true,workspaceStorage:true,desktopRuntimeRSS:true};
    assert.deepEqual(report.releaseFeatures,features);
    assert.equal(report.demoRuntime.cases.length,4);
    assert.equal(report.tfliteRuntime.inputCleanupRequired,true);
    assert.equal(report.runtimeLifecycle.inputCleanupRequired,true);
    assert.equal(report.workspaceStorageRequired,true);
    assert.equal(report.workspaceStorage.status,'passed');
    return {features:report.releaseFeatures,publishedDemoCases:report.demoRuntime.cases.length,inputCleanupRequired:true,workspaceStorageRequired:true};
}
