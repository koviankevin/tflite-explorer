import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {sha256} from '../../scripts/lib/release-artifact.mjs';
export async function assertStartupRecovery33(raw,{base,buildId,screenshotPath}){
    assert.equal(raw.startupRecoveryRequired,true);const r=raw.startupRecovery;
    assert.equal(r.format,'model-lens-startup-recovery');assert.equal(r.version,1);assert.equal(r.status,'passed',r.error);assert.deepEqual(r.errors,[]);assert.equal(r.downloads,0);
    assert.equal(r.earlyOpenRequired,true);assert.equal(r.guideReadinessRequired,true);
    assert.deepEqual(r.cases.map(c=>c.mode),['entry-failure','dependency-failure','pending-recovery','early-open','guide-ready']);
    for(const c of r.cases){
        assert.equal(c.recovered,true);assert.equal(c.contextClosed,true);assert.equal(c.modelOpened,false);assert.equal(c.runtimeFetched,false);
        assert.equal(c.keyboardReload,!['pending-recovery','early-open','guide-ready'].includes(c.mode));assert.equal(c.pendingFocusRestored,c.mode==='pending-recovery');
        assert.ok(Number.isSafeInteger(c.workers)&&c.workers>=0&&c.workers<=2);
        if(['entry-failure','dependency-failure'].includes(c.mode)){const b=c.failureBounds;assert.ok(b.x>=0&&b.y>=0&&b.width>0&&b.height>0&&b.x+b.width<=1280&&b.y+b.height<=640);}
        if(c.mode==='early-open')assert.deepEqual(c.earlyOpen,{disabledWhilePending:true,clickWaitedForReady:true,nativeChooser:true,selectedFiles:0});
        if(c.mode==='guide-ready')assert.deepEqual(c.guideReadiness,{disabledWhileLoading:true,enabledWhenReady:true,dialogPreserved:true,focusPreserved:true});
    }
    assert.equal(r.workers.length,r.cases.reduce((n,c)=>n+c.workers,0));assert.ok(r.workers.every(w=>w.closed&&w.url===new URL(raw.coreBasePath+'vendor/netron/worker.js?v='+buildId,base).href&&r.cases.some(c=>c.mode===w.mode)));
    assert.ok(r.requests.length>0&&r.requests.every(q=>q.method==='GET'&&q.url.startsWith(base)&&!q.url.includes('/vendor/litert/')&&!/\/(?:model-worker|tflite-runtime-worker)\.js/.test(q.url)));
    const s=r.failureScreenshot;assert.equal(s.mode,'dependency-failure');assert.equal(s.mime,'image/png');assert.equal(s.encoding,'base64');const bytes=Buffer.from(s.data,'base64');assert.equal(bytes.toString('base64'),s.data);assert.equal(bytes.length,s.bytes);assert.ok(bytes.length>0&&bytes.length<=512*1024);assert.equal(sha256(bytes),s.sha256);assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
    await writeFile(screenshotPath,bytes,{flag:'wx'});
    return {cases:r.cases,workers:r.workers.length,allWorkersClosed:true,zeroModelAndRuntime:true,downloads:0,screenshotSHA256:s.sha256,screenshotPath,scope:'Hosted Linux Chromium real one-shot network faults, actual Enter reload and delayed successful startup; no inference or private model. This is not rootcause proof for the historical unexplained timeout.'};
}
