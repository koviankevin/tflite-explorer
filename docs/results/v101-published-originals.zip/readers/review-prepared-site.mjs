import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
import {createWriteStream} from 'node:fs';
import {readFile,writeFile,mkdir,lstat} from 'node:fs/promises';
import {Transform} from 'node:stream';
import {pipeline} from 'node:stream/promises';
import path from 'node:path';
import {root,gitSource,sha256} from '../../scripts/lib/release-artifact.mjs';
import {verifySite} from '../../scripts/lib/versioned-site.mjs';
import {ghJSON,fileSHA256,validateDelivery} from '../../scripts/lib/pages-release.mjs';
const [runText,version='0.2.0-preview.8',label='review']=process.argv.slice(2);assert.match(runText||'',/^\d+$/);assert.match(version,/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/);assert.match(label,/^[a-z0-9-]+$/);
const runId=Number(runText);assert.ok(Number.isSafeInteger(runId)&&runId>0);const source=gitSource();assert.equal(source.dirty,false);
const api='repos/koviankevin/tflite-explorer/',base=path.join(root,`build/qa/prepared-${runId}-${label}`);await mkdir(base);
const report={format:'model-lens-prepared-snapshot-review',version:1,status:'failed',startedAt:new Date().toISOString(),source,runId,artifacts:[]};
try{
 const run=ghJSON(api+'actions/runs/'+runId),jobs=ghJSON(api+`actions/runs/${runId}/jobs?per_page=100`),listed=ghJSON(api+`actions/runs/${runId}/artifacts?per_page=100`);
 assert.equal(run.status,'completed');assert.equal(run.conclusion,'success');assert.equal(run.head_sha,source.commit);assert.equal(run.event,'workflow_dispatch');assert.equal(run.head_branch,'main');assert.equal(run.path,'.github/workflows/verified-pages.yml');assert.equal(jobs.total_count,jobs.jobs.length);assert.equal(listed.total_count,listed.artifacts.length);
 const prepares=jobs.jobs.filter(j=>j.name==='prepare');assert.equal(prepares.length,1);const job=prepares[0];assert.equal(job.conclusion,'success');assert.equal(job.head_sha,source.commit);assert.equal(job.run_attempt,run.run_attempt);
 const log=execFileSync(process.env.GH_BIN||'gh',['run','view',String(runId),'--repo','koviankevin/tflite-explorer','--log','--job',String(job.id)],{encoding:'utf8',timeout:30000,maxBuffer:8*1024**2,windowsHide:true});
 const lines=log.split(/\r?\n/).filter(line=>line.includes('{"prepared":true'));assert.equal(lines.length,1);const prepared=JSON.parse(lines[0].slice(lines[0].indexOf('{"prepared":true')));assert.equal(prepared.controllerSource,source.commit);assert.match(prepared.buildId,/^[a-f0-9]{16}$/);assert.match(prepared.siteId,/^[a-f0-9]{64}$/);assert.match(prepared.siteManifestSHA256,/^[a-f0-9]{64}$/);assert.match(prepared.zipSHA256,/^[a-f0-9]{64}$/);report.prepared=prepared;
 const selected=JSON.parse(await readFile(path.join(root,'release-evidence.json'),'utf8'));assert.deepEqual(prepared.gates.map(g=>[g.kind,g.runId]),Object.entries(selected.runs));
 assert.equal(listed.artifacts.length,2);
 for(const name of ['github-pages','release-delivery']){
  const matches=listed.artifacts.filter(a=>a.name===name);assert.equal(matches.length,1);const a=matches[0];assert.equal(a.expired,false);assert.match(a.digest,/^sha256:[a-f0-9]{64}$/);assert.ok(Number.isSafeInteger(a.size_in_bytes)&&a.size_in_bytes>0&&a.size_in_bytes<=512*1024**2);assert.equal(a.workflow_run.id,runId);assert.equal(a.workflow_run.head_sha,source.commit);assert.equal(a.workflow_run.head_branch,'main');assert.equal(a.workflow_run.repository_id,a.workflow_run.head_repository_id);assert.ok(Date.parse(a.created_at)>=Date.parse(job.started_at)&&Date.parse(a.created_at)<=Date.parse(job.completed_at));
  const filename=path.join(base,name+'.zip'),child=spawn(process.env.GH_BIN||'gh',['api',api+`actions/artifacts/${a.id}/zip`],{windowsHide:true,stdio:['ignore','pipe','pipe']});child.stderr.resume();const done=new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',code=>code===0?resolve():reject(Error('Artifact download failed: '+code)));});let bytes=0;const limit=new Transform({transform(chunk,encoding,callback){bytes+=chunk.length;callback(bytes>a.size_in_bytes?Error('Artifact exceeds provider size.'):null,chunk);}}),timer=setTimeout(()=>child.kill(),120000);
  try{await Promise.all([pipeline(child.stdout,limit,createWriteStream(filename,{flags:'wx'})),done]);}catch(error){child.kill();await done.catch(()=>{});throw error;}finally{clearTimeout(timer);}
  assert.equal(bytes,a.size_in_bytes);assert.equal('sha256:'+await fileSHA256(filename),a.digest);report.artifacts.push({name,id:a.id,bytes,digest:a.digest});
 }
 const delivery=path.join(base,'delivery'),pages=path.join(base,'pages');await mkdir(delivery);await mkdir(pages);
 const extract=String.raw`import sys,zipfile,tarfile,pathlib,stat,shutil,os
base=pathlib.Path(sys.argv[1]); version=sys.argv[2]; build=sys.argv[3]
reserved={'CON','PRN','AUX','NUL'}|{'COM'+str(i) for i in range(1,10)}|{'LPT'+str(i) for i in range(1,10)}
def safe(name):
 assert name and not name.startswith('/') and '\\' not in name and ':' not in name and '\x00' not in name
 assert all(p not in ('','.','..') and not p.endswith(('.',' ')) and p.split('.')[0].upper() not in reserved for p in name.split('/'))
 return name
zipname='model-lens-public-'+version+'-'+build+'.zip'
for archive,expected,target in [('release-delivery.zip',{zipname,zipname+'.sha256','release-manifest.json','release-gates.json'},'delivery'),('github-pages.zip',{'artifact.tar'},None)]:
 z=zipfile.ZipFile(base/archive); entries=z.infolist(); names=[f.filename for f in entries]
 assert set(names)==expected and len(names)==len(expected) and sum(f.file_size for f in entries)<=512*1024*1024 and z.testzip() is None
 for f in entries:
  safe(f.filename); assert not f.is_dir() and stat.S_IFMT(f.external_attr>>16) in (0,stat.S_IFREG)
  assert f.filename not in ('release-manifest.json','release-gates.json') or f.file_size<=4*1024*1024
  with z.open(f) as inp,open(base/(target or '')/f.filename,'xb') as out:shutil.copyfileobj(inp,out,1024*1024)
t=tarfile.open(base/'artifact.tar'); members=t.getmembers(); assert len(members)<=8192 and sum(m.size for m in members)<=512*1024*1024
names=set()
for m in members:
 name=m.name[2:] if m.name.startswith('./') else m.name
 if name in ('','.'):assert m.isdir();continue
 safe(name); assert m.isdir() or m.isfile(); assert name.casefold() not in names; names.add(name.casefold())
for m in members:
 name=m.name[2:] if m.name.startswith('./') else m.name
 if name in ('','.'):continue
 target=base/'pages'/name; assert os.path.commonpath([str((base/'pages').resolve()),str(target.resolve())])==str((base/'pages').resolve())
 if m.isdir():target.mkdir(parents=True,exist_ok=True)
 else:
  target.parent.mkdir(parents=True,exist_ok=True)
  with t.extractfile(m) as inp,open(target,'xb') as out:shutil.copyfileobj(inp,out,1024*1024)
`;
 execFileSync(process.env.PYTHON_BIN||(process.platform==='win32'?'python':'python3'),['-I','-c',extract,base,version,prepared.buildId],{timeout:60000,windowsHide:true,stdio:['ignore','pipe','pipe']});
 const siteRaw=await readFile(path.join(pages,'site-manifest.json'));assert.equal(sha256(siteRaw),prepared.siteManifestSHA256);const site=await verifySite(pages,{publicOnly:true});assert.equal(site.siteId,prepared.siteId);assert.equal(site.current.release.buildId,prepared.buildId);
 const receiptSHA=await fileSHA256(path.join(delivery,'release-gates.json')),bundle=await validateDelivery(delivery,{source:prepared.coreSource,build:prepared.buildId,manifest:site.current.manifestSHA256,receipt:receiptSHA,zip:prepared.zipSHA256},{allowBaselineHistory:prepared.promotion===true});assert.deepEqual(bundle.manifest.release,site.current.release);assert.equal(bundle.manifest.release.version,version);if(!prepared.promotion)assert.equal(prepared.coreSource,source.commit);
 report.release=bundle.manifest.release;report.assets=bundle.assets;report.site={siteId:site.siteId,manifestSHA256:sha256(siteRaw),current:site.current.release.buildId,legacy:site.legacyRoot.release.buildId,retainedBuildIds:site.retainedBuildIds,files:site.files.length};report.directories={pages:path.relative(root,pages).replaceAll('\\','/'),delivery:path.relative(root,delivery).replaceAll('\\','/')};assert.deepEqual(gitSource(),source);report.sourceUnchanged=true;report.status='passed';
}catch(error){report.error=error.stack||String(error);process.exitCode=1;}
finally{report.finishedAt=new Date().toISOString();await writeFile(path.join(base,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,runId,prepared:report.prepared,site:report.site,report:path.relative(root,path.join(base,'report.json')),error:report.error}));}
