import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {sha256} from '../../scripts/lib/release-artifact.mjs';
export async function assertWorkspaceStorage34(smoke,{base,buildId,screenshotPath}){
    assert.equal(smoke.workspaceStorageRequired,true);const r=smoke.workspaceStorage;
    assert.equal(r.format,'model-lens-workspace-storage');assert.equal(r.version,1);assert.equal(r.status,'passed');assert.equal(r.contextClosed,true);assert.deepEqual(r.errors,[]);
    assert.equal(r.recordsBefore,20);assert.equal(r.recordsAfterRemoval,19);assert.equal(r.recordsAfterRetry,20);assert.equal(r.nativeChoosers,22);
    assert.equal(r.cases.length,2);assert.ok(r.cases[0].includes('21st fails visibly')&&r.cases[1].includes('restores query, 32px and selected OP'));
    assert.deepEqual(r.downloads.map(d=>d.label),['backup','retried']);for(const d of r.downloads){assert.ok(d.bytes>0&&d.bytes<2*1024**2);assert.match(d.sha256,/^[a-f0-9]{64}$/);}
    const prefix=new URL('versions/'+buildId+'/src/',base).href;
    assert.equal(r.workers.filter(w=>w.url===prefix+'model-worker.js?v='+buildId).length,22);assert.equal(r.workers.filter(w=>/tflite-runtime-worker/.test(w.url)).length,0);assert.ok(r.workers.every(w=>w.closed&&w.url.startsWith(base)));
    const p=r.failureScreenshot;assert.equal(p.encoding,'base64');assert.equal(p.mime,'image/png');const bytes=Buffer.from(p.data,'base64');assert.equal(bytes.length,p.bytes);assert.ok(bytes.length>0&&bytes.length<=512*1024);assert.equal(sha256(bytes),p.sha256);assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');await writeFile(screenshotPath,bytes,{flag:'wx'});
    return {...r,failureScreenshot:{...p,data:undefined}};
}
