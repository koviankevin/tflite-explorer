import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {gitReader,sourceScope} from '../../scripts/lib/release-gates.mjs';
import {gitSource,verifyArtifact} from '../../scripts/lib/release-artifact.mjs';
const source=gitSource();assert.equal(source.commit,'412dd958c77f564c4dc044cb42e07238757190a4');assert.equal(source.tree,'896f518b267f4e5328de8150e0ff7c245a0ef445');assert.equal(source.dirty,false);
const previous=JSON.parse(await readFile('build/qa/preview32-main-gates-authenticated-final/review.json','utf8'));assert.equal(previous.authentication,'passed');
const reader=gitReader(),scopes=previous.receipt.gates.map(g=>{const current=sourceScope(g.kind,source.commit,reader),tested=sourceScope(g.kind,g.testedCommit,reader);assert.equal(current.fingerprint,g.scopeFingerprint);assert.deepEqual(current.files,tested.files);return {kind:g.kind,runId:g.runId,fingerprint:current.fingerprint,files:current.files.length,reused:true};});
const manifest=await verifyArtifact('build/qa/preview32-frozen-main',{publicOnly:true,requireClean:true,expectedCommit:source.commit});assert.deepEqual(manifest.release.source,source);assert.deepEqual(gitSource(),source);
const receipt={status:'passed',source,sourceUnchanged:true,release:manifest.release,files:manifest.files.length,scopes,scope:'Exact PR/merge tree and all four authenticated gate dependency scopes; documentation/evidence only differences, no browser rerun.'};await writeFile('build/qa/preview32-frozen-review.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));
