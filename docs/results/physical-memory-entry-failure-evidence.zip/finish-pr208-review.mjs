import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readArtifact,assertReport,sourceScope,gitReader} from '../../../scripts/lib/release-gates.mjs';
const q=new URL('./',import.meta.url),load=async n=>JSON.parse(await readFile(new URL(n,q),'utf8')),git=(...a)=>execFileSync('git',a,{encoding:'utf8'}).trim();
const p=await load('pr208-before-merge.json'),c=await load('pr208-tested-commit.json'),head='93cfdf3bfaf4f0ffd8219dfb5d7109d97ca9de4d',details={};
assert.equal(p.head.sha,head);assert.equal(git('rev-parse','HEAD'),head);assert.equal(git('rev-parse','HEAD^{tree}'),c.tree.sha);assert.equal(git('status','--porcelain'),'');
for(const kind of ['node','contract']){
 const r=await load(`pr208-${kind}-run.json`),j=(await load(`pr208-${kind}-jobs.json`)).jobs,l=(await load(`pr208-${kind}-log.json`)).content;
 assert.equal(r.head_sha,head);assert.equal(r.conclusion,'success');assert.equal(r.event,'pull_request');assert.equal(r.run_attempt,1);assert.equal(r.repository.full_name,'koviankevin/tflite-explorer');assert.equal(j.length,1);assert.equal(j[0].conclusion,'success');assert.equal(j[0].head_sha,head);assert.equal(j[0].run_id,r.id);assert.ok(l.includes(c.sha));details[kind]={run:r.id,job:j[0].id};
 if(kind==='node'){
  for(const s of ['# tests 912','# pass 877','# fail 0','# skipped 35','# cancelled 0'])assert.ok(l.includes(s),s);
  for(const name of ['Run node --test test/*.test.mjs','Run node scripts/build.mjs'])assert.ok(j[0].steps.some(s=>s.name===name&&s.conclusion==='success'));
  details[kind].counts={tests:912,pass:877,fail:0,skipped:35,cancelled:0};
 }else{
  const a=(await load('pr208-contract-artifacts.json')).artifacts;assert.equal(a.length,1);assert.equal(a[0].workflow_run.head_sha,head);assert.equal(a[0].workflow_run.id,r.id);assert.equal(a[0].expired,false);assert.equal(a[0].name,`release-contract-${c.sha}-1`);
  const decoded=readArtifact(await readFile(new URL('pr208-contract-original.zip',q)),a[0].digest),report=decoded.report;
  assertReport(report,'contract',{...r,head_sha:c.sha},c.tree.sha);assert.deepEqual(report.counts,{tests:79,pass:79,fail:0,skipped:0,cancelled:0});assert.equal(report.plan.required,true);assert.equal(report.node,'v22.23.3');
  const scope=sourceScope('contract',head,gitReader());assert.equal(scope.fingerprint,report.plan.scopeCheck.candidateFingerprint);
  details[kind]={...details[kind],artifact:a[0].id,providerDigest:a[0].digest,reportSHA256:decoded.sha256,counts:report.counts,scopeFingerprint:scope.fingerprint};
 }
}
const changed=git('diff','--name-only','cc57b3011892317b497a717fc6a16b68b874bd62',head).split('\n');assert.ok(!changed.some(x=>/^(src|vendor)\//.test(x)||['package.json','package-lock.json'].includes(x)));
const receipt={status:'PR208-original-checks-and-tested-tree-verified',at:new Date().toISOString(),head,checkout:c.sha,tree:c.tree.sha,details,changedFiles:changed,appParserRuntimeVendorPackageUnchanged:true,selectedLocalTests:49,syntheticBudget:await load('profile-budget-with-capacity.json'),helperCorrection:'Initial reader assumed source.fingerprint; original contract schema stores plan.scopeCheck.candidateFingerprint. Preserved originals reused locally; no CI rerun.',releaseEvidenceEligible:false,goalComplete:false};
await writeFile(new URL('pr208-checks-review.json',q),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
await writeFile(new URL('continuation.json',q),JSON.stringify({status:'progress',goal:'active',next:'merge verified PR208 then one predeclared diagnostic main dispatch; original failed gate stays failed; no deployment',head,receipt:'pr208-checks-review.json',previous:'../legacy-shape-preflight/continuation.json'},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(receipt));
