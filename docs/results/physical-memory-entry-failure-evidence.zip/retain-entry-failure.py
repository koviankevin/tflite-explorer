import datetime,hashlib,io,json,pathlib,subprocess,zipfile
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];gh=r'H:\mc2llvm\.work\gh\bin\gh.exe';base='repos/koviankevin/tflite-explorer/'
def raw(route):return subprocess.check_output([gh,'api','--allow-escape-sequences',base+route],timeout=45)
def api(route):return json.loads(raw(route).decode('utf-8-sig'))
def save(n,o):
    with (q/n).open('x',encoding='utf-8') as f:json.dump(o,f,indent=2);f.write('\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
r=api('actions/runs/41256209262');j=api('actions/runs/41256209262/jobs');a=api('actions/runs/41256209262/artifacts')
assert r['status']=='completed' and r['conclusion']=='failure' and r['run_attempt']==1 and r['event']=='workflow_dispatch' and r['head_sha']=='16166884841780f9f28071fcb46999ad65f56027' and r['path']=='.github/workflows/physical-memory-diagnostic.yml'
assert len(j['jobs'])==1 and j['jobs'][0]['id']==124699802745 and j['jobs'][0]['conclusion']=='failure'
assert len(a['artifacts'])==1
artifact=a['artifacts'][0];assert artifact['id']==13063695536 and not artifact['expired'] and artifact['workflow_run']['id']==r['id']
save('first-diagnostic-run.json',r);save('first-diagnostic-jobs.json',j);save('first-diagnostic-artifacts.json',a)
log=raw('actions/jobs/124699802745/logs');save('first-diagnostic-log.json',{'content':log.decode('utf-8-sig')})
b=raw('actions/artifacts/13063695536/zip');assert len(b)==artifact['size_in_bytes'] and 'sha256:'+sha(b)==artifact['digest']
with (q/'first-diagnostic-original.zip').open('xb') as f:f.write(b)
with zipfile.ZipFile(io.BytesIO(b)) as z:
    assert z.namelist()==['browser-memory-diagnostic-41256209262-1.json'] and z.testzip() is None
    body=z.read(z.namelist()[0]);report=json.loads(body)
with (q/'first-diagnostic-report.json').open('xb') as f:f.write(body)
assert report['status']=='failed' and report['releaseEvidenceEligible']==False and report['purpose']=='readonly-native-memory-attribution'
assert 'Unknown lifecycle profile' in report['error'] and report['cycles']==[] and report['samples']==[]
assert 'environment' not in report and 'fixture' not in report and 'memoryProfile' not in report
save('first-diagnostic-review.json',{'status':'failed-before-resource-fixture-or-browser','run':r['id'],'job':j['jobs'][0]['id'],'source':r['head_sha'],'artifact':artifact['id'],'providerDigest':artifact['digest'],'reportSHA256':sha(body),'rootCause':'Entry allowlist still accepted only gate/soak; memory-diagnostic was rejected before resource preflight. Instrumentation unit tests missed the actual entry.','measurementObtained':False,'originalRSSGateUnchanged':41252363060,'correction':'Actual-entry subprocess regression reproduced Unknown lifecycle profile, then reached a stubbed resource boundary after the one-line allowlist correction; no physical model/browser in that test.','selectedTests':50,'releaseEvidenceEligible':False,'goalComplete':False})
names=['plan.json','dispatch-intent.json','dispatch-result.json','pr208-merge-proof.json','pr208-checks-review.json','first-diagnostic-run.json','first-diagnostic-jobs.json','first-diagnostic-artifacts.json','first-diagnostic-log.json','first-diagnostic-original.zip','first-diagnostic-report.json','first-diagnostic-review.json','entry-profile-red.tap','entry-profile-harness.tap','entry-profile-real-red.tap','entry-selected-green.tap','settle-selected-verified.tap','profile-budget-with-capacity.json','finish-pr208-review.mjs','retain-entry-failure.py']
dest=root/'docs/results/physical-memory-entry-failure-evidence.zip';records=[]
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for n in names:
        data=(q/n).read_bytes();z.writestr(n,data);records.append({'path':n,'bytes':len(data),'sha256':sha(data)})
    z.writestr('manifest.json',json.dumps({'format':'model-lens-evidence-archive','records':records},indent=2)+'\n')
with zipfile.ZipFile(dest) as z:assert z.testzip() is None
receipt=json.loads((q/'first-diagnostic-review.json').read_bytes());receipt['at']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['originals']={'path':dest.name,'records':len(records),'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes())}
with (root/'docs/results/physical-memory-entry-failure.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
