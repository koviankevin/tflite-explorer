import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {quantizationFixture} from '../../../test/quantization-fixture.mjs';
import {parseModel} from '../../../src/model-engine.js';
import {inspectTfliteQuantization as current} from '../../../src/tflite-quantization-checks.js';
import {inspectTfliteQuantization as previous} from './candidate-site-v2/src/tflite-quantization-checks.js';
const q=new URL('./',import.meta.url),hash=b=>createHash('sha256').update(b).digest('hex'),changed=execFileSync('git',['diff','--name-only','70946a276962915861fa44aa2091a4bb84125f42','--','src','vendor'],{encoding:'utf8'}).trim().split('\n');
assert.deepEqual(changed,['src/tflite-quantization-checks.js']);
const rows=[];for(const [name,options]of [['native-bad',{rank:false,scale:[.25,.5],dimension:3,target:1}],['native-opaque',{dimension:99,customDetails:true,target:1}],['native-large',{layers:201}],['CPU-original',{}],['CPU-legacy',{rank:false}],['CPU-invalid-axis',{rank:false,dimension:3}]]){
 const f=await quantizationFixture(options),a=previous(f.index.raw,[0]),b=current(f.index.raw,[0]);assert.deepEqual(b,a);rows.push({name,modelSHA256:hash(f.bytes),metadataSHA256:hash(JSON.stringify(b)),total:b.total,failed:b.failed,unchecked:b.unchecked});
}
const metadata=JSON.parse(await readFile(new URL('../../../vendor/netron/tflite-metadata.json',q),'utf8')),corpus=new URL('../../../../tflite-explorer/build/qa/product-next/public-corpus/',q),manifest=JSON.parse(await readFile(new URL('manifest.json',corpus),'utf8'));
const files=[...manifest.files.map(f=>({name:f.file,url:new URL(f.file,corpus),sha256:f.sha256})),{name:'person_detect.tflite',url:new URL('../public-quantized-compatibility/person_detect.tflite',q),sha256:'808cfdfc0cf3a6fa6f6fa26bfa379ea97c16d5db7334637766e39c3408502e9d'}];
for(const f of files){const bytes=new Uint8Array(await readFile(f.url));assert.equal(hash(bytes),f.sha256);const index=await parseModel((o,n)=>bytes.subarray(o,o+n),bytes.length,metadata),ids=index.raw.subgraphs.map((_,i)=>i),a=previous(index.raw,ids),b=current(index.raw,ids);if(f.name==='conv10.tflite'){const expected=structuredClone(a);assert.equal(expected.tensors[2].dtype,'INT64');expected.checked--;expected.unchecked++;expected.tensors[2].status='not-run';expected.tensors[2].reason='此 dtype 的 zero point 範圍尚未實作；其餘 affine 欄位已檢查，kernel 仍未驗證。';assert.deepEqual(b,expected);}else assert.deepEqual(b,a);rows.push({name:f.name,modelSHA256:f.sha256,metadataSHA256:hash(JSON.stringify(b)),total:b.total,failed:b.failed,unchecked:b.unchecked});}
const tap=await readFile(new URL('dtype-followup-green.tap',q),'utf8');assert.match(tap,/pass\s+20/);assert.match(tap,/fail\s+0/);
const receipt={status:'passed-unsupported-dtype-followup-and-finite-reuse-review',before:'70946a276962915861fa44aa2091a4bb84125f42',moduleRawSHA256:hash(await readFile(new URL('../../../src/tflite-quantization-checks.js',q))),changedApplicationFiles:changed,followupNodeChecks:20,rows,scope:'Only unimplemented dtype range classification changes. All three actual native fixture metadata objects, CPU-control objects and four fixed public-model metadata objects are exactly unchanged. conv10 has exactly one INT64 bias reclassified from passed to not-run;counts adjust accordingly,zero failed and all values retained. UI/report/serializer/parser/runtime/vendor unchanged;reuse previous Windows/CPU/preservation with original source scope. New INT4/UINT16/FLOAT32 classification and actual INT4 serialized report have their own Node evidence;no new native primitive-dtype run claimed.'};
await writeFile(new URL('dtype-followup-reuse-review.json',q),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({status:receipt.status,node:20,unchangedCaseObjects:rows.length,changed,publicFailed:rows.at(-1).failed}));

