import hashlib,json,pathlib,zipfile
q=pathlib.Path(__file__).resolve().parent;root=q.parents[2];sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((q/'dtype-followup-reuse-review.json').read_bytes());assert r['status']=='passed-unsupported-dtype-followup-and-finite-reuse-review' and r['followupNodeChecks']==20 and r['moduleRawSHA256']==sha((root/'src/tflite-quantization-checks.js').read_bytes())
names=['unsupported-dtype-red.tap','dtype-followup-green.tap','unsupported-int64-boundary-green.tap','dtype-followup-int64-boundary.json','review-dtype-followup-before-int64-boundary.mjs','review-dtype-followup.mjs','dtype-followup-reuse-review.json','pr203-initial-green-checks.json','archive-dtype-followup.py']
records=[{'path':n,'bytes':(q/n).stat().st_size,'sha256':sha((q/n).read_bytes())} for n in names];m=(json.dumps({'format':'model-lens-quantization-dtype-followup-originals','records':records,'privacy':'Only source,metadata and test logs. No model/weight/BIN/BMP bytes.'},indent=2)+'\n').encode()
dest=root/'docs/results/quantization-dtype-followup-evidence.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('manifest.json',m)
    for n in names:z.write(q/n,n)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    for v in records:assert sha(z.read(v['path']))==v['sha256']
b=dest.read_bytes();r.update(format='model-lens-quantization-dtype-followup',status='candidate-dtype-coverage-corrected-not-published',actualINT4Report='3unverified/0checked/0failed,noCPUclaim',unsupportedRanges=['INT64','INT4','UINT16','FLOAT32'],rangeRulesImplemented=['INT8','UINT8','INT16','INT32'],originals={'path':dest.name,'bytes':len(b),'sha256':sha(b),'manifestSHA256':sha(m),'records':len(records)},goalComplete=False)
(root/'docs/results/quantization-dtype-followup.json').open('x',encoding='utf-8').write(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'archiveBytes':len(b),'archiveSHA256':sha(b),'records':len(records)}))

